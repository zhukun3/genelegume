# GeneLegume v0.2.4

基于**共线性 + 同源关系**，在豆科及更大尺度的植物中推断基因的**存在/缺失、扩张/收缩**。
直接复用已有的 OrthoFinder 结果（家族 + 它已经算好的 DIAMOND 比对），无需重新比对。

## 分析单元：两个层级

| 层级 | 单元 | 物种范围 | 用途 |
|---|---|---|---|
| 家族层 | OrthoFinder N0 HOG | 全部物种（苔藓 → 豆科） | 深时间尺度的家族起源/丢失、拷贝数变化（与 CAFE5 可比） |
| 位点层 | HOC = HOG 按共线性拆分出的位点 | 共线性范围内（如被子植物） | 位点级 PAV、真实缺失 vs 注释/组装问题、WGD 保留/分化丢失、串联扩张 |

HOC 的定义：**由共线性范围根节点处同一个祖先位点衍生出的全部拷贝**。范围内发生的 WGD（如蝶形花 WGD、大豆属 WGD）产生的拷贝留在同一个 HOC 里，由重建模型按 WGD 解释，而不是算作扩张。

## 流程

```
genelegume prepare  # 读 OrthoFinder 家族、映射到 BED、检查物种树
genelegume synteny  # 范围内所有基因组对的共线块（可断点续跑，多进程）
genelegume hoc      # 局部簇 → 复制模式 → HOC 构建 → 零值分类
genelegume recon    # 任意拓扑上的祖先拷贝数重建 + 事件判定（家族层 + 位点层）
genelegume run      # 依次执行以上四步
genelegume benchmark  # 在模拟数据上多种子评估（可选）
genelegume subgenomes  # 异源多倍体按祖先种自动划分亚基因组，并生成对应的物种树
genelegume setup    # 从"每个物种一个文件夹"的目录里自动找注释/基因组/蛋白，生成配置
```

### v0.2.4 的主要变化
- **miniprot 复查改为合并区间**：同一染色体上重叠的投影区间先合并再提取，基因组每个碱基只建一次索引（之前每个零值单元各写一份，重叠后总长度可达基因组的数倍，内存 30–40 GB）。每个零值单元只认自己 HOC 的查询蛋白、且落在自己区间内的比对。miniprot 改为保留较弱的次要比对（`-p 0.1 --outs=0.1 -N 100`），避免同家族在别处的强比对掩盖目标区间内的退化拷贝（v0.2.3 及以前会把这类情况判为 `absent`）。每个物种的区间统计写在 `miniprot/<物种>/regions_summary.txt`。
- **新命令 `genelegume subgenomes`**：异源多倍体的每条染色体按其基因对各二倍体祖先种的最佳比对得分投票，划分为 A/B 等亚基因组；物种树中多倍体被替换为亚基因组叶，分别放在各自祖先种旁边，并保留多倍体之间的关系（如栽培花生与 A. monticola 互为姐妹）。输出新配置、`*_tree.nwk` 和逐条染色体的划分表 `*_subgenome_assignment.tsv`。
- `setup`：OrthoFinder 结果中没有 `N0.tsv` 时（如 OrthoFinder 3.x 或 `-og` 运行）自动写入 `family_level: og`；注释能匹配几乎全部蛋白时不再误报"多转录本"（如 `Adu01.1234` 这类以基因编号结尾的 ID）。
- 测试 44 个（新增模拟异源四倍体的端到端测试）。

### v0.2.3 的主要变化
- `--folder-map` 指定的物种按文件夹名识别属名（如 `S1979_T2T.gene.pep` → `Stylosanthes_guianensis`），用于自动放置 WGD。

### v0.2.2 的主要变化
- `setup` 按去掉后缀的属名_种名找文件夹（`Glycine_max.Wm82` → `Glycine_max/`），新增 `--folder-map`（两列 TSV：OrthoFinder 物种名、文件夹）处理名字完全对不上的物种。
- GFF 中所有像 ID 的属性值都可用于匹配蛋白名（包括 GWH 的 `Accession`/`Protein_Accession`/`OriID`、NCBI 的 `Dbxref`），不再只限于固定的几个字段。
- WGD 按属名自动放置（蝶形花、大豆属、禾本科、拟南芥等）；若某个类群的最近共同祖先下混入了其他物种（多半是根定错），不放置并在配置中说明。
- 报告 OrthoFinder 输入中同一基因的多个转录本（会高估家族层拷贝数）；匹配率接近 0 时给出蛋白名和注释 ID 的示例；花生类异源四倍体给出按染色体拆分亚基因组的建议。
- 测试 37 个。

### v0.2.1 的主要变化
- **新命令 `genelegume setup`**：注释和基因组放在 `<根目录>/<物种名>/...`（文件名任意，最多三层子目录）时，自动为每个 OrthoFinder 物种挑选文件，写出带逐物种路径的配置：
  - 注释：所有 `.gff3/.gff/.gtf/.bed(.gz)` 候选都用流程本身的读取器读一遍，取与 OrthoFinder 蛋白名匹配率最高的；TE、重复序列、非编码 RNA 等文件按文件名跳过。
  - 基因组：序列名与所选注释的染色体名一致的核酸 FASTA；CDS/转录本 FASTA 会被识别并跳过。
  - 蛋白：优先用 OrthoFinder 的输入 FASTA（默认 Results 上两级目录），否则用文件夹中表头匹配最好的蛋白 FASTA。
  - 只有在有物种需要时才设置 `id_strip`；WGD 模板中数据里不存在的物种条目会被去掉；输出 `setup_report.tsv`（逐物种选择与问题）和 `setup_report_chromosomes.tsv`（用来配置亚基因组）。
- **GFF3/GTF 读取兼容更多注释来源**：OrthoFinder 蛋白名可以匹配转录本 ID/Name、基因 ID/Name（蛋白按基因命名）、CDS 的 `protein_id` 或 CDS ID（NCBI），并去掉 NCBI 的 `rna-`/`cds-`/`gene-` 前缀；支持 GTF；没有 mRNA 行时用 CDS/exon 构建转录本；文件中有 CDS 时去掉非编码转录本（lncRNA 等），避免它们插入基因顺序。匹配上的记录直接以 OrthoFinder 蛋白名命名。BED 输入的行为不变。
- 测试从 24 个增加到 32 个。

### v0.2.0 的主要变化
- **按物种对动态加权的证据模式（`evidence.mode: weighted`，默认）**：HOC 图的边不再只来自共线锚点，而是对每个同家族基因对计算 HMS = α·共线分 + (1−α)·同源分，α 按基因组对从数据估计（详见下文"关键算法 3"）。旧行为保留为 `synteny_first`。
- 零值新增 `partial` 状态（miniprot 只有部分比对、无移码/终止），按缺数据处理，不再算作 `pseudo`。
- CAFE5 导出不再把 NA 写成 0：含 NA 的单元不写入 `cafe5_input.tsv`，另列在 `cafe5_excluded_na.tsv`。
- 事件表新增 `ambiguous` 列（该枝两端的状态存在几乎等价的最优替代），`branch_summary.tsv` 新增 `n_ambiguous`。
- 新命令 `genelegume benchmark`：多种子 × 多场景 × 多方法的模拟评估，输出均值和标准差；模拟器新增 `--shuffle`（单基因离开共线位置但位点不变，用来模拟共线性侵蚀）。
- 测试从 14 个增加到 24 个；加入 GitHub Actions；修正 conda 环境文件和 Dockerfile 的安装方式。

### 关键算法
1. **共线块**：MCScanX 式打分（匹配 +50，间隔罚分 −1/基因，最大间隔 25，≥5 锚点），DAGchainer 式贪心提取。纯 Python 下 1.6 万个锚点约 3 秒；建议安装 numba（已写入 conda 环境）以加速。
2. **WGD 感知的直系层筛选**：A→B 的期望深度 = B 谱系上自 A–B 分化以来 WGD 倍数的乘积（例如 苜蓿→大豆 = 2）。每个位置只保留身份度最高的前 k 层，更老的旁系块被过滤。
3. **HOC 构建**：节点是局部簇（同家族、同染色体、间隔 ≤5 个基因）。边有两类：
   - **加权证据边**（`weighted` 模式）：对基因组对 A–B 的每个同家族候选基因对 (a, b)：
     - 共线分 s：只有直系锚点才非 0，等于 a 两侧 ±W（默认 10）个基因内同一共线块的锚点数 / W，上限 1；
     - 同源分 h：bitscore 除以 a 在 B 中的最佳 bitscore，以及除以 b 在 A 中的最佳 bitscore，取较小值（互为最佳 = 1）；
     - HMS = α_AB·s + (1−α_AB)·h；保留"互为前 k 名"且 HMS ≥ τ 的基因对，k 来自 WGD 配置（苜蓿→大豆 k=2，大豆→苜蓿 k=1）；
     - α_AB 默认是该基因组对的**共线覆盖率**：互为最佳匹配的基因对中，同时是直系锚点的比例。近缘、共线保守的物种对 α 高，主要信共线性；远缘或共线侵蚀的物种对 α 低，主要信同源性。
     - 只有同源证据的边（s=0）满足 HMS ≤ 1−α，所以只在 α ≤ 1−τ 的物种对之间才能成立：近缘物种中没有共线伙伴的拷贝（转座拷贝、伙伴已丢失）保持独立位点，远缘物种中则由同源关系连起来。
     - 其他 α 选项：`rbk`（GeneTribe 的标准改为适配 WGD：取使"互为前 k 名"对数最多的 α）、`smooth`（覆盖率对物种树距离拟合 logistic 曲线后取曲线值）、或固定数值。
   - **比范围根更年轻的共线块**（身份度 ≥ 跨根直系的中位数），用来把范围内 WGD 产生的旁系拷贝连起来。
   
   先取连通分量；某物种的簇数超过其 WGD 史允许的上限时，再用 MCL 细分。`synteny_first` 模式下第一类边只用直系锚点，同源证据只在 `NA_nocontext` 时兜底（v0.1 行为）。
4. **零值分类**（GoldMiner 没有这一步）：用相邻锚点把位点投影到目标基因组：
   - 投影不到 → `NA_nocontext`（缺数据）
   - 落在 N 区 → `NA_gap`（缺数据）
   - miniprot 找到完整同源序列 → `unannotated`（补为 1）；找到含移码/终止的序列 → `pseudo`（0）；只有部分比对、无移码/终止 → `partial`（缺数据）
   - 都没有 → `absent`（真实缺失）
   - 另外两条规则：投影区间内有同家族但没锚上的基因，直接归入该 HOC（位置补救）；没有共线上下文时，按同家族最佳比对归入（同源兜底）。
5. **重建**：加权 Sankoff 简约，按拷贝数向量化，支持任意多叉有根树。NA 叶不计代价。WGD 枝上期望值为 i×m，保留 WGD 拷贝代价为 0，WGD 后丢失（分化丢失）代价很低。事件类型：`gain / loss / expansion / contraction / wgd_retention / wgd_fractionation`。位点层的扩张事件附带该枝下基因的复制模式（wgd / tandem / proximal / transposed / dispersed）。
6. **多倍体与泛基因组**：`subgenomes` 按染色体把异源多倍体拆成亚基因组叶；`accessions` 把多个品系合并成一个物种叶，同时输出存在频率。频率默认 ≥50% 才算存在，而不是像 GoldMiner 那样"有一个品系有就算有"。

## 安装

```bash
conda env create -f env/environment.yml      # 包含 numba、miniprot、CAFE5
conda activate genelegume
pip install -e .                             # 在仓库根目录安装 genelegume 本身
# 或者用容器
docker build -f env/Dockerfile -t genelegume .
```

## 快速运行

指定现有 OrthoFinder 结果目录和注释目录即可。程序会自动读取 OrthoFinder 的物种树，并查找共线性范围内每个物种的注释。

```bash
genelegume run --orthofinder /data/Results_XXX --annotations /data/annotations \
  --workdir /data/genelegume_pilot -t 4
```

- 注释文件的文件名使用 OrthoFinder 物种名，例如 `Glycine_max.gff3.gz` 或 `Medicago_truncatula.bed`。同一个目录可混用 BED 和 GFF3，均支持 gzip。同一物种同时有两种格式时优先使用 BED。
- GFF3/GTF：每个基因取一个转录本。优先取能匹配 OrthoFinder 蛋白名的转录本（先精确匹配，再用 `--id-strip`），否则取基因组跨度最长的。可匹配的名字包括转录本 ID/Name、基因 ID/Name、CDS 的 `protein_id`/ID。
- 注释按物种分文件夹存放、文件名不统一时，用 `genelegume setup`（见下）。
- OrthoFinder 的 `WorkingDirectory` 需要保留 `Blast*_*.txt(.gz)`、`SpeciesIDs.txt` 和 `SequenceIDs.txt`。如果它在结果目录外，用 `--orthofinder-workdir /data/WorkingDirectory` 指定。
- 可加 `--genome-dir /data/genomes` 检查组装缺口。共线性默认覆盖整棵树，可用 `--scope 物种A 物种B` 限定到两者最近共同祖先的支系。
- `--evidence-mode synteny_first` 切回 v0.1 的行为；`--alpha coverage|smooth|rbk|0.8` 设定共线权重。
- 首次试跑可将命令中的 `run` 换成 `prepare`，先检查输出目录中的 `id_match.tsv`。使用 `--annotations` 时若缺少范围内物种的注释，程序会报出物种名。更换输入或共线性参数时，请指定新的 `--workdir`。

## 注释按物种分文件夹存放：`genelegume setup`

```bash
genelegume setup --orthofinder /data/OrthoFinder/Results_XXX \
  --species-root /data/all_species -o genelegume.yaml -t 16
# 检查 setup_report.tsv 和 genelegume.yaml（WGD、亚基因组、物种树的根）后：
genelegume prepare -c genelegume.yaml
genelegume run -c genelegume.yaml
```

`--proteome-dir` 指定 OrthoFinder 输入 FASTA 所在目录（默认为 Results 的上两级，即 `orthofinder -f` 的目录）。OrthoFinder 物种名带后缀（如 `Glycine_max.Wm82`）时按 `Glycine_max/` 查找；只差大小写或个别字母时也能找到，但会在报告中提示确认；完全对不上的用 `--folder-map map.tsv` 指定（每行：OrthoFinder 物种名、Tab、文件夹名或路径）。

## 异源多倍体：`genelegume subgenomes`

```bash
genelegume subgenomes -c genelegume.yaml \
  --polyploid Arachis_hypogaea --polyploid Arachis_monticola \
  --progenitor A=Arachis_duranensis --progenitor B=Arachis_ipaensis -o genelegume_sub.yaml
```

检查屏幕输出中每条大染色体的划分和投票一致率（低于 80% 会提示，可能是组装错误或易位）。互为姐妹的多倍体请在同一条命令中一起划分，这样它们在新树中仍保持姐妹关系。新树的枝长是近似值（只用于共线覆盖率衰减曲线）。

## 自定义配置

`genelegume run -c config.yaml` 仍可使用。命令行路径相对于当前目录，YAML 路径相对于文件所在目录。可以组合使用两种方式，例如把 WGD 和物种树写在 YAML 里，运行时用 `--annotations` 指定注释目录。

YAML 支持 `bed_dir`、`gff_dir` 和 `species` 下逐物种的 `bed` 或 `gff` 路径。自定义物种树、WGD、miniprot 和蛋白 FASTA 的配置见 `examples/config_legume55.yaml`。默认配置未定义 WGD，已知有 WGD 的数据应按文献配置后再解读扩张和收缩。

## 主要输出（`workdir/`）
| 文件 | 内容 |
|---|---|
| `hoc/hoc_matrix.tsv` | HOC × 物种拷贝数（NA = 缺数据） |
| `hoc/hoc_state.tsv` | present / absent / unannotated / pseudo / partial / NA_gap / NA_nocontext |
| `hoc/hoc_genes.tsv.gz` | 基因 → HOC，证据类型（synteny / position / homology / none），复制模式 |
| `hoc/hoc_zero_states.tsv.gz` | 每个零值的投影区间与支持数 |
| `hoc/pair_alpha.tsv` | 每个基因组对的距离、共线覆盖率、rbk α、采用的 α、边数、纯同源边数 |
| `hoc/synteny_decay.pdf` | 共线覆盖率随物种树距离的衰减曲线 |
| `recon_{family,hoc}/events.tsv.gz` | 单元 × 枝的事件表（`ambiguous` 列标记存在等价最优解的事件） |
| `recon_{family,hoc}/branch_summary.tsv` | 每枝各类事件数量 |
| `recon_{family,hoc}/node_states.tsv.gz` | 所有节点的祖先拷贝数 |
| `recon_{family,hoc}/origins.tsv` | 起源节点（`n_origins`>1 提示趋同获得或家族划分问题） |
| `recon_{family,hoc}/cafe5_input.tsv` | 无缺失数据的单元，可直接用 CAFE5 检验显著性；含 NA 的单元见 `cafe5_excluded_na.tsv` |
| `recon_{family,hoc}/tree_events.pdf` | 树上标注 +获得/−丢失、↑扩张/↓收缩、WGD |

## 验证（模拟数据，`genelegume benchmark`）
模拟设置：6 个物种（5 个在共线性范围内），两次 WGD（蝶形花 ×2、大豆属 ×2）；有串联、转座、丢失、新基因、倒位和易位；加入 1–2% 的注释遗漏和组装 gap。所有输入都按 OrthoFinder 的真实格式写出。三个场景：
- `default`：同 v0.1；
- `eroded`：另有单基因离开共线位置（位点身份不变，速率 0.02/基因/时间单位，长枝上更多）；
- `eroded_strong`：速率 0.04，并提高两个基因组的注释遗漏率。

5 个随机种子（1–5）的均值 ± 标准差（完整结果见 `benchmarks/v0.2.0/`）：

| 指标 | 场景 | synteny_first（v0.1） | weighted（默认，α=覆盖率） | weighted, α=rbk |
|---|---|---|---|---|
| HOC 精确率 | default | 0.961 ± 0.010 | 0.963 ± 0.009 | 0.954 ± 0.006 |
| | eroded | 0.965 ± 0.012 | 0.964 ± 0.011 | 0.958 ± 0.008 |
| | eroded_strong | 0.953 ± 0.010 | 0.952 ± 0.011 | 0.947 ± 0.011 |
| HOC 召回率 | default | 0.998 ± 0.001 | 0.999 ± 0.001 | 1.000 ± 0.000 |
| | eroded | 0.850 ± 0.008 | 0.962 ± 0.002 | 0.982 ± 0.004 |
| | eroded_strong | 0.764 ± 0.009 | 0.940 ± 0.009 | 0.964 ± 0.005 |
| `absent` 中真实缺失的比例 | default | 0.898 ± 0.042 | 0.919 ± 0.042 | 0.948 ± 0.021 |
| | eroded | 0.253 ± 0.019 | 0.698 ± 0.038 | 0.889 ± 0.012 |
| | eroded_strong | 0.162 ± 0.015 | 0.640 ± 0.059 | 0.769 ± 0.052 |
| loss 精确率 | default | 0.642 ± 0.051 | 0.643 ± 0.052 | 0.655 ± 0.047 |
| | eroded_strong | 0.469 ± 0.068 | 0.555 ± 0.050 | 0.566 ± 0.055 |
| gain 精确率 | eroded_strong | 0.921 ± 0.011 | 0.964 ± 0.007 | 0.967 ± 0.007 |
| 扩张精确率 | default | 0.763 ± 0.055 | 0.770 ± 0.049 | 0.701 ± 0.041 |
| 内部节点拷贝数完全正确 | eroded_strong | 0.937 ± 0.008 | 0.962 ± 0.002 | 0.964 ± 0.001 |
| WGD 保留精确率 | default | 0.955 ± 0.006 | 0.955 ± 0.006 | 0.952 ± 0.005 |

解读：
- 共线性保守时（default），两种模式几乎相同；共线性被侵蚀时，`synteny_first` 会把离开原位的基因拆成新位点，造成大量假"缺失 + 新获得"，加权模式基本修复了这一点。
- `rbk` 在召回率和缺失判定上最好，但 HOC 精确率和扩张精确率最低。模拟中的同源分几乎完美地反映分化时间，比真实 DIAMOND 结果干净得多，会偏向重同源的 `rbk`；因此默认使用更保守的覆盖率 α。真实数据上建议两者都跑并抽查。
- 标为 `ambiguous` 的事件不到 1%；loss 精确率偏低主要不是简约平局造成的，而是范围内只有一个外群（葡萄）时"外群丢失"与"内群获得"难以区分。

## 已知限制 / 下一步
- 尚未选定开源许可证；正式发布前请加入 LICENSE 文件并在 `pyproject.toml` 中注明。
- 我的开发环境里没有 miniprot，所以序列检查只测了输出解析，还没有跑过真实的 miniprot。
- 模拟中的比对是由基因谱系直接生成的，不是 DIAMOND 的真实输出；真实数据的第一轮请先抽查几对基因组的共线块。
- 简约法不给显著性。显著性可以把 `cafe5_input.tsv` 交给 CAFE5 来做；计划加入出生-死亡模型的似然方法。
- 扩张/收缩的准确率受 parsimony 歧义影响（例如"保留 WGD 拷贝后再丢失"与"早期丢失后再复制"）。下一步打算把复制模式（WGD 层 vs 串联）直接纳入重建。
