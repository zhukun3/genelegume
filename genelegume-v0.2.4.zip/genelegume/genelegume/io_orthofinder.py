"""Readers for an existing OrthoFinder (v2.5+) results directory.

Reused pieces:
* Phylogenetic_Hierarchical_Orthogroups/N0.tsv  -> gene families (HOGs)
* Orthogroups/Orthogroups.tsv (+ UnassignedGenes)  -> fallback families
* Species_Tree/SpeciesTree_rooted_node_labels.txt -> species tree
* WorkingDirectory/{SpeciesIDs,SequenceIDs}.txt + Blast{i}_{j}.txt(.gz)
  -> the all-vs-all DIAMOND/BLAST hits OrthoFinder already computed, used here
     for synteny so nothing has to be re-searched.
"""
from __future__ import annotations

import glob
import gzip
import os
from typing import Dict, Iterator, List, Optional, Tuple

import pandas as pd

BLAST_COLS = ["q", "s", "pident", "alen", "mm", "gap", "qs", "qe", "ss", "se", "evalue", "bits"]


def _strip_ext(fn: str) -> str:
    base = os.path.basename(fn)
    for ext in (".gz",):
        if base.endswith(ext):
            base = base[: -len(ext)]
    for ext in (".fa", ".faa", ".fasta", ".fas", ".pep", ".aa", ".fna"):
        if base.endswith(ext):
            return base[: -len(ext)]
    return os.path.splitext(base)[0]


class OrthoFinderResults:
    def __init__(self, results_dir: str, working_dir: Optional[str] = None):
        self.dir = results_dir
        wd = working_dir
        if wd is None:
            cands = [os.path.join(results_dir, "WorkingDirectory")] + sorted(
                glob.glob(os.path.join(results_dir, "*", "WorkingDirectory")))
            wd = next((c for c in cands if os.path.isdir(c)), None)
        self.wd = wd
        self.species_ids: Dict[str, int] = {}
        if wd and os.path.exists(os.path.join(wd, "SpeciesIDs.txt")):
            with open(os.path.join(wd, "SpeciesIDs.txt")) as fh:
                for line in fh:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    i, fn = line.split(": ", 1)
                    self.species_ids[_strip_ext(fn)] = int(i)
        self._seq: Optional[Dict[str, str]] = None

    # ------------------------------------------------------------------ tree
    def species_tree_path(self) -> Optional[str]:
        for fn in ("SpeciesTree_rooted_node_labels.txt", "SpeciesTree_rooted.txt"):
            p = os.path.join(self.dir, "Species_Tree", fn)
            if os.path.exists(p):
                return p
        return None

    # -------------------------------------------------------------- families
    def families(self, level: str = "hog", include_unassigned: bool = True) -> pd.DataFrame:
        """Long table: family, species, gene.

        level="hog": N0.tsv phylogenetic HOGs (recommended);
        level="og":  Orthogroups.tsv.
        Unassigned genes become single-gene families (needed to count
        species-specific genes and de novo gains).
        """
        if level == "hog":
            p = os.path.join(self.dir, "Phylogenetic_Hierarchical_Orthogroups", "N0.tsv")
            df = pd.read_csv(p, sep="\t", dtype=str)
            id_col = "HOG"
            drop = [c for c in ("OG", "Gene Tree Parent Clade") if c in df.columns]
            df = df.drop(columns=drop)
        elif level == "og":
            p = os.path.join(self.dir, "Orthogroups", "Orthogroups.tsv")
            df = pd.read_csv(p, sep="\t", dtype=str)
            id_col = "Orthogroup"
        else:
            raise ValueError(level)
        long = _wide_to_long(df, id_col)
        if include_unassigned:
            pu = os.path.join(self.dir, "Orthogroups", "Orthogroups_UnassignedGenes.tsv")
            if os.path.exists(pu):
                u = _wide_to_long(pd.read_csv(pu, sep="\t", dtype=str), "Orthogroup")
                seen = set(long["gene"])
                u = u[~u["gene"].isin(seen)]
                long = pd.concat([long, u], ignore_index=True)
        return long

    # ------------------------------------------------------------------ hits
    def _load_seq(self) -> Dict[str, str]:
        if self._seq is None:
            self._seq = {}
            with open(os.path.join(self.wd, "SequenceIDs.txt")) as fh:
                for line in fh:
                    if ": " in line:
                        i, n = line.rstrip("\n").split(": ", 1)
                        self._seq[i] = n.split()[0]
        return self._seq

    def has_hits(self) -> bool:
        return bool(self.wd and self.species_ids and
                    glob.glob(os.path.join(self.wd, "Blast*_*.txt*")))

    def hits(self, sp_a: str, sp_b: str, evalue: float = 1e-5, top: int = 5) -> pd.DataFrame:
        """Hits with query in sp_a and subject in sp_b, original gene names.

        Keeps the ``top`` best subjects per query (by bitscore). Columns:
        q, s, pident, bits, evalue.
        """
        ia, ib = self.species_ids[sp_a], self.species_ids[sp_b]
        p = None
        for ext in (".txt.gz", ".txt"):
            c = os.path.join(self.wd, f"Blast{ia}_{ib}{ext}")
            if os.path.exists(c):
                p = c
                break
        if p is None:
            raise FileNotFoundError(f"no Blast{ia}_{ib} in {self.wd}")
        df = pd.read_csv(p, sep="\t", header=None, names=BLAST_COLS,
                         usecols=[0, 1, 2, 10, 11], dtype={"q": str, "s": str})
        df = df[df["evalue"] <= evalue]
        if sp_a == sp_b:
            df = df[df["q"] != df["s"]]
        df = df.sort_values(["q", "bits"], ascending=[True, False])
        df = df.drop_duplicates(["q", "s"])
        df = df.groupby("q", sort=False).head(top)
        seq = self._load_seq()
        df["q"] = df["q"].map(seq)
        df["s"] = df["s"].map(seq)
        return df.reset_index(drop=True)

    def self_scores(self, sp: str) -> Dict[str, float]:
        """Self-hit bitscore per gene (for BSR normalisation); empty if absent."""
        i = self.species_ids[sp]
        for ext in (".txt.gz", ".txt"):
            p = os.path.join(self.wd, f"Blast{i}_{i}{ext}")
            if os.path.exists(p):
                df = pd.read_csv(p, sep="\t", header=None, names=BLAST_COLS,
                                 usecols=[0, 1, 11], dtype={"q": str, "s": str})
                df = df[df["q"] == df["s"]]
                seq = self._load_seq()
                return dict(zip(df["q"].map(seq), df["bits"]))
        return {}


def _wide_to_long(df: pd.DataFrame, id_col: str) -> pd.DataFrame:
    sp_cols = [c for c in df.columns if c != id_col]
    rows = []
    for fam, *vals in df[[id_col] + sp_cols].itertuples(index=False, name=None):
        for sp, v in zip(sp_cols, vals):
            if isinstance(v, str) and v.strip():
                for g in v.split(", "):
                    g = g.strip()
                    if g:
                        rows.append((fam, sp, g))
    return pd.DataFrame(rows, columns=["family", "species", "gene"])
