"""Genome-side inputs: gene coordinates (BED / GFF3) and assembly gaps."""
from __future__ import annotations

import gzip
import os
import re
from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd


def _open(path: str):
    return gzip.open(path, "rt") if path.endswith(".gz") else open(path)


@dataclass
class GeneTable:
    """Ordered genes of one genome.

    Columns of ``df``: chr, start, end, gene, strand, idx (0-based rank within
    chromosome), gid (0-based rank genome-wide, chromosome-major).
    """

    species: str
    df: pd.DataFrame
    pos: Dict[str, Tuple[str, int]] = field(default_factory=dict)
    chr_len_genes: Dict[str, int] = field(default_factory=dict)

    def __post_init__(self):
        df = self.df.sort_values(["chr", "start", "end"]).reset_index(drop=True)
        df["idx"] = df.groupby("chr").cumcount().astype(int)
        df["gid"] = np.arange(len(df), dtype=int)
        self.df = df
        self.pos = dict(zip(df["gene"], zip(df["chr"], df["idx"])))
        self.chr_len_genes = df.groupby("chr").size().to_dict()
        self._gid = dict(zip(df["gene"], df["gid"]))

    def __contains__(self, gene: str) -> bool:
        return gene in self.pos

    def __len__(self) -> int:
        return len(self.df)

    def gid(self, gene: str) -> int:
        return self._gid[gene]

    def genes_on(self, chrom: str) -> pd.DataFrame:
        return self.df[self.df["chr"] == chrom]


def read_bed(path: str, species: str) -> GeneTable:
    """Read a BED with at least 4 columns (chr, start, end, gene[, score, strand])."""
    rows = []
    with _open(path) as fh:
        for line in fh:
            if not line.strip() or line.startswith(("#", "track", "browser")):
                continue
            f = line.rstrip("\n").split("\t")
            if len(f) < 4:
                f = line.split()
            strand = f[5] if len(f) > 5 else "."
            rows.append((f[0], int(f[1]), int(f[2]), f[3], strand))
    return _gene_table(path, species, rows)


def _gene_table(path: str, species: str, rows: Iterable[tuple]) -> GeneTable:
    df = pd.DataFrame(rows, columns=["chr", "start", "end", "gene", "strand"])
    if df["gene"].duplicated().any():
        dup = df.loc[df["gene"].duplicated(), "gene"].head(5).tolist()
        raise ValueError(f"{path}: duplicated gene IDs, e.g. {dup}")
    return GeneTable(species, df)


_attr_re = re.compile(r"(?:^|;)\s*([^=;]+)=([^;]*)")


def _gff_features(path: str, features: set, id_attr: str):
    with _open(path) as fh:
        for line in fh:
            if line.startswith("##FASTA"):
                break
            if line.startswith("#") or not line.strip():
                continue
            f = line.rstrip("\n").split("\t")
            if len(f) < 9 or f[2] not in features:
                continue
            attrs = dict(_attr_re.findall(f[8]))
            fid = attrs.get(id_attr)
            if fid is not None:
                yield attrs, (f[0], int(f[3]) - 1, int(f[4]), fid, 0, f[6])


_gtf_re = re.compile(r'\s*([^\s;"]+)\s+"([^"]*)"')
_TX_FEATURES = {"mRNA", "transcript"}
_PART_FEATURES = {"CDS", "exon"}
_NCBI_PREFIX = re.compile(r"^(?:rna|cds|gene|mrna|transcript)[-:_]", re.I)
# attributes that never hold an identifier (everything else is a possible alias:
# ID, Name, Accession, Protein_Accession, OriID, protein_id, Dbxref, Alias, ...)
_NON_ID_KEYS = {"Note", "note", "description", "Description", "product", "Ontology_term",
                "gbkey", "gene_biotype", "biotype", "transcript_biotype", "gene_type",
                "transcript_type", "exon_number", "exon_id", "phase", "score", "Is_circular",
                "partial", "pseudo", "inference", "experiment", "Target", "Gap",
                "Derives_from", "function", "Function", "Dbxref_type", "source", "Source"}


def _attrs(col9: str) -> Dict[str, str]:
    """GFF3 (key=value;) or GTF (key "value";) attributes."""
    if '"' in col9 and "=" not in col9.split('"')[0]:
        return dict(_gtf_re.findall(col9))
    return dict(_attr_re.findall(col9))


def _first(v: Optional[str]) -> Optional[str]:
    return v.split(",")[0] if v else None


def _add_alias(s: set, v: Optional[str]) -> None:
    if v:
        s.add(v)
        w = _NCBI_PREFIX.sub("", v)
        if w != v:
            s.add(w)


def _aliases(a: Dict[str, str]) -> set:
    """Every identifier-like attribute value (comma lists and db:xref split)."""
    out: set = set()
    for k, v in a.items():
        if k in _NON_ID_KEYS or not v:
            continue
        for piece in v.split(","):
            piece = piece.strip()
            if len(piece) < 2 or len(piece) > 100 or " " in piece or piece.isdigit():
                continue
            _add_alias(out, piece)
            if ":" in piece:
                _add_alias(out, piece.rsplit(":", 1)[1])
    return out


def read_gff(path: str, species: str, proteins: Iterable[str],
             id_strip: Optional[str] = None) -> GeneTable:
    """Read one transcript per gene, named by its OrthoFinder protein if one matches.

    Works on GFF3 and GTF. A protein matches a transcript through any
    identifier-like attribute of the transcript, its gene (proteomes named by
    gene) or its CDS rows: ID, Name, NCBI ``protein_id``/Dbxref, GWH
    ``Accession``/``Protein_Accession``/``OriID`` and so on, with NCBI
    ``rna-``/``cds-``/``gene-`` prefixes removed. Exact protein names are tried before ``id_strip``. If the
    file has no mRNA/transcript rows, transcripts are built from CDS/exon rows,
    and failing that from gene rows. Matched records are named by the protein,
    so downstream ID mapping is exact; unmatched genes keep their transcript ID
    and still count for gene order.
    """
    tx: Dict[str, list] = {}       # tid -> [chrom, start, end, strand, gene, aliases]
    mrna: set = set()              # tids from mRNA rows (coding by definition)
    parts: Dict[str, list] = {}    # tid -> same, built from CDS/exon rows
    genes: Dict[str, list] = {}    # gid -> [chrom, start, end, strand, aliases]
    with _open(path) as fh:
        for line in fh:
            if line.startswith("##FASTA"):
                break
            if line.startswith("#") or not line.strip():
                continue
            f = line.rstrip("\n").split("\t")
            if len(f) < 9:
                continue
            feat = f[2]
            if feat not in _TX_FEATURES and feat not in _PART_FEATURES and feat != "gene":
                continue
            a = _attrs(f[8])
            chrom, start, end, strand = f[0], int(f[3]) - 1, int(f[4]), f[6]
            if feat == "gene":
                gid = a.get("ID") or a.get("gene_id")
                if gid:
                    genes[gid] = [chrom, start, end, strand, _aliases(a)]
                continue
            if feat in _TX_FEATURES:
                tid = a.get("ID") or a.get("transcript_id")
                if not tid:
                    continue
                gene = _first(a.get("Parent")) or a.get("gene_id") or tid
                al = _aliases(a)
                if feat == "mRNA":
                    mrna.add(tid)
                if tid in tx:   # GTF: transcript rows can repeat
                    r = tx[tid]
                    r[1], r[2] = min(r[1], start), max(r[2], end)
                    r[5] |= al
                else:
                    tx[tid] = [chrom, start, end, strand, gene, al]
                continue
            # CDS / exon: transcript parent(s), protein IDs, coordinates
            tids = (a.get("Parent") or a.get("transcript_id") or "").split(",")
            al = _aliases(a) if feat == "CDS" else set()
            for tid in filter(None, tids):
                r = parts.get(tid)
                if r is None:
                    parts[tid] = [chrom, start, end, strand, a.get("gene_id") or tid, set(al),
                                  feat == "CDS"]
                else:
                    r[1], r[2] = min(r[1], start), max(r[2], end)
                    r[5] |= al
                    r[6] = r[6] or feat == "CDS"

    coding = {tid for tid, r in parts.items() if r[6]}
    for tid, r in parts.items():
        if tid in tx:                         # protein_id / CDS IDs onto their mRNA
            tx[tid][5] |= r[5]
        elif not coding or tid in coding:     # no transcript row: use the CDS/exon span
            tx[tid] = r[:6]                   # (GTF: by transcript_id; GFF3: by Parent)
    if coding:                                # drop non-coding transcripts (lncRNA etc.)
        tx = {tid: r for tid, r in tx.items() if tid in coding or tid in mrna}
    if not tx and genes:
        tx = {gid: [g[0], g[1], g[2], g[3], gid, set(g[4])] for gid, g in genes.items()}
    if not tx:
        raise ValueError(f"{path}: no mRNA/transcript, CDS/exon or gene features with IDs")

    alias_of: Dict[str, set] = {}
    for tid, r in tx.items():
        al = r[5]
        al.add(tid)
        g = genes.get(r[4])
        if g is not None:
            al |= g[4]
        elif r[4]:
            _add_alias(al, r[4])
        for x in al:
            alias_of.setdefault(x, set()).add(tid)

    # protein -> best transcript (exact alias beats id_strip; then longest span)
    strip = re.compile(id_strip) if id_strip else None
    claim: Dict[str, Tuple[tuple, str]] = {}     # tid -> (score, protein)
    for p in set(proteins):
        hit, m = alias_of.get(p), 2
        if not hit and strip is not None:
            hit, m = alias_of.get(strip.sub("", p)), 1
        if not hit:
            continue
        tid = max(hit, key=lambda t: (tx[t][2] - tx[t][1], t))
        sc = (m, tx[tid][2] - tx[tid][1], p)
        if tid not in claim or sc > claim[tid][0]:
            claim[tid] = (sc, p)

    # one transcript per gene: a matched one first, then the longest
    best: Dict[str, Tuple[tuple, str]] = {}
    for tid, r in tx.items():
        c = claim.get(tid)
        sc = ((c[0][0] if c else 0), r[2] - r[1], tid)
        if r[4] not in best or sc > best[r[4]][0]:
            best[r[4]] = (sc, tid)
    rows, used = [], set()
    for _, tid in best.values():
        c = claim.get(tid)
        name = c[1] if c else tid
        if name in used:
            name = f"{tid}|{len(used)}"
        used.add(name)
        r = tx[tid]
        rows.append((r[0], r[1], r[2], name, r[3]))
    return _gene_table(path, species, rows)


def gff3_to_bed(path: str, out: str, feature: str = "mRNA", id_attr: str = "ID",
                longest_per: Optional[str] = "Parent") -> int:
    """Convert GFF3 to a 6-column BED of one feature type.

    If ``longest_per`` is given (e.g. Parent for mRNA), only the longest feature
    per parent (gene) is kept by genomic span. Returns the number of records written.
    """
    best: Dict[str, Tuple[int, tuple]] = {}
    for attrs, rec in _gff_features(path, {feature}, id_attr):
        _, start, end, fid, _, _ = rec
        key = attrs.get(longest_per, fid) if longest_per else fid
        length = end - start
        if key not in best or length > best[key][0]:
            best[key] = (length, rec)
    recs = sorted((r for _, r in best.values()), key=lambda r: (r[0], r[1]))
    with open(out, "w") as o:
        for r in recs:
            o.write("\t".join(map(str, r)) + "\n")
    return len(recs)


def scan_gaps(fasta: str, min_len: int = 10) -> Dict[str, List[Tuple[int, int]]]:
    """Return runs of N/n (>= min_len) per sequence as 0-based half-open intervals."""
    gaps: Dict[str, List[Tuple[int, int]]] = {}
    pat = re.compile(r"[Nn]{%d,}" % min_len)
    name, chunks = None, []

    def flush():
        if name is None:
            return
        seq = "".join(chunks)
        gaps[name] = [(m.start(), m.end()) for m in pat.finditer(seq)]
        gaps.setdefault(name + "__len__", [(0, len(seq))])

    with _open(fasta) as fh:
        for line in fh:
            if line.startswith(">"):
                flush()
                name, chunks = line[1:].split()[0], []
            else:
                chunks.append(line.strip())
    flush()
    return gaps


def write_gaps(gaps: Dict[str, List[Tuple[int, int]]], out: str) -> None:
    with open(out, "w") as o:
        for k, v in gaps.items():
            if k.endswith("__len__"):
                o.write(f"{k[:-7]}\t0\t{v[0][1]}\tLEN\n")
            else:
                for s, e in v:
                    o.write(f"{k}\t{s}\t{e}\tGAP\n")


def read_gaps(path: str) -> Tuple[Dict[str, np.ndarray], Dict[str, int]]:
    """Read the gaps file written by write_gaps -> ({chr: Nx2 array}, {chr: length})."""
    g: Dict[str, list] = {}
    lens: Dict[str, int] = {}
    with _open(path) as fh:
        for line in fh:
            c, s, e, t = line.split()[:4]
            if t == "LEN":
                lens[c] = int(e)
            else:
                g.setdefault(c, []).append((int(s), int(e)))
    return {k: np.array(sorted(v), dtype=np.int64) for k, v in g.items()}, lens


class IdMapper:
    """Map OrthoFinder sequence names to BED gene IDs.

    Exact match first; otherwise apply ``strip`` (a regex removed from the end
    of the protein name, e.g. ``r"\\.\\d+(\\.p)?$"`` for transcript suffixes).
    """

    def __init__(self, strip: Optional[str] = None):
        self.strip = re.compile(strip) if strip else None

    def __call__(self, name: str, table: GeneTable) -> Optional[str]:
        if name in table.pos:
            return name
        if self.strip is not None:
            n2 = self.strip.sub("", name)
            if n2 in table.pos:
                return n2
        return None


def match_rate(names: Iterable[str], table: GeneTable, mapper: IdMapper) -> float:
    names = list(names)
    if not names:
        return 1.0
    return sum(mapper(n, table) is not None for n in names) / len(names)
