import gzip
import os

import pandas as pd
import yaml
from click.testing import CliRunner

from genelegume import config as cfgmod
from genelegume import pipeline
from genelegume.cli import main
from genelegume.evaluate import evaluate
from genelegume.simulate import Sim, SimParams


def test_simulated_run(tmp_path):
    d = str(tmp_path)
    Sim(p=SimParams(seed=11, genes_per_chr=80)).run().write(d)
    cfg = {"orthofinder": "OrthoFinder/Results_sim", "workdir": "out", "threads": 1,
           "bed_dir": "bed", "genome_dir": "genome", "id_strip": r"\.1$",
           "synteny": {"scope": ["Gmax", "Vvin"]},
           "wgd": [{"mrca": ["Gmax", "Mtru"], "multiplier": 2},
                   {"mrca": ["Gmax", "Gsoj"], "multiplier": 2}]}
    with open(os.path.join(d, "config.yaml"), "w") as o:
        yaml.safe_dump(cfg, o)
    pipeline.run_all(cfgmod.load(os.path.join(d, "config.yaml")))
    r = evaluate(d, os.path.join(d, "out"), {"Papi": 2, "Glyc": 2}, "Eud")
    assert r["hoc_pair_precision"] > 0.95
    assert r["hoc_pair_recall"] > 0.95
    assert r["internal_node_state_accuracy"] > 0.9
    assert r["events_genelegume"]["wgd_retention"]["precision"] > 0.9
    for f in ["hoc/hoc_matrix.tsv", "hoc/hoc_state.tsv", "recon_hoc/events.tsv.gz",
              "recon_family/branch_summary.tsv", "recon_hoc/cafe5_input.tsv"]:
        assert os.path.exists(os.path.join(d, "out", f))


def test_cli_mixed_annotations(tmp_path):
    Sim(p=SimParams(seed=11, genes_per_chr=35)).run().write(str(tmp_path))
    annotation_dir = tmp_path / "bed"
    source = annotation_dir / "Vvin.bed"
    beds = source.read_text().splitlines()
    source.unlink()
    out = tmp_path / "out"
    options = [
        "--orthofinder", str(tmp_path / "OrthoFinder" / "Results_sim"),
        "--annotations", str(annotation_dir),
        "--workdir", str(out),
        "--scope", "Gmax", "Vvin",
        "--id-strip", r"\.1$",
        "-t", "1",
    ]
    cli = CliRunner()
    missing = cli.invoke(main, ["prepare", *options])
    assert missing.exit_code == 1
    assert "missing BED or GFF3 annotation for: Vvin" in missing.output

    with gzip.open(annotation_dir / "Vvin.gff3.gz", "wt") as annotation:
        annotation.write("##gff-version 3\n")
        for row in beds:
            chrom, start, end, gene, _, strand = row.split("\t")
            prefix = f"{chrom}\tsim\tmRNA\t{int(start) + 1}"
            suffix = f"\t.\t{strand}\t.\t"
            annotation.write(f"{prefix}\t{int(end) + 100}{suffix}ID={gene}_other;Parent={gene}_parent\n")
            annotation.write(f"{prefix}\t{end}{suffix}ID={gene};Parent={gene}_parent\n")

    result = cli.invoke(main, ["run", *options])
    assert result.exit_code == 0, result.output
    matches = pd.read_csv(out / "id_match.tsv", sep="\t").set_index("species")
    assert "Mpol" not in matches.index
    assert matches.loc["Vvin", "rate"] == 1
    assert (out / "recon_hoc" / "events.tsv.gz").exists()


def test_weighted_beats_synteny_first_when_synteny_erodes(tmp_path):
    d = str(tmp_path)
    Sim(p=SimParams(seed=3, genes_per_chr=80, shuffle=0.03)).run().write(d)
    rec = {}
    for mode in ("synteny_first", "weighted"):
        cfg = {"orthofinder": "OrthoFinder/Results_sim", "workdir": f"out_{mode}", "threads": 1,
               "bed_dir": "bed", "genome_dir": "genome", "id_strip": r"\.1$",
               "synteny": {"scope": ["Gmax", "Vvin"]}, "evidence": {"mode": mode},
               "wgd": [{"mrca": ["Gmax", "Mtru"], "multiplier": 2},
                       {"mrca": ["Gmax", "Gsoj"], "multiplier": 2}]}
        with open(os.path.join(d, f"{mode}.yaml"), "w") as o:
            yaml.safe_dump(cfg, o)
        pipeline.run_all(cfgmod.load(os.path.join(d, f"{mode}.yaml")))
        r = evaluate(d, os.path.join(d, f"out_{mode}"), {"Papi": 2, "Glyc": 2}, "Eud")
        rec[mode] = r["hoc_pair_recall"]
    assert rec["weighted"] > rec["synteny_first"] + 0.03
    pa = pd.read_csv(os.path.join(d, "out_weighted", "hoc", "pair_alpha.tsv"), sep="\t")
    assert {"alpha", "coverage", "alpha_rbk", "n_homology_only"} <= set(pa.columns)
