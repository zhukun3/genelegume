"""Simulate genomes along a species tree and write OrthoFinder-format results.

Truth is kept for every gene (true locus = true HOC, family) and for every
tree node (copy number per locus), so each pipeline stage can be scored.

Events along a branch (rates per gene per time unit): copy loss, tandem
duplication (same locus), transposed duplication (new locus, same family),
de novo genes (new family), inversions, segmental translocations. WGDs double
every chromosome at the start of a branch, followed by fractionation.
Artefacts at leaves: genes missing from the annotation, and assembly gaps
(sequence replaced by N, genes inside removed from the annotation).

Homology hits are generated from the gene genealogy (identity decays with
divergence time) instead of running DIAMOND, and written as OrthoFinder
Blast{i}_{j}.txt.gz files with internal IDs.
"""
from __future__ import annotations

import gzip
import math
import os
import random
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from .tree import Tree

DEFAULT_TREE = "(((((Gmax:1,Gsoj:1)Glyc:2,Pvul:3)Phas:1,Mtru:4)Papi:2,Vvin:6)Eud:4,Mpol:10)Root;"
DEFAULT_WGD = {"Papi": 2, "Glyc": 2}


@dataclass
class Gene:
    uid: int
    locus: str
    family: str
    anc: Tuple[Tuple[float, int], ...]
    strand: str = "+"


@dataclass
class SimParams:
    n_chr: int = 6
    genes_per_chr: int = 150
    ancient_paralog_frac: float = 0.12
    loss: float = 0.012
    tandem: float = 0.004
    transposed: float = 0.002
    novel: float = 0.002
    inversions: float = 0.3
    translocations: float = 0.15
    frac_loss: float = 0.55      # fraction of WGD duplicates lost along the WGD branch
    decay: float = 0.04          # identity = 100*exp(-decay*divergence)
    unannotated: Dict[str, float] = field(default_factory=lambda: {"Pvul": 0.02, "Vvin": 0.01})
    gaps: Dict[str, int] = field(default_factory=lambda: {"Mtru": 4, "Gsoj": 2})
    gap_genes: int = 8
    spurious: float = 0.3
    shuffle: float = 0.0         # single-gene relocations per gene per time unit (locus kept):
                                 # erodes synteny without creating a new locus
    seed: int = 7


class Sim:
    def __init__(self, tree_nwk: str = DEFAULT_TREE, wgd: Optional[Dict[str, int]] = None,
                 p: SimParams = SimParams()):
        self.tree = Tree(tree_nwk)
        self.wgd = DEFAULT_WGD if wgd is None else wgd
        self.p = p
        self.rng = random.Random(p.seed)
        self.uid = 0
        self.nloc = 0
        self.nfam = 0
        self.genomes: Dict[str, Dict[str, List[Gene]]] = {}
        self.time: Dict[str, float] = {}
        self.plen: Dict[str, int] = {}

    # ----------------------------------------------------------- helpers
    def _new_uid(self) -> int:
        self.uid += 1
        return self.uid

    def _new_locus(self) -> str:
        self.nloc += 1
        return f"T{self.nloc:06d}"

    def _new_family(self) -> str:
        self.nfam += 1
        f = f"F{self.nfam:05d}"
        self.plen[f] = self.rng.randint(150, 600)
        return f

    def _copy(self, g: Gene, t: float, locus: Optional[str] = None) -> Gene:
        return Gene(self._new_uid(), locus or g.locus, g.family, g.anc + ((t, self.uid),), g.strand)

    # -------------------------------------------------------------- run
    def run(self) -> "Sim":
        p, rng = self.p, self.rng
        root = self.tree.root
        g0: Dict[str, List[Gene]] = {}
        fams: List[Tuple[str, Tuple]] = []
        for c in range(1, p.n_chr + 1):
            genes = []
            for _ in range(p.genes_per_chr):
                if fams and rng.random() < p.ancient_paralog_frac:
                    fam, anc0 = rng.choice(fams)
                    uid = self._new_uid()
                    anc = anc0[:1] + ((-rng.uniform(2, 8), uid),)
                else:
                    fam = self._new_family()
                    uid = self._new_uid()
                    anc = ((-20.0, uid),)
                    fams.append((fam, anc))
                genes.append(Gene(uid, self._new_locus(), fam, anc, rng.choice("+-")))
            g0[f"chr{c}"] = genes
        self.time[root.name] = 0.0
        self.genomes[root.name] = g0
        for node in self.tree.preorder():
            for ch in node.children:
                t0 = self.time[node.name]
                t1 = t0 + (ch.length or 1.0)
                self.time[ch.name] = t1
                self.genomes[ch.name] = self._evolve(self.genomes[node.name], t0, t1,
                                                     self.wgd.get(ch.name, 1))
        return self

    def _evolve(self, gen, t0, t1, wgd):
        p, rng = self.p, self.rng
        # speciation: every gene gets a new lineage id at t0
        g = {c: [self._copy(x, t0) for x in v] for c, v in gen.items()}
        L = t1 - t0
        if wgd > 1:
            tw = t0 + L / 2  # WGD in the middle of the branch
            new = {}
            for c, v in g.items():
                new[c + "a"] = [self._copy(x, tw) for x in v]
                for k in range(1, wgd):
                    new[c + "abcdefgh"[k]] = [self._copy(x, tw) for x in v]
            g = new
            # fractionation: drop one copy of many duplicated pairs
            for c in list(g):
                if c.endswith("a"):
                    continue
                g[c] = [x for x in g[c] if rng.random() > p.frac_loss]
        n = sum(len(v) for v in g.values())
        chrs = list(g)

        def pick():
            c = rng.choice(chrs)
            while not g[c]:
                c = rng.choice(chrs)
            return c, rng.randrange(len(g[c]))

        for _ in range(np.random.default_rng(rng.randrange(1 << 30)).poisson(p.loss * n * L)):
            c, i = pick()
            g[c].pop(i)
        for _ in range(np.random.default_rng(rng.randrange(1 << 30)).poisson(p.tandem * n * L)):
            c, i = pick()
            tt = rng.uniform(t0, t1)
            g[c].insert(i + 1, self._copy(g[c][i], tt))
        for _ in range(np.random.default_rng(rng.randrange(1 << 30)).poisson(p.transposed * n * L)):
            c, i = pick()
            tt = rng.uniform(t0, t1)
            new = self._copy(g[c][i], tt, locus=self._new_locus())
            c2, j = pick()
            g[c2].insert(j, new)
        for _ in range(np.random.default_rng(rng.randrange(1 << 30)).poisson(p.novel * n * L)):
            c, j = pick()
            fam = self._new_family()
            uid = self._new_uid()
            g[c].insert(j, Gene(uid, self._new_locus(), fam, ((rng.uniform(t0, t1), uid),), rng.choice("+-")))
        for _ in range(np.random.default_rng(rng.randrange(1 << 30)).poisson(p.inversions * L * len(chrs) / 6)):
            c = rng.choice(chrs)
            if len(g[c]) < 40:
                continue
            a = rng.randrange(len(g[c]) - 30)
            b = a + rng.randint(5, 30)
            seg = g[c][a:b][::-1]
            for x in seg:
                x.strand = "-" if x.strand == "+" else "+"
            g[c][a:b] = seg
        for _ in range(np.random.default_rng(rng.randrange(1 << 30)).poisson(p.translocations * L * len(chrs) / 6)):
            c, c2 = rng.choice(chrs), rng.choice(chrs)
            if len(g[c]) < 40:
                continue
            a = rng.randrange(len(g[c]) - 30)
            b = a + rng.randint(8, 30)
            seg = g[c][a:b]
            del g[c][a:b]
            j = rng.randrange(len(g[c2]) + 1)
            g[c2][j:j] = seg
        n_shuffle = (np.random.default_rng(rng.randrange(1 << 30)).poisson(p.shuffle * n * L)
                     if p.shuffle > 0 else 0)  # no draw when off: old seeds stay reproducible
        for _ in range(n_shuffle):
            c, i = pick()
            x = g[c].pop(i)
            c2 = rng.choice(chrs)
            g[c2].insert(rng.randrange(len(g[c2]) + 1), x)
        return {c: v for c, v in g.items() if v}

    # ------------------------------------------------------------ truth
    def node_counts(self) -> pd.DataFrame:
        rows = {}
        for name, gen in self.genomes.items():
            cnt: Dict[str, int] = {}
            for v in gen.values():
                for x in v:
                    cnt[x.locus] = cnt.get(x.locus, 0) + 1
            rows[name] = cnt
        return pd.DataFrame(rows).fillna(0).astype(int)

    def family_node_counts(self) -> pd.DataFrame:
        rows = {}
        for name, gen in self.genomes.items():
            cnt: Dict[str, int] = {}
            for v in gen.values():
                for x in v:
                    cnt[x.family] = cnt.get(x.family, 0) + 1
            rows[name] = cnt
        return pd.DataFrame(rows).fillna(0).astype(int)

    # ------------------------------------------------------------ write
    def write(self, out: str) -> Dict[str, str]:
        p, rng = self.p, self.rng
        leaves = self.tree.leaf_names
        res = os.path.join(out, "OrthoFinder", "Results_sim")
        wd = os.path.join(res, "WorkingDirectory")
        for d in ("Phylogenetic_Hierarchical_Orthogroups", "Orthogroups", "Species_Tree"):
            os.makedirs(os.path.join(res, d), exist_ok=True)
        os.makedirs(wd, exist_ok=True)
        for d in ("bed", "genome", "proteome", "truth"):
            os.makedirs(os.path.join(out, d), exist_ok=True)
        truth, annotated = [], {}
        for sp in leaves:
            gen = self.genomes[sp]
            drop_rate = p.unannotated.get(sp, 0.0)
            gaps = p.gaps.get(sp, 0)
            gap_idx = set()
            allg = [(c, i, x) for c, v in gen.items() for i, x in enumerate(v)]
            for _ in range(gaps):
                c, i, _x = rng.choice(allg)
                for k in range(i, min(i + p.gap_genes, len(gen[c]))):
                    gap_idx.add((c, k))
            bed, seqs, keep = [], {}, []
            for c, v in gen.items():
                pos = 1000
                chunks = []
                for i, x in enumerate(v):
                    s, e = pos, pos + 1500
                    name = f"{sp}_g{x.uid}"
                    in_gap = (c, i) in gap_idx
                    unann = (not in_gap) and rng.random() < drop_rate
                    truth.append((sp, name, x.locus, x.family, c, i, not (in_gap or unann), in_gap))
                    if not (in_gap or unann):
                        bed.append((c, s, e, name, 0, x.strand))
                        keep.append((name, x))
                    chunks.append((s, e, in_gap))
                    pos = e + 1000
                L = pos + 1000
                seq = bytearray(np.random.default_rng(rng.randrange(1 << 30)).choice(
                    np.frombuffer(b"ACGT", dtype=np.uint8), L).tobytes())
                for s, e, ing in chunks:
                    if ing:
                        seq[s - 500:e + 500] = b"N" * (e - s + 1000)
                seqs[c] = seq.decode()
            annotated[sp] = keep
            with open(os.path.join(out, "bed", f"{sp}.bed"), "w") as o:
                for r in bed:
                    o.write("\t".join(map(str, r)) + "\n")
            with open(os.path.join(out, "genome", f"{sp}.fa"), "w") as o:
                for c, s in seqs.items():
                    o.write(f">{c}\n")
                    for k in range(0, len(s), 80):
                        o.write(s[k:k + 80] + "\n")
            with open(os.path.join(out, "proteome", f"{sp}.fa"), "w") as o:
                for name, x in keep:
                    o.write(f">{name}.1\n{'M' + 'A' * (self.plen[x.family] - 1)}\n")
        pd.DataFrame(truth, columns=["species", "gene", "locus", "family", "chr", "rank",
                                     "annotated", "in_gap"]).to_csv(
            os.path.join(out, "truth", "genes.tsv.gz"), sep="\t", index=False)
        self.node_counts().to_csv(os.path.join(out, "truth", "locus_node_counts.tsv.gz"), sep="\t")
        self.family_node_counts().to_csv(os.path.join(out, "truth", "family_node_counts.tsv.gz"), sep="\t")
        with open(os.path.join(out, "truth", "tree.nwk"), "w") as o:
            o.write(self.tree.to_newick() + "\n")
        self._write_orthofinder(res, wd, annotated)
        return {"results": res, "bed_dir": os.path.join(out, "bed"),
                "genome_dir": os.path.join(out, "genome"), "proteome_dir": os.path.join(out, "proteome")}

    def _write_orthofinder(self, res, wd, annotated):
        leaves = self.tree.leaf_names
        rng = self.rng
        with open(os.path.join(res, "Species_Tree", "SpeciesTree_rooted_node_labels.txt"), "w") as o:
            o.write(self.tree.to_newick() + "\n")
        sid = {sp: i for i, sp in enumerate(leaves)}
        with open(os.path.join(wd, "SpeciesIDs.txt"), "w") as o:
            for sp, i in sid.items():
                o.write(f"{i}: {sp}.fa\n")
        iid: Dict[str, Dict[str, str]] = {}
        with open(os.path.join(wd, "SequenceIDs.txt"), "w") as o:
            for sp in leaves:
                iid[sp] = {}
                for j, (name, x) in enumerate(annotated[sp]):
                    iid[sp][name] = f"{sid[sp]}_{j}"
                    o.write(f"{sid[sp]}_{j}: {name}.1\n")
        # families -> N0.tsv (multi-gene) + unassigned (single gene)
        members: Dict[str, Dict[str, List[str]]] = {}
        for sp in leaves:
            for name, x in annotated[sp]:
                members.setdefault(x.family, {}).setdefault(sp, []).append(name + ".1")
        multi = {f: m for f, m in members.items() if sum(len(v) for v in m.values()) > 1}
        single = {f: m for f, m in members.items() if f not in multi}
        rows = []
        for k, (f, m) in enumerate(sorted(multi.items())):
            rows.append([f"N0.HOG{k:07d}", f"OG{k:07d}", "n0"] + [", ".join(m.get(sp, [])) for sp in leaves])
        pd.DataFrame(rows, columns=["HOG", "OG", "Gene Tree Parent Clade"] + leaves).to_csv(
            os.path.join(res, "Phylogenetic_Hierarchical_Orthogroups", "N0.tsv"), sep="\t", index=False)
        ogrows = [[r[1]] + r[3:] for r in rows]
        pd.DataFrame(ogrows, columns=["Orthogroup"] + leaves).to_csv(
            os.path.join(res, "Orthogroups", "Orthogroups.tsv"), sep="\t", index=False)
        urows = []
        for k, (f, m) in enumerate(sorted(single.items())):
            urows.append([f"OG{len(rows) + k:07d}"] + [", ".join(m.get(sp, [])) for sp in leaves])
        pd.DataFrame(urows, columns=["Orthogroup"] + leaves).to_csv(
            os.path.join(res, "Orthogroups", "Orthogroups_UnassignedGenes.tsv"), sep="\t", index=False)
        self.fam_to_hog = {f: r[0] for f, r in zip(sorted(multi), rows)}
        self.fam_to_hog.update({f: r[0] for f, r in zip(sorted(single), urows)})
        # hits
        by_fam: Dict[str, Dict[str, List[Tuple[str, Gene]]]] = {}
        for sp in leaves:
            for name, x in annotated[sp]:
                by_fam.setdefault(x.family, {}).setdefault(sp, []).append((name, x))
        for a in leaves:
            for b in leaves:
                lines = []
                bl = annotated[b]
                for name, x in annotated[a]:
                    cands = by_fam.get(x.family, {}).get(b, [])
                    hs = []
                    for n2, y in cands:
                        pid = 100.0 if n2 == name else self._pident(x, y)
                        bits = pid / 100 * self.plen[x.family] * 1.9
                        hs.append((bits, pid, n2))
                    hs.sort(reverse=True)
                    hs = hs[:6]
                    if bl and rng.random() < self.p.spurious:
                        n2, y = bl[rng.randrange(len(bl))]
                        if y.family != x.family:
                            hs.append((45.0, 28.0, n2))
                    for bits, pid, n2 in hs:
                        ev = 10 ** (-min(180, bits / 3))
                        alen = self.plen[x.family]
                        lines.append(f"{iid[a][name]}\t{iid[b][n2]}\t{pid:.1f}\t{alen}\t0\t0\t1\t{alen}"
                                     f"\t1\t{alen}\t{ev:.2e}\t{bits:.1f}\n")
                with gzip.open(os.path.join(wd, f"Blast{sid[a]}_{sid[b]}.txt.gz"), "wt") as o:
                    o.writelines(lines)

    def _pident(self, x: Gene, y: Gene) -> float:
        tc = -30.0
        for (t1, u1), (t2, u2) in zip(x.anc, y.anc):
            if u1 == u2:
                tc = t1
            else:
                break
        if x.anc[0][1] != y.anc[0][1]:  # different ancient lineage
            tc = -30.0
        else:
            # coalescence: last shared lineage id; its *end* is the next split
            k = 0
            while k < min(len(x.anc), len(y.anc)) and x.anc[k][1] == y.anc[k][1]:
                k += 1
            tc = min(x.anc[k][0] if k < len(x.anc) else 10, y.anc[k][0] if k < len(y.anc) else 10)
        T = 10.0
        div = 2 * (T - tc)
        pid = 100 * math.exp(-self.p.decay * div) + self.rng.gauss(0, 1.5)
        return max(25.0, min(99.5, pid))
