"""Command-line interface for GeneLegume."""
from __future__ import annotations

import re
from functools import wraps

import click

from . import __version__
from . import config as cfgmod
from . import pipeline


@click.group(help="Gene presence/absence and expansion/contraction from synteny + homology.")
@click.version_option(__version__)
def main():
    pass


def _workflow_options(command):
    input_dir = click.Path(exists=True, file_okay=False, resolve_path=True)
    output_dir = click.Path(file_okay=False, resolve_path=True)

    @click.option("-c", "--config", type=click.Path(exists=True, dir_okay=False),
                  help="YAML config for custom analysis settings.")
    @click.option("--orthofinder", type=input_dir, help="OrthoFinder Results directory.")
    @click.option("--annotations", type=input_dir,
                  help="Directory of <species>.bed or <species>.gff3 files (gzip supported).")
    @click.option("--orthofinder-workdir", type=input_dir,
                  help="OrthoFinder WorkingDirectory if it is outside Results.")
    @click.option("--genome-dir", type=input_dir, help="Optional <species>.fa[.gz] files for gap checks.")
    @click.option("--workdir", type=output_dir, help="Output directory (default: genelegume_out).")
    @click.option("--scope", nargs=2, metavar="SPECIES_A SPECIES_B",
                  help="Limit synteny to the clade of these two tree leaves.")
    @click.option("--id-strip", help="Regex to remove from protein IDs if an exact match fails.")
    @click.option("-t", "--threads", type=click.IntRange(min=1), help="Number of workers.")
    @click.option("--evidence-mode", type=click.Choice(["weighted", "synteny_first"]),
                  help="How synteny and homology are combined (default: weighted).")
    @click.option("--alpha", help="Synteny weight per genome pair: coverage, smooth, rbk or a number 0-1.")
    @wraps(command)
    def run_step(config, annotations, scope, evidence_mode, alpha, **options):
        if config is None and (options["orthofinder"] is None or annotations is None):
            raise click.UsageError("Provide --orthofinder and --annotations, or use --config.")
        overrides = {key: value for key, value in options.items() if value is not None}
        if annotations is not None:
            overrides.update(bed_dir=annotations, gff_dir=annotations)
        if scope is not None:
            overrides["synteny"] = {"scope": scope}
        ev = {}
        if evidence_mode:
            ev["mode"] = evidence_mode
        if alpha:
            try:
                ev["alpha"] = float(alpha)
            except ValueError:
                if alpha not in ("coverage", "smooth", "rbk"):
                    raise click.BadParameter("coverage, smooth, rbk or a number", param_hint="--alpha")
                ev["alpha"] = alpha
        if ev:
            overrides["evidence"] = ev
        if config is None or annotations is not None:
            overrides["require_annotations"] = True
        try:
            cfg = cfgmod.load(config, overrides=overrides)
            command(cfg)
        except (OSError, ValueError, re.error) as exc:
            raise click.ClickException(str(exc)) from exc

    return run_step


@main.command(help="Read OrthoFinder families, match annotation IDs, and check the species tree.")
@_workflow_options
def prepare(cfg):
    pipeline.step_prepare(cfg)


@main.command(help="Collinear blocks for all genome pairs in the synteny scope (resumable).")
@_workflow_options
def synteny(cfg):
    pipeline.step_synteny(cfg)


@main.command(help="Local clusters, duplication modes, HOCs and zero-cell classification.")
@_workflow_options
def hoc(cfg):
    pipeline.step_hoc(cfg)


@main.command(help="Ancestral reconstruction and event calling (family + HOC level).")
@_workflow_options
def recon(cfg):
    pipeline.step_recon(cfg)


@main.command(help="Run prepare, synteny, hoc and recon.")
@_workflow_options
def run(cfg):
    pipeline.run_all(cfg)


@main.command("setup", help="Find annotation/genome/proteome in per-species folders and write a config.")
@click.option("--orthofinder", required=True, type=click.Path(exists=True, file_okay=False, resolve_path=True),
              help="OrthoFinder Results directory.")
@click.option("--species-root", required=True, type=click.Path(exists=True, file_okay=False, resolve_path=True),
              help="Directory holding one folder per species (<root>/<species>/...).")
@click.option("--proteome-dir", type=click.Path(exists=True, file_okay=False, resolve_path=True),
              help="OrthoFinder input FASTA directory (default: two levels above Results).")
@click.option("-o", "--out", default="genelegume.yaml", show_default=True, help="Config to write.")
@click.option("--workdir", default="genelegume_out", show_default=True, help="workdir written into the config.")
@click.option("--report", default="setup_report.tsv", show_default=True, help="Per-species choices.")
@click.option("--folder-map", type=click.Path(exists=True, dir_okay=False),
              help="TSV: OrthoFinder species name <TAB> folder (name under --species-root or a path).")
@click.option("-t", "--threads", type=click.IntRange(min=1), default=4, show_default=True)
def setup(orthofinder, species_root, proteome_dir, out, workdir, report, folder_map, threads):
    from .setup_inputs import run_setup
    fmap = None
    if folder_map:
        fmap = {}
        with open(folder_map) as fh:
            for line in fh:
                f = line.rstrip("\n").split("\t")
                if len(f) >= 2 and f[0] and not f[0].startswith("#"):
                    fmap[f[0].strip()] = f[1].strip()
    try:
        run_setup(orthofinder, species_root, out, proteome_dir, workdir, threads, report,
                  log=click.echo, folder_map=fmap)
    except (OSError, ValueError) as exc:
        raise click.ClickException(str(exc)) from exc


@main.command("subgenomes", help="Split allopolyploids into subgenome leaves (chromosomes assigned by best "
                                   "hits to the diploid progenitors) and write a config + tree.")
@click.option("-c", "--config", "cfg_path", required=True, type=click.Path(exists=True, dir_okay=False),
              help="Config without subgenomes (e.g. from genelegume setup).")
@click.option("--polyploid", "polyploids", multiple=True, required=True,
              help="OrthoFinder species name of a polyploid; repeat for several (split together).")
@click.option("--progenitor", "progenitors", multiple=True, required=True,
              help="LABEL=species, e.g. A=Arachis_duranensis; repeat once per subgenome.")
@click.option("-o", "--out", required=True, help="New config to write.")
def subgenomes(cfg_path, polyploids, progenitors, out):
    from .polyploid import run_subgenomes
    prog = {}
    for x in progenitors:
        if "=" not in x:
            raise click.BadParameter(f"{x}: use LABEL=species", param_hint="--progenitor")
        k, v = x.split("=", 1)
        prog[k.strip()] = v.strip()
    try:
        run_subgenomes(cfg_path, list(polyploids), prog, out, log=click.echo)
    except (OSError, ValueError) as exc:
        raise click.ClickException(str(exc)) from exc


@main.command("gff2bed", help="GFF3 -> BED of the longest mRNA per gene.")
@click.argument("gff3")
@click.argument("out_bed")
@click.option("--feature", default="mRNA")
@click.option("--id-attr", default="ID")
def gff2bed(gff3, out_bed, feature, id_attr):
    from .io_genome import gff3_to_bed
    n = gff3_to_bed(gff3, out_bed, feature, id_attr)
    click.echo(f"{n} records")


@main.command("show-tree", help="Print the species tree with node names (use them for WGD placement).")
@click.argument("newick")
def show_tree(newick):
    from .tree import Tree
    t = Tree.from_file(newick)
    click.echo(t.to_newick())
    for n in t.nodes:
        if not n.is_leaf:
            click.echo(f"{n.name}\t{len(t.leaves_under(n.name))} leaves\t"
                       + ",".join(sorted(t.leaves_under(n.name))[:4]) + ("..." if len(t.leaves_under(n.name)) > 4 else ""))


@main.command(help="Simulate genomes + OrthoFinder-format results with known truth.")
@click.option("-o", "--out", required=True)
@click.option("--seed", default=7, type=int)
@click.option("--genes-per-chr", default=150, type=int)
@click.option("--shuffle", default=0.0, type=float,
              help="Single-gene relocations per gene per time unit (erodes synteny, keeps the locus).")
def simulate(out, seed, genes_per_chr, shuffle):
    import yaml
    from .simulate import Sim, SimParams
    Sim(p=SimParams(seed=seed, genes_per_chr=genes_per_chr, shuffle=shuffle)).run().write(out)
    cfg = {"orthofinder": "OrthoFinder/Results_sim", "workdir": "out", "threads": 2,
           "bed_dir": "bed", "genome_dir": "genome", "proteome_dir": "proteome",
           "id_strip": r"\.1$", "synteny": {"scope": ["Gmax", "Vvin"]},
           "wgd": [{"mrca": ["Gmax", "Mtru"], "multiplier": 2, "name": "papilionoid"},
                   {"mrca": ["Gmax", "Gsoj"], "multiplier": 2, "name": "Glycine"}]}
    with open(f"{out}/config.yaml", "w") as o:
        yaml.safe_dump(cfg, o, sort_keys=False)
    click.echo(f"wrote {out}/ ; run: genelegume run -c {out}/config.yaml ; "
               f"then: genelegume evaluate -s {out}")


@main.command(help="Score a run on simulated data against the simulation truth.")
@click.option("-s", "--sim-dir", required=True)
@click.option("-w", "--workdir", default=None, help="default <sim-dir>/out")
def evaluate(sim_dir, workdir):
    import json
    from .evaluate import evaluate as ev
    r = ev(sim_dir, workdir or f"{sim_dir}/out", {"Papi": 2, "Glyc": 2}, "Eud")
    click.echo(json.dumps(r, indent=1, default=str))


@main.command(help="Multi-seed benchmark on simulated data (scenarios x evidence modes).")
@click.option("-o", "--out", required=True, help="Output directory.")
@click.option("--seeds", default="1-5", show_default=True, help="e.g. 1-5 or 1,4,9")
@click.option("--scenarios", default="default,eroded", show_default=True,
              help="Comma list from: default, eroded, eroded_strong.")
@click.option("--methods", default="synteny_first,weighted", show_default=True,
              help="Comma list from: synteny_first, weighted, weighted_rbk, weighted_smooth.")
@click.option("--genes-per-chr", default=150, type=int, show_default=True)
@click.option("-t", "--threads", default=2, type=click.IntRange(min=1), show_default=True)
@click.option("--keep", is_flag=True, help="Keep every run's work directory.")
def benchmark(out, seeds, scenarios, methods, genes_per_chr, threads, keep):
    from .benchmark import METHODS, SCENARIOS, run_benchmark
    seed_list = []
    for part in seeds.split(","):
        a, _, b = part.partition("-")
        seed_list += list(range(int(a), int(b) + 1)) if b else [int(a)]
    scs, ms = scenarios.split(","), methods.split(",")
    bad = [x for x in scs if x not in SCENARIOS] + [x for x in ms if x not in METHODS]
    if bad:
        raise click.UsageError(f"unknown scenario/method: {bad}")
    summ = run_benchmark(out, seed_list, scs, ms, threads, genes_per_chr, keep=keep, log=click.echo)
    cols = [c for c in summ.columns if c.endswith("_mean") and any(
        k in c for k in ("hoc_pair", "absent", "internal", "loss_precision", "gain_precision"))]
    click.echo(summ[cols].round(3).to_string())
    click.echo(f"wrote {out}/runs.tsv and {out}/summary.tsv")


if __name__ == "__main__":
    main()
