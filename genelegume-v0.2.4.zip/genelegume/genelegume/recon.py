"""Ancestral copy-number reconstruction on an arbitrary rooted tree.

Weighted Sankoff parsimony over integer copy-number states, vectorised over
all units (gene families or HOCs). Compared with GoldMiner's OdlRecon:

* any rooted, multifurcating topology (no fixed 10 groups, no ladder tree);
* missing data (NA) at leaves is a wildcard instead of being read as 0;
* whole-genome duplications are placed on branches: on such a branch a parent
  with i copies is *expected* to give i*m copies, so keeping WGD copies is not
  an "expansion" and losing them is cheap "fractionation".

Branch cost c(i -> j) with e = i*m (m = WGD multiplier of the branch, 1 if none)
    i == 0, j  > 0 : gain + dup*(j-1)
    i  > 0, j == 0 : loss + frac*(e-i) + shrink*(i-1)
    j > e          : dup*(j-e)
    i <= j <= e    : frac*(e-j)
    0 < j < i      : frac*(e-i) + shrink*(i-j)
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from .tree import Tree

BUCKETS = [2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048]


@dataclass
class Costs:
    gain: float = 3.0
    loss: float = 1.0
    dup: float = 2.0
    shrink: float = 1.0
    frac: float = 0.25
    root_gain: Optional[float] = 1.0  # cost of presence at the root (None = same as gain)
    tie_eps: float = 1e-4  # prefers "no change" among equal-cost choices


def cost_matrix(K: int, m: int, c: Costs) -> np.ndarray:
    i = np.arange(K)[:, None].astype(float)
    j = np.arange(K)[None, :].astype(float)
    e = i * m
    C = np.zeros((K, K))
    gain = (i == 0) & (j > 0)
    loss = (i > 0) & (j == 0)
    up = (i > 0) & (j > e)
    mid = (i > 0) & (j >= i) & (j <= e)
    down = (i > 0) & (j > 0) & (j < i)
    C[gain] = (c.gain + c.dup * (j - 1) + 0 * i)[gain]
    C[loss] = (c.loss + c.frac * (e - i) + c.shrink * (i - 1) + 0 * j)[loss]
    C[up] = (c.dup * (j - e))[up]
    C[mid] = (c.frac * (e - j))[mid]
    C[down] = (c.frac * (e - i) + c.shrink * (i - j))[down]
    C += c.tie_eps * np.abs(j - e)
    return C


@dataclass
class ReconResult:
    states: pd.DataFrame           # unit x node (all nodes, postorder), int; leaves keep -1 for NA
    events: pd.DataFrame           # unit, node, parent, p, c, event, delta
    cost: pd.Series                # parsimony cost per unit
    leaf_na: pd.DataFrame = field(default=None)
    ambiguous: pd.DataFrame = field(default=None)  # unit x node: another state was (nearly) as cheap


def reconstruct(counts: pd.DataFrame, tree: Tree, wgd: Optional[Dict[str, int]] = None,
                costs: Costs = Costs(), chunk_cells: int = 20_000_000) -> ReconResult:
    """counts: units x leaf names; NaN = missing data. Extra/absent leaves raise."""
    wgd = wgd or {}
    leaves = tree.leaf_names
    missing = [l for l in leaves if l not in counts.columns]
    if missing:
        raise ValueError(f"tree leaves without a count column: {missing[:10]}")
    for k in wgd:
        if k not in tree.by_name:
            raise ValueError(f"WGD placed on unknown node {k!r}")
    X = counts[leaves].to_numpy(dtype=float)
    units = counts.index.to_numpy()
    mx = np.nan_to_num(X, nan=0).max(axis=1) if len(X) else np.zeros(0)
    state_all = np.full((len(units), len(tree.nodes)), -1, dtype=np.int64)
    amb_all = np.zeros((len(units), len(tree.nodes)), dtype=bool)
    cost_all = np.zeros(len(units))
    lo = 0
    for K in BUCKETS:
        sel = np.where((mx < K) & (mx >= lo))[0]
        lo = K
        if len(sel) == 0:
            continue
        step = max(1, chunk_cells // (K * K))
        for s0 in range(0, len(sel), step):
            ids = sel[s0:s0 + step]
            st, cst, amb = _sankoff(X[ids], tree, wgd, costs, K)
            state_all[ids] = st
            amb_all[ids] = amb
            cost_all[ids] = cst
    if len(mx) and mx.max() >= BUCKETS[-1]:
        raise ValueError("copy number above supported maximum")
    names = [n.name for n in tree.nodes]
    states = pd.DataFrame(state_all, index=units, columns=names)
    # leaf states at NA leaves are imputations; the mask is returned alongside
    na = np.isnan(X)
    leaf_na = pd.DataFrame(na, index=units, columns=leaves)
    ambiguous = pd.DataFrame(amb_all, index=units, columns=names)
    events = call_events(states, tree, wgd, leaf_na, ambiguous)
    return ReconResult(states, events, pd.Series(cost_all, index=units), leaf_na, ambiguous)


def _sankoff(X: np.ndarray, tree: Tree, wgd: Dict[str, int], costs: Costs, K: int):
    n = X.shape[0]
    INF = 1e12
    S: Dict[int, np.ndarray] = {}
    Cm: Dict[int, np.ndarray] = {}
    for node in tree.nodes:  # postorder
        if node.parent is not None:
            Cm[node.idx] = cost_matrix(K, int(wgd.get(node.name, 1)), costs)
        if node.is_leaf:
            col = tree.leaf_names.index(node.name)
            v = X[:, col]
            s = np.full((n, K), INF)
            na = np.isnan(v)
            s[na] = 0.0
            obs = (~na).nonzero()[0]
            s[obs, v[obs].astype(int)] = 0.0
            S[node.idx] = s
        else:
            acc = np.zeros((n, K))
            for ch in node.children:
                acc += (Cm[ch.idx][None, :, :] + S[ch.idx][:, None, :]).min(axis=2)
            S[node.idx] = acc
    root = tree.root
    root_cost = cost_matrix(K, 1, costs)[0].copy()
    if costs.root_gain is not None:
        root_cost[1:] += costs.root_gain - costs.gain
    tot = S[root.idx] + root_cost[None, :]
    st = np.zeros((n, len(tree.nodes)), dtype=np.int64)
    amb = np.zeros((n, len(tree.nodes)), dtype=bool)
    # a state choice is ambiguous when another state is within half the
    # smallest event cost (tie_eps only orders otherwise equal choices)
    pos = [c for c in (costs.gain, costs.loss, costs.dup, costs.shrink, costs.frac) if c > 0]
    tol = 0.5 * min(pos) if pos else 1e-6

    def pick(v):
        best = v.min(axis=1)
        return v.argmin(axis=1), ((v <= best[:, None] + tol).sum(axis=1) > 1)

    st[:, root.idx], amb[:, root.idx] = pick(tot)
    cost = tot.min(axis=1)
    for node in tree.preorder():
        for ch in node.children:
            p = st[:, node.idx]
            st[:, ch.idx], amb[:, ch.idx] = pick(Cm[ch.idx][p] + S[ch.idx])
    return st, cost, amb


def classify(p: np.ndarray, c: np.ndarray, m: int) -> np.ndarray:
    e = p * m
    ev = np.full(p.shape, "", dtype=object)
    ev[(p == 0) & (c > 0)] = "gain"
    ev[(p > 0) & (c == 0)] = "loss"
    ev[(p > 0) & (c > e)] = "expansion"
    ev[(p > 0) & (c > 0) & (c < p)] = "contraction"
    if m > 1:
        ev[(p > 0) & (c > p) & (c <= e)] = "wgd_retention"
        ev[(p > 0) & (c == p)] = "wgd_fractionation"
    return ev


def call_events(states: pd.DataFrame, tree: Tree, wgd: Dict[str, int],
                leaf_na: Optional[pd.DataFrame] = None,
                ambiguous: Optional[pd.DataFrame] = None) -> pd.DataFrame:
    """One row per (unit, branch) with a non-trivial event. Branches into NA
    leaves are skipped (the leaf state there is only an imputation).
    ``ambiguous`` is True when the state of either end of the branch had an
    (almost) equally parsimonious alternative."""
    out = []
    S = states.to_numpy()
    A = ambiguous.to_numpy() if ambiguous is not None else np.zeros(S.shape, dtype=bool)
    units = states.index.to_numpy()
    for node in tree.nodes:
        if node.parent is None:
            r = S[:, node.idx]
            m = r > 0
            out.append(pd.DataFrame({"unit": units[m], "node": node.name, "parent": "",
                                     "p": 0, "c": r[m], "event": "gain", "delta": r[m],
                                     "ambiguous": A[m, node.idx]}))
            continue
        mult = int(wgd.get(node.name, 1))
        p = S[:, node.parent.idx]
        c = S[:, node.idx]
        ev = classify(p, c, mult)
        keep = ev != ""
        if node.is_leaf and leaf_na is not None:
            keep &= ~leaf_na[node.name].to_numpy()
        if not keep.any():
            continue
        e = p * mult
        delta = np.where(ev == "gain", c, np.where(ev == "loss", -p,
                np.where(ev == "expansion", c - e, np.where(ev == "wgd_retention", c - p,
                np.where(ev == "wgd_fractionation", -(e - p), c - p)))))
        amb = A[:, node.idx] | A[:, node.parent.idx]
        out.append(pd.DataFrame({"unit": units[keep], "node": node.name, "parent": node.parent.name,
                                 "p": p[keep], "c": c[keep], "event": ev[keep], "delta": delta[keep],
                                 "ambiguous": amb[keep]}))
    if not out:
        return pd.DataFrame(columns=["unit", "node", "parent", "p", "c", "event", "delta", "ambiguous"])
    return pd.concat(out, ignore_index=True)


def branch_summary(events: pd.DataFrame, tree: Tree) -> pd.DataFrame:
    """Count of units per branch and event type (rows in postorder)."""
    if events.empty:
        return pd.DataFrame(index=[n.name for n in tree.nodes])
    tab = events.pivot_table(index="node", columns="event", values="unit", aggfunc="count", fill_value=0)
    tab = tab.reindex([n.name for n in tree.nodes], fill_value=0)
    cols = [c for c in ["gain", "loss", "expansion", "contraction", "wgd_retention",
                        "wgd_fractionation"] if c in tab.columns]
    tab = tab[cols]
    tab.insert(0, "n_leaves_below", [len(tree.leaves_under(n)) for n in tab.index])
    if "ambiguous" in events.columns:
        amb = events[events["ambiguous"].astype(bool)].groupby("node").size()
        tab["n_ambiguous"] = amb.reindex(tab.index, fill_value=0).astype(int)
    return tab


def origin_table(states: pd.DataFrame, tree: Tree) -> pd.DataFrame:
    """Origin node(s) per unit: nodes with state > 0 whose parent has 0
    (or the root). ``n_origins`` > 1 flags convergent gains / HGT /
    misassigned families."""
    S = states.to_numpy()
    rows = []
    origins: Dict[int, List[str]] = {}
    for node in tree.nodes:
        c = S[:, node.idx] > 0
        p = np.ones_like(c) if node.parent is None else S[:, node.parent.idx] == 0
        hit = np.where(c & p)[0]
        for h in hit:
            origins.setdefault(h, []).append(node.name)
    for i, u in enumerate(states.index):
        o = origins.get(i, [])
        rows.append((u, ";".join(o) if o else ".", len(o)))
    return pd.DataFrame(rows, columns=["unit", "origin", "n_origins"]).set_index("unit")


def aggregate_accessions(counts: pd.DataFrame, groups: Dict[str, List[str]],
                         min_freq: float = 0.5) -> (pd.DataFrame, pd.DataFrame):
    """Collapse several accessions per species into one leaf value.

    Present if the fraction of (non-NA) accessions with >=1 copy is >= min_freq;
    copy number = median of non-zero counts. Returns (leaf_counts, presence_freq).
    Unlike GoldMiner (median of non-zero genomes only), a gene seen in 1/20
    accessions is not called present for the whole species.
    """
    leaf, freq = {}, {}
    for sp, accs in groups.items():
        sub = counts[accs]
        nn = sub.notna().sum(axis=1)
        pres = (sub > 0).sum(axis=1)
        f = pres / nn.replace(0, np.nan)
        med = sub.where(sub > 0).median(axis=1).round()
        val = np.where(f >= min_freq, med, 0.0)
        val = np.where(nn == 0, np.nan, val)
        leaf[sp] = val
        freq[sp] = f
    return (pd.DataFrame(leaf, index=counts.index), pd.DataFrame(freq, index=counts.index))


def to_cafe(counts: pd.DataFrame, out: str, excluded: Optional[str] = None,
            desc: Optional[pd.Series] = None) -> Tuple[int, int]:
    """Write a CAFE5 count table.

    CAFE5 has no missing-data code, and writing NA as 0 would turn missing
    data back into losses. Units with any NA are therefore left out of the
    table (and listed in ``excluded``). Returns (n written, n excluded).
    """
    na = counts.isna().any(axis=1)
    df = counts[~na].astype(int).copy()
    df.insert(0, "Family ID", df.index)
    df.insert(0, "Desc", desc.reindex(df.index).fillna("(null)") if desc is not None else "(null)")
    df.to_csv(out, sep="\t", index=False)
    if excluded is not None:
        counts[na].to_csv(excluded, sep="\t", na_rep="NA")
    return int((~na).sum()), int(na.sum())
