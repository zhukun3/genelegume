"""read_gff: matching OrthoFinder protein names across common annotation styles."""
import gzip

from genelegume.io_genome import read_gff


def _write(tmp_path, name, rows, gz=False):
    p = tmp_path / name
    text = "\n".join("\t".join(map(str, r)) for r in rows) + "\n"
    if gz:
        with gzip.open(p, "wt") as fh:
            fh.write(text)
    else:
        p.write_text(text)
    return str(p)


def _genes(gt):
    return dict(zip(gt.df["gene"], gt.df["start"]))


def test_phytozome_isoforms_and_strip(tmp_path):
    rows = [
        ("chr1", "x", "gene", 1, 900, ".", "+", ".", "ID=G1"),
        ("chr1", "x", "mRNA", 1, 900, ".", "+", ".", "ID=G1.1;Parent=G1"),
        ("chr1", "x", "mRNA", 1, 500, ".", "+", ".", "ID=G1.2;Parent=G1"),
        ("chr1", "x", "gene", 2001, 2900, ".", "-", ".", "ID=G2"),
        ("chr1", "x", "mRNA", 2001, 2900, ".", "-", ".", "ID=G2.1;Parent=G2"),
    ]
    p = _write(tmp_path, "a.gff3.gz", rows, gz=True)
    gt = read_gff(p, "A", ["G1.2.p", "G2.1.p"], r"\.p$")
    # one record per gene; the isoform OrthoFinder used wins over the longer one
    assert set(gt.df["gene"]) == {"G1.2.p", "G2.1.p"}
    assert len(gt) == 2


def test_proteins_named_by_gene_id(tmp_path):
    rows = [
        ("chr1", "x", "gene", 1, 900, ".", "+", ".", "ID=Ae01g0001;Name=Ae01g0001"),
        ("chr1", "x", "mRNA", 1, 900, ".", "+", ".", "ID=Ae01g0001.t1;Parent=Ae01g0001"),
        ("chr1", "x", "gene", 2001, 2900, ".", "+", ".", "ID=Ae01g0002"),
        ("chr1", "x", "mRNA", 2001, 2900, ".", "+", ".", "ID=Ae01g0002.t1;Parent=Ae01g0002"),
    ]
    gt = read_gff(_write(tmp_path, "b.gff3", rows), "B", ["Ae01g0001", "Ae01g0002"])
    assert _genes(gt) == {"Ae01g0001": 0, "Ae01g0002": 2000}


def test_ncbi_protein_id(tmp_path):
    rows = [
        ("NC_1", "Gnomon", "gene", 1, 900, ".", "+", ".", "ID=gene-LOC1;Name=LOC1"),
        ("NC_1", "Gnomon", "mRNA", 1, 900, ".", "+", ".",
         "ID=rna-XM_1.1;Parent=gene-LOC1;transcript_id=XM_1.1"),
        ("NC_1", "Gnomon", "CDS", 50, 800, ".", "+", "0",
         "ID=cds-XP_1.1;Parent=rna-XM_1.1;protein_id=XP_1.1"),
        ("NC_1", "Gnomon", "gene", 2001, 2900, ".", "+", ".", "ID=gene-LOC2"),
        ("NC_1", "Gnomon", "mRNA", 2001, 2900, ".", "+", ".", "ID=rna-XM_2.1;Parent=gene-LOC2"),
        ("NC_1", "Gnomon", "CDS", 2050, 2800, ".", "+", "0",
         "ID=cds-XP_2.1;Parent=rna-XM_2.1;protein_id=XP_2.1"),
    ]
    gt = read_gff(_write(tmp_path, "c.gff", rows), "C", ["XP_1.1", "XP_2.1"])
    assert set(gt.df["gene"]) == {"XP_1.1", "XP_2.1"}


def test_gtf(tmp_path):
    rows = [
        ("chr2", "x", "transcript", 1, 900, ".", "+", ".", 'gene_id "g1"; transcript_id "g1.t1";'),
        ("chr2", "x", "exon", 1, 900, ".", "+", ".", 'gene_id "g1"; transcript_id "g1.t1";'),
        ("chr2", "x", "CDS", 10, 800, ".", "+", "0", 'gene_id "g1"; transcript_id "g1.t1";'),
        ("chr2", "x", "exon", 2001, 2900, ".", "+", ".", 'gene_id "g2"; transcript_id "g2.t1";'),
        ("chr2", "x", "CDS", 2010, 2800, ".", "+", "0", 'gene_id "g2"; transcript_id "g2.t1";'),
    ]
    gt = read_gff(_write(tmp_path, "d.gtf", rows), "D", ["g1.t1", "g2"])
    # g1 from its transcript row; g2 has no transcript row -> built from exon/CDS
    assert _genes(gt) == {"g1.t1": 0, "g2": 2000}


def test_gene_and_cds_only(tmp_path):
    rows = [
        ("s1", "x", "gene", 1, 900, ".", "+", ".", "ID=E1"),
        ("s1", "x", "CDS", 1, 900, ".", "+", "0", "ID=E1.cds;Parent=E1"),
        ("s1", "x", "gene", 2001, 2900, ".", "+", ".", "ID=E2"),
        ("s1", "x", "CDS", 2001, 2900, ".", "+", "0", "ID=E2.cds;Parent=E2"),
    ]
    gt = read_gff(_write(tmp_path, "e.gff3", rows), "E", ["E1", "E2.cds"])
    assert set(gt.df["gene"]) == {"E1", "E2.cds"}


def test_unmatched_genes_keep_order(tmp_path):
    rows = [
        ("chr1", "x", "mRNA", 1, 900, ".", "+", ".", "ID=T1;Parent=G1"),
        ("chr1", "x", "mRNA", 1001, 1900, ".", "+", ".", "ID=T2;Parent=G2"),
        ("chr1", "x", "mRNA", 2001, 2900, ".", "+", ".", "ID=T3;Parent=G3"),
    ]
    gt = read_gff(_write(tmp_path, "f.gff3", rows), "F", ["T1", "T3"])
    assert list(gt.df["gene"]) == ["T1", "T2", "T3"]
    assert list(gt.df["idx"]) == [0, 1, 2]


def test_noncoding_transcripts_dropped(tmp_path):
    rows = [
        ("NC_1", "x", "gene", 1, 900, ".", "+", ".", "ID=gene-A"),
        ("NC_1", "x", "mRNA", 1, 900, ".", "+", ".", "ID=rna-A;Parent=gene-A"),
        ("NC_1", "x", "CDS", 10, 800, ".", "+", "0", "ID=cds-A;Parent=rna-A;protein_id=PA"),
        ("NC_1", "x", "gene", 1001, 1900, ".", "+", ".", "ID=gene-L"),
        ("NC_1", "x", "lnc_RNA", 1001, 1900, ".", "+", ".", "ID=rna-L;Parent=gene-L"),
        ("NC_1", "x", "exon", 1001, 1900, ".", "+", ".", "ID=exon-L;Parent=rna-L"),
        ("NC_1", "x", "gene", 2001, 2900, ".", "+", ".", "ID=gene-N"),
        ("NC_1", "x", "transcript", 2001, 2900, ".", "+", ".", "ID=rna-N;Parent=gene-N"),
        ("NC_1", "x", "exon", 2001, 2900, ".", "+", ".", "ID=exon-N;Parent=rna-N"),
    ]
    gt = read_gff(_write(tmp_path, "g.gff", rows), "G", ["PA"])
    assert list(gt.df["gene"]) == ["PA"]


def test_gwh_accessions(tmp_path):
    # NGDC Genome Warehouse style: proteins may be named by GWHP accession or by OriID
    rows = [
        ("GWHBHAK00000001", ".", "gene", 1, 900, ".", "+", ".",
         "ID=GWHGBHAK000001;Accession=GWHGBHAK000001;OriID=Cc01G0001"),
        ("GWHBHAK00000001", ".", "mRNA", 1, 900, ".", "+", ".",
         "ID=GWHTBHAK000001;Accession=GWHTBHAK000001;Parent=GWHGBHAK000001;"
         "OriID=Cc01G0001.1;Protein_Accession=GWHPBHAK000001"),
        ("GWHBHAK00000001", ".", "gene", 2001, 2900, ".", "+", ".",
         "ID=GWHGBHAK000002;Accession=GWHGBHAK000002;OriID=Cc01G0002"),
        ("GWHBHAK00000001", ".", "mRNA", 2001, 2900, ".", "+", ".",
         "ID=GWHTBHAK000002;Parent=GWHGBHAK000002;OriID=Cc01G0002.1"),
        ("GWHBHAK00000001", ".", "CDS", 2001, 2900, ".", "+", "0",
         "ID=GWHTBHAK000002.CDS1;Parent=GWHTBHAK000002;Protein_Accession=GWHPBHAK000002"),
    ]
    p = _write(tmp_path, "gwh.gff", rows)
    gt = read_gff(p, "C", ["GWHPBHAK000001", "GWHPBHAK000002"])
    assert set(gt.df["gene"]) == {"GWHPBHAK000001", "GWHPBHAK000002"}
    gt = read_gff(p, "C", ["Cc01G0001.1", "Cc01G0002"])
    assert set(gt.df["gene"]) == {"Cc01G0001.1", "Cc01G0002"}


def test_dbxref_split(tmp_path):
    rows = [("NC_1", "x", "mRNA", 1, 900, ".", "+", ".",
             "ID=rna-1;Parent=gene-1;Dbxref=GeneID:100,Genbank:XM_9.1")]
    gt = read_gff(_write(tmp_path, "h.gff", rows), "H", ["XM_9.1"])
    assert list(gt.df["gene"]) == ["XM_9.1"]
