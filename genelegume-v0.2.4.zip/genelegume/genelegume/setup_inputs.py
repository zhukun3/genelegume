"""`genelegume setup`: find each species' annotation, genome and proteome in
per-species folders, pick the right files by how well they match OrthoFinder,
and write a config with explicit per-species paths.

Layout handled: <species_root>/<species>/... (files at any depth <= 3, any names).
For every OrthoFinder species:

* annotation (.gff3/.gff/.gtf/.bed, gzip ok): every candidate is read with the
  same reader the pipeline uses; the one matching the most OrthoFinder protein
  names wins (exact names first, then with common transcript suffixes removed).
* genome: a nucleotide FASTA whose sequence names match the chosen annotation's
  chromosome names (CDS/transcript FASTA are recognised and skipped).
* proteome: the OrthoFinder input FASTA if present (names match by definition),
  otherwise the protein FASTA in the folder whose headers match best.
"""
from __future__ import annotations

import difflib
import gzip
import os
import re
import shutil
from concurrent.futures import ProcessPoolExecutor
from typing import Dict, List, Optional, Tuple

import yaml

from .io_genome import IdMapper, read_bed, read_gff
from .io_orthofinder import OrthoFinderResults, _strip_ext
from .tree import Tree

# transcript/protein suffixes, longest first (only used when an exact name fails)
STRIP_ALL = r"(\.\d+\.p\d*|\.p\d*|\.\d+|-P[A-Z]|-R[A-Z]|_P\d+|_T\d+|\.t\d+|\.mRNA\d*)$"

ANN_RX = re.compile(r"\.(gff3|gff|gtf|bed)(\.gz)?$", re.I)
FA_RX = re.compile(r"\.(fa|fasta|fna|fas|faa|pep|cds|ffn|aa|seq)(\.gz)?$", re.I)
SKIP_RX = re.compile(r"(repeat|edta|ltr|rmsk|[._-]te[._-]|teanno|trna|mirna|ncrna|snorna|"
                     r"rrna|lncrna|gap|busco|blast|diamond|interpro|kegg|swiss)", re.I)
MAX_CANDIDATES = 12

# WGD rules. Species are recognised by their Genus_species base name, so
# OrthoFinder names such as Glycine_max.Wm82 work. A clade rule is placed at the
# MRCA of all its species present and is kept only if that MRCA contains no
# other species (protects against a misrooted tree). Check against your references.
PAPILIONOID_GENERA = {
    "Aeschynomene", "Arachis", "Stylosanthes", "Dalbergia", "Pterocarpus", "Glycine",
    "Phaseolus", "Vigna", "Cajanus", "Lotus", "Medicago", "Trifolium", "Pisum", "Vicia",
    "Lens", "Cicer", "Lathyrus", "Astragalus", "Lupinus", "Cladrastis", "Sesbania",
    "Indigofera", "Abrus", "Mucuna", "Pueraria", "Amphicarpaea", "Sophora", "Styphnolobium",
    "Ammopiptanthus", "Castanospermum", "Dipteryx", "Robinia", "Wisteria", "Glycyrrhiza",
    "Melilotus", "Ormosia", "Spatholobus", "Apios", "Lablab", "Psophocarpus", "Macrotyloma"}
POACEAE_GENERA = {"Oryza", "Zea", "Sorghum", "Setaria", "Triticum", "Hordeum", "Brachypodium",
                  "Aegilops", "Secale", "Panicum", "Eragrostis", "Saccharum", "Phyllostachys"}
WGD_RULES = [
    {"name": "papilionoid", "genera": PAPILIONOID_GENERA, "multiplier": 2},
    {"name": "Glycine", "genera": {"Glycine"}, "multiplier": 2},
    {"name": "rho", "genera": POACEAE_GENERA, "multiplier": 2},
    {"name": "gamma", "mrca": ["Malania_oleifera", "Medicago_truncatula"], "multiplier": 3},
    {"name": "maize", "node": "Zea_mays", "multiplier": 2},
    {"name": "salicoid", "node": "Populus_trichocarpa", "multiplier": 2},
    {"name": "At_alpha_beta", "node": "Arabidopsis_thaliana", "multiplier": 4},
]


def place_wgd(tree: Optional[Tree], species: List[str],
              bases: Optional[Dict[str, str]] = None) -> Tuple[list, list]:
    """Return (wgd entries for the config, notes).

    ``bases`` gives the Genus_species for OrthoFinder names that do not carry
    it (e.g. S1979_T2T.gene.pep -> Stylosanthes_guianensis, from --folder-map).
    """
    bases = bases or {}

    def base_name(sp: str) -> str:  # noqa: F811 - local override with the mapping
        return bases.get(sp) or _base_name(sp)

    by_base: Dict[str, List[str]] = {}
    for sp in species:
        by_base.setdefault(base_name(sp), []).append(sp)
    out, notes = [], []
    for rule in WGD_RULES:
        if "genera" in rule:
            members = [sp for sp in species if base_name(sp).split("_")[0] in rule["genera"]]
            if not members:
                continue
            if len(members) == 1:
                out.append({"name": rule["name"], "node": members[0], "multiplier": rule["multiplier"]})
                continue
            if tree is None:
                out.append({"name": rule["name"], "mrca": members, "multiplier": rule["multiplier"]})
                continue
            node = tree.mrca(members)
            inside = set(tree.leaves_under(node.name))
            extra = sorted(inside - set(members))
            if extra:
                notes.append(f"{rule['name']} WGD 未自动放置：这些物种的最近共同祖先下还有 {', '.join(extra)}"
                             "（物种树的根或拓扑可能有问题，或这些物种也该算在内）")
                continue
            # two species spanning the clade are enough for the config
            out.append({"name": rule["name"], "mrca": _span(tree, node, members),
                        "multiplier": rule["multiplier"]})
        elif "node" in rule:
            hit = by_base.get(rule["node"])
            if hit:
                out.append({"name": rule["name"], "node": hit[0], "multiplier": rule["multiplier"]})
        else:
            a, b = (by_base.get(x) for x in rule["mrca"])
            if a and b:
                out.append({"name": rule["name"], "mrca": [a[0], b[0]], "multiplier": rule["multiplier"]})
    return out, notes


def _span(tree: Tree, node, members: List[str]) -> List[str]:
    """Two members whose MRCA is ``node`` (one from each side of its first split)."""
    for i, a in enumerate(members):
        for b in members[i + 1:]:
            if tree.mrca([a, b]) is node:
                return [a, b]
    return members


SCOPE_TEMPLATE = ["Amborella_trichopoda", "Medicago_truncatula"]


# ------------------------------------------------------------------ files
def base_name(sp: str) -> str:
    """Genus_species part of an OrthoFinder name: Glycine_max.Wm82 -> Glycine_max."""
    return re.split(r"[.]", sp, maxsplit=1)[0]


_base_name = base_name


def find_folder(root: str, sp: str, folder_map: Optional[Dict[str, str]] = None
                ) -> Tuple[Optional[str], str]:
    if folder_map and sp in folder_map:
        p = folder_map[sp]
        p = p if os.path.isabs(p) else os.path.join(root, p)
        return (p, "map") if os.path.isdir(p) else (None, f"map_missing:{p}")
    subs = [d for d in os.listdir(root) if os.path.isdir(os.path.join(root, d))]
    low = {d.lower(): d for d in subs}
    b = base_name(sp)
    for name, tag in ((sp, "exact"), (b, "base")):
        if name in subs:
            return os.path.join(root, name), tag if tag == "exact" else f"base:{name}"
        if name.lower() in low:
            return os.path.join(root, low[name.lower()]), f"case:{low[name.lower()]}"
    for name in (sp, b):
        close = difflib.get_close_matches(name, subs, n=1, cutoff=0.85)
        if close:
            return os.path.join(root, close[0]), f"fuzzy:{close[0]}"
    return None, "none"


def list_files(folder: str, depth: int = 3) -> Tuple[List[str], List[str], List[str]]:
    ann, fa, skipped = [], [], []
    base = folder.rstrip(os.sep).count(os.sep)
    for d, dirs, files in os.walk(folder):
        if d.count(os.sep) - base >= depth:
            dirs[:] = []
        dirs[:] = [x for x in dirs if not x.startswith(".")]
        for f in files:
            p = os.path.join(d, f)
            if ANN_RX.search(f):
                (skipped if SKIP_RX.search(f) else ann).append(p)
            elif FA_RX.search(f):
                (skipped if SKIP_RX.search(f) else fa).append(p)
    return sorted(ann), sorted(fa), skipped


def _open(p: str):
    return gzip.open(p, "rt", errors="replace") if p.endswith(".gz") else open(p, errors="replace")


def sniff_fasta(p: str, nbytes: int = 4_000_000) -> dict:
    """Alphabet, first name and header density from the first few MB."""
    heads, letters, nuc, first, starts_m = 0, 0, 0, None, 0
    read, new_rec = 0, False
    try:
        with _open(p) as fh:
            for line in fh:
                read += len(line)
                if line.startswith(">"):
                    heads += 1
                    new_rec = True
                    if first is None:
                        first = line[1:].split()[0] if line[1:].split() else ""
                else:
                    s = line.strip()
                    if new_rec and s:
                        starts_m += s[0] in "Mm"
                        new_rec = False
                    letters += len(s)
                    nuc += sum(s.upper().count(c) for c in "ACGTUN")
                if read > nbytes:
                    break
    except (OSError, EOFError) as e:
        return {"kind": "unreadable", "error": str(e)}
    if heads == 0:
        return {"kind": "not_fasta"}
    # proteins: many non-ACGTN letters, or most records start with Met
    protein = (letters and nuc / letters < 0.9) or (heads >= 5 and starts_m / heads > 0.5)
    kind = "protein" if protein else "nucleotide"
    return {"kind": kind, "first": first, "heads": heads, "letters": letters,
            "eof": read <= nbytes}


def _first_record(p: str) -> str:
    """Attributes of the first mRNA/transcript (or CDS) row, for diagnosis."""
    try:
        with _open(p) as fh:
            for line in fh:
                f = line.rstrip("\n").split("\t")
                if len(f) >= 9 and f[2] in ("mRNA", "transcript", "CDS"):
                    return f"{f[2]}: {f[8][:160]}"
    except OSError:
        pass
    return ""


def fasta_names(p: str) -> List[str]:
    with _open(p) as fh:
        return [ln[1:].split()[0] for ln in fh if ln.startswith(">") and ln[1:].split()]


# ------------------------------------------------------------------ matching
def _rate(gt, prots: List[str], strip: Optional[str]) -> float:
    if not prots:
        return 0.0
    m = IdMapper(strip)
    return sum(m(n, gt) is not None for n in prots) / len(prots)


def eval_annotation(path: str, sp: str, prots: List[str]) -> dict:
    is_bed = re.search(r"\.bed(\.gz)?$", path, re.I) is not None
    try:
        if is_bed:
            gt = read_bed(path, sp)
            exact, loose = _rate(gt, prots, None), _rate(gt, prots, STRIP_ALL)
        else:
            gt = read_gff(path, sp, prots, None)
            exact = _rate(gt, prots, None)
            loose = exact
            if exact < 0.98:
                gt2 = read_gff(path, sp, prots, STRIP_ALL)
                loose = _rate(gt2, prots, None)
                if loose > exact:
                    gt = gt2
    except Exception as e:  # noqa: BLE001 - report any unreadable candidate
        return {"path": path, "error": f"{type(e).__name__}: {e}"[:200], "exact": 0.0, "loose": 0.0}
    chrs = gt.df["chr"].value_counts()
    return {"path": path, "format": "bed" if is_bed else "gff", "n_genes": len(gt),
            "exact": round(exact, 4), "loose": round(loose, 4), "chroms": chrs.to_dict()}


def resolve_species(args) -> dict:
    sp, root, prot_dir, prots, folder_map = args
    r = {"species": sp, "notes": []}
    folder, how = find_folder(root, sp, folder_map)
    r["folder"], r["folder_match"] = folder, how
    if folder is None:
        r["notes"].append("没有找到物种文件夹" + (f"（{how}）" if how != "none" else
                          "；可用 --folder-map 指定"))
        ann, fa, skipped = [], [], []
    else:
        if how.startswith(("case", "fuzzy")):
            r["notes"].append(f"文件夹名与物种名不完全一致（{how}），请确认")
        ann, fa, skipped = list_files(folder)
    r["n_skipped"] = len(skipped)
    rx = re.compile(STRIP_ALL)
    bases = {}
    for x in prots:
        bases[rx.sub("", x)] = bases.get(rx.sub("", x), 0) + 1
    multi = sum(n - 1 for n in bases.values() if n > 1)
    r["n_proteins"], r["n_isoform_extra"] = len(prots), multi
    if prots and multi / len(prots) > 0.05:
        r["notes"].append(f"OrthoFinder 输入里有 {multi} 个蛋白（{multi / len(prots):.0%}）是同一基因的其他转录本，"
                          "每个基因只有一个能匹配到位置；家族层拷贝数会被高估，建议只用最长转录本重跑 OrthoFinder")

    # annotation: best match rate wins
    evals = []
    for p in sorted(ann, key=lambda x: (not re.search(r"gff3|gene|mrna|longest|primary", x, re.I),
                                        os.path.getsize(x)))[:MAX_CANDIDATES]:
        evals.append(eval_annotation(p, sp, prots))
    ok = [e for e in evals if "error" not in e]
    r["ann_candidates"] = len(ann)
    if ok:
        best = max(ok, key=lambda e: (e["loose"], e["exact"], e["format"] == "gff"))
        r["annotation"], r["ann_format"] = best["path"], best["format"]
        r["n_genes"], r["match_exact"], r["match_loose"] = best["n_genes"], best["exact"], best["loose"]
        r["chroms"] = best["chroms"]
        if best["loose"] >= 0.98 and r["n_isoform_extra"]:
            # every protein found its own gene: the "shared base names" were not isoforms
            # (e.g. Adu01.1234-style IDs where the suffix is the gene number)
            r["n_isoform_extra"] = 0
            r["notes"] = [n for n in r["notes"] if "其他转录本" not in n]
            multi = 0
        if best["loose"] < 0.9:
            iso = multi / len(prots) if prots else 0
            r["notes"].append(f"注释与 OrthoFinder 蛋白名匹配率只有 {best['loose']:.0%}"
                              + ("（大部分差额来自上面说的多转录本）" if best["loose"] + iso > 0.9 else ""))
            if best["loose"] < 0.05:
                r["example_protein"] = prots[0] if prots else ""
                r["example_annotation"] = _first_record(best["path"])
                r["notes"].append(f"例: OrthoFinder 蛋白名 {r['example_protein']}；注释第一条转录本 "
                                  f"{r['example_annotation']}")
        others = [e for e in ok if e is not best and e["loose"] > 0.5]
        if others:
            r["notes"].append("另有可用注释: " + ", ".join(os.path.basename(e["path"]) for e in others))
    else:
        r["annotation"] = None
        r["chroms"] = {}
        if ann:
            r["notes"].append("注释文件都无法读取: " + "; ".join(
                f"{os.path.basename(e['path'])}: {e.get('error')}" for e in evals))
        elif folder:
            r["notes"].append("文件夹里没有 .gff3/.gff/.gtf/.bed 注释")

    # genome / proteome
    seqids = set(r["chroms"])
    genomes, proteins = [], []
    for p in fa:
        s = sniff_fasta(p)
        if s["kind"] == "protein":
            proteins.append(p)
        elif s["kind"] == "nucleotide":
            genome_like = s["heads"] <= 3 and not s["eof"]
            if s["first"] in seqids:
                genomes.append((0, -os.path.getsize(p), p))
            elif genome_like:
                genomes.append((1, -os.path.getsize(p), p))
    genomes.sort()
    if genomes and genomes[0][0] == 0:
        r["genome"] = genomes[0][2]
    else:
        r["genome"] = None
        if genomes:
            r["notes"].append(f"{os.path.basename(genomes[0][2])} 像基因组，但序列名和注释的染色体名对不上，未采用")
        elif folder:
            r["notes"].append("没有找到基因组 fasta（不影响主流程，只是不做 gap/miniprot 检查）")

    r["proteome"], r["proteome_source"] = None, ""
    if prot_dir:
        for e in (".fa", ".faa", ".fasta", ".fas", ".pep", ".aa"):
            p = os.path.join(prot_dir, sp + e)
            if os.path.isfile(p):
                r["proteome"], r["proteome_source"] = p, "orthofinder_input"
                break
    if r["proteome"] is None and proteins:
        want = set(prots)
        rx = re.compile(STRIP_ALL)
        want2 = {rx.sub("", x) for x in want}
        scored = []
        for p in proteins[:MAX_CANDIDATES]:
            names = fasta_names(p)
            if names:
                hit = sum(n in want or rx.sub("", n) in want2 for n in names) / len(names)
                scored.append((hit, p))
        if scored and max(scored)[0] > 0.5:
            r["proteome"], r["proteome_source"] = max(scored)[1], f"folder({max(scored)[0]:.0%})"
    if r["proteome"] is None:
        r["notes"].append("没有找到与 OrthoFinder 名字一致的蛋白 fasta（只影响 miniprot 复查）")
    return r


# ------------------------------------------------------------------ main
def run_setup(orthofinder: str, species_root: str, out_yaml: str, proteome_dir: Optional[str],
              workdir: str, threads: int, report: str, log=print,
              folder_map: Optional[Dict[str, str]] = None) -> dict:
    of = OrthoFinderResults(orthofinder)
    if not of.species_ids:
        raise ValueError(f"{orthofinder}: WorkingDirectory/SpeciesIDs.txt not found")
    if not of.has_hits():
        raise ValueError(f"{orthofinder}: no Blast*_*.txt(.gz) in WorkingDirectory")
    n0 = os.path.join(of.dir, "Phylogenetic_Hierarchical_Orthogroups", "N0.tsv")
    og = os.path.join(of.dir, "Orthogroups", "Orthogroups.tsv")
    family_level = "hog"
    if not os.path.exists(n0):
        if not os.path.exists(og):
            raise ValueError(f"{orthofinder}: neither {n0} nor {og} exists")
        family_level = "og"
        log("note: no Phylogenetic_Hierarchical_Orthogroups/N0.tsv; families will use Orthogroups.tsv")
    tree_path = of.species_tree_path()
    tree = Tree.from_file(tree_path) if tree_path else None
    seq = of._load_seq()
    by_sp: Dict[str, List[str]] = {sp: [] for sp in of.species_ids}
    id2sp = {str(i): sp for sp, i in of.species_ids.items()}
    for k, name in seq.items():
        sp = id2sp.get(k.split("_", 1)[0])
        if sp:
            by_sp[sp].append(name)
    if proteome_dir is None:
        proteome_dir = os.path.dirname(os.path.dirname(os.path.abspath(orthofinder)))
    species = sorted(of.species_ids, key=of.species_ids.get)
    present = set(species)
    scope = SCOPE_TEMPLATE if all(s in present for s in SCOPE_TEMPLATE) else None
    in_scope = set(species)
    if tree is not None:
        try:
            node = tree.mrca(scope) if scope else tree.root
            in_scope = set(tree.leaves_under(node.name))
        except Exception:  # noqa: BLE001
            scope = None
            in_scope = set(tree.leaf_names)
    log(f"{len(species)} OrthoFinder species; searching {species_root}/<species>/ with {threads} workers")
    jobs = [(sp, species_root, proteome_dir, by_sp[sp], folder_map) for sp in species]
    with ProcessPoolExecutor(max_workers=threads) as ex:
        res = list(ex.map(resolve_species, jobs))

    # id_strip only if some species needs it
    need_strip = [r["species"] for r in res if r.get("annotation")
                  and r["match_loose"] - r["match_exact"] > 0.02]
    id_strip = STRIP_ALL if need_strip else None

    # report tables
    for r in res:
        r["in_scope"] = r["species"] in in_scope
    cols = ["species", "in_scope", "folder_match", "annotation", "ann_format", "n_genes", "match_exact",
            "match_loose", "n_proteins", "n_isoform_extra", "genome", "proteome", "proteome_source",
            "example_protein", "example_annotation", "notes"]
    with open(report, "w") as fh:
        fh.write("\t".join(cols) + "\n")
        for r in res:
            row = dict(r, notes="; ".join(r["notes"]))
            fh.write("\t".join("" if row.get(c) is None else str(row.get(c)) for c in cols) + "\n")
    chrom_tsv = re.sub(r"\.tsv$", "", report) + "_chromosomes.tsv"
    with open(chrom_tsv, "w") as fh:
        fh.write("species\tseqid\tn_genes\n")
        for r in res:
            for c, n in sorted(r.get("chroms", {}).items(), key=lambda x: -x[1]):
                if n >= 20:
                    fh.write(f"{r['species']}\t{c}\t{n}\n")

    # config
    # species mapped with --folder-map: the folder name tells the genus
    mapped = {r["species"]: os.path.basename(r["folder"].rstrip(os.sep))
              for r in res if r.get("folder") and r.get("folder_match") == "map"}
    wgd, wgd_notes = place_wgd(tree, species, mapped)
    for sp, b in mapped.items():
        wgd_notes.insert(0, f"{sp} 按 --folder-map 的文件夹名视为 {b}")
    sp_block = {}
    for r in res:
        d = {}
        if r.get("annotation"):
            d[r["ann_format"]] = r["annotation"]
        if r.get("genome"):
            d["genome"] = r["genome"]
        if r.get("proteome"):
            d["proteome"] = r["proteome"]
        if d:
            sp_block[r["species"]] = d
    n_genome = sum(1 for r in res if r.get("genome"))
    mp = "miniprot" if shutil.which("miniprot") and n_genome else None
    tetra = [r["species"] for r in res if re.search(r"hypogaea|monticola", r["species"])]
    sub_hint = []
    for r in res:
        if r["species"] not in tetra:
            continue
        big = [c for c, n in r.get("chroms", {}).items() if n >= 100]
        big = sorted(big, key=lambda c: [int(t) if t.isdigit() else t for t in re.split(r"(\d+)", c)])
        if len(big) == 20:
            sub_hint.append((r["species"], big[:10], big[10:]))

    def dump(obj):
        return yaml.safe_dump(obj, sort_keys=False, allow_unicode=True, default_flow_style=False,
                              width=1000).rstrip()

    lines = [
        "# GeneLegume 配置（genelegume setup 生成）。每个物种用到的文件见 species: 段，",
        f"# 选择依据见 {os.path.basename(report)}。运行前请检查 wgd、subgenomes 和物种树的根。",
        dump({"orthofinder": os.path.abspath(orthofinder), "workdir": workdir, "threads": threads}),
        "tree: null   # null = OrthoFinder 定根树；根不对时换成你自己的有根树（叶名一致）",
        *(["family_level: og   # 这份 OrthoFinder 结果没有 N0.tsv，家族改用 Orthogroups.tsv"]
          if family_level == "og" else []),
        ("# 以下物种的蛋白名需要去掉转录本后缀才能匹配注释: " + ", ".join(need_strip[:12])
         + (" ..." if len(need_strip) > 12 else "")) if need_strip else "# 所有物种的蛋白名都能直接匹配注释",
        dump({"id_strip": id_strip}),
        "",
        "synteny:",
        "  # 共线性只在该分支内使用；范围外物种只做家族层",
        f"  scope: [{', '.join(scope)}]" if scope else "  scope: null",
        "",
        "evidence: {mode: weighted, alpha: coverage}",
        "",
        "# WGD：按属名自动放置（蝶形花、大豆属、禾本科、拟南芥等），请对照文献核对。",
        "# 共线性范围根节点之前的 WGD（如 γ）为所有物种共有，不需要写。",
        *[f"# 注意: {n}" for n in wgd_notes],
        "# 可选: {name: genistoid, mrca: [Lupinus_albus, Lupinus_angustifolius], multiplier: 3}  # 需核对文献",
        dump({"wgd": wgd}) if wgd else "wgd: []",
        "",
        "# 异源四倍体按染色体拆成亚基因组；染色体名见 " + os.path.basename(chrom_tsv)
        + (f"（需要配置: {', '.join(tetra)}）" if tetra else ""),
        "# 拆分后亚基因组叶需写进物种树（tree: 指定自己的树），见 examples/config_legume55.yaml",
        *(["# 按染色体排序猜测的拆分（前 10 条 = A，后 10 条 = B；请核对你的组装）:"]
          + [f"#   {sp}:\n#     {base_name(sp)}_A: [{', '.join(a)}]\n#     {base_name(sp)}_B: [{', '.join(b)}]"
             for sp, a, b in sub_hint] if sub_hint else []),
        "subgenomes: {}",
        "",
        "absence:",
        f"  miniprot: {mp or 'null'}   # null = 不做序列复查（需 miniprot 可执行文件 + 基因组）",
        "",
        dump({"species": sp_block}),
        "",
    ]
    with open(out_yaml, "w") as fh:
        fh.write("\n".join(lines))

    # console summary
    n_ann = sum(1 for r in res if r.get("annotation"))  # noqa: F841
    log(f"annotation: {n_ann}/{len(res)} species; genome: {n_genome}; "
        f"proteome: {sum(1 for r in res if r.get('proteome'))}")
    n_bad = 0
    for r in res:
        m = f"{r['match_loose']:.0%}" if r.get("annotation") else "-"
        if not r["in_scope"]:
            flag = "  （共线性范围外，只做家族层，不需要注释）"
        elif r.get("annotation") and r["match_loose"] >= 0.9:
            flag = ""
        else:
            flag, n_bad = "  <-- 检查", n_bad + 1
        log(f"  {r['species']:<32} 注释 {os.path.basename(r.get('annotation') or '-'):<40} "
            f"匹配 {m:>5}  基因组 {'有' if r.get('genome') else '无'}{flag}")
        if r["in_scope"]:
            for n in r["notes"]:
                log(f"      · {n}")
    log(f"共线性范围内 {len(in_scope)} 个物种，{n_bad} 个需要检查")
    if tree is not None:
        root = tree.root
        sides = [tree.leaves_under(c.name) if c.name else [] for c in root.children]
        small = min(sides, key=len) if sides else []
        log(f"tree root: 最小的根分支 = {', '.join(small[:6])}{' ...' if len(small) > 6 else ''}"
            f"（如果不是你预期的外群，请在 tree: 中指定有根树）")
    log(f"wrote {out_yaml}, {report}, {chrom_tsv}")
    return {"results": res, "id_strip": id_strip}
