"""Local gene clusters and gene-level duplication modes for one genome.

Local cluster (the node of the HOC graph): genes of the same family on the
same chromosome, chained when consecutive members are <= cluster_gap ranks
apart (GoldMiner's TDGFinder uses 5).

Duplication modes follow DupGen_finder's priority:
    WGD/segmental > tandem > proximal > transposed > dispersed
    singleton = only copy of its family in this genome.
"""
from __future__ import annotations

from typing import Dict, Iterable, Optional, Set

import numpy as np
import pandas as pd

from .io_genome import GeneTable


def local_clusters(gt: GeneTable, fam_of: Dict[str, str], cluster_gap: int = 5) -> pd.Series:
    """Return gene -> local cluster id ``<species>|<family>|<k>``."""
    df = gt.df[gt.df["gene"].isin(fam_of.keys())].copy()
    df["family"] = df["gene"].map(fam_of)
    out = {}
    for (fam, chrom), sub in df.sort_values("idx").groupby(["family", "chr"], sort=False):
        idx = sub["idx"].to_numpy()
        genes = sub["gene"].to_numpy()
        breaks = np.concatenate([[True], np.diff(idx) > cluster_gap])
        cid = np.cumsum(breaks)
        for g, c in zip(genes, cid):
            out[g] = f"{gt.species}|{fam}|{chrom}:{c}"
    return pd.Series(out, name="cluster")


def duplication_modes(gt: GeneTable, fam_of: Dict[str, str], self_hits: Optional[pd.DataFrame],
                      wgd_genes: Iterable[str] = (), ancestral_genes: Iterable[str] = (),
                      tandem_gap: int = 1, proximal_gap: int = 10) -> pd.DataFrame:
    """Classify every gene of a genome.

    self_hits: q, s within this genome (mapped IDs); pairs are only considered
        between members of the same family.
    wgd_genes: genes that are anchors of intra-genome collinear blocks.
    ancestral_genes: genes in an orthologous syntenic position relative to
        another species (used to tell transposed from dispersed copies).
    """
    genes = gt.df[["gene", "chr", "idx"]].copy()
    genes["family"] = genes["gene"].map(fam_of)
    fam_size = genes.groupby("family")["gene"].transform("size")
    wgd = set(wgd_genes)
    anc = set(ancestral_genes)

    pairs = pd.DataFrame(columns=["q", "s"])
    if self_hits is not None and not self_hits.empty:
        pairs = self_hits[["q", "s"]]
        pairs = pairs[pairs["q"].isin(gt.pos.keys()) & pairs["s"].isin(gt.pos.keys())]
        same_fam = pairs["q"].map(fam_of).to_numpy() == pairs["s"].map(fam_of).to_numpy()
        pairs = pairs[same_fam]
    # fall back to family membership when no self hits are supplied
    pos = gt.df.set_index("gene")
    tandem: Set[str] = set()
    proximal: Set[str] = set()
    transposed: Set[str] = set()
    if not pairs.empty:
        ca = pos.loc[pairs["q"], "chr"].to_numpy()
        cb = pos.loc[pairs["s"], "chr"].to_numpy()
        d = np.abs(pos.loc[pairs["q"], "idx"].to_numpy() - pos.loc[pairs["s"], "idx"].to_numpy())
        same_chr = ca == cb
        t = same_chr & (d <= tandem_gap)
        p = same_chr & (d > tandem_gap) & (d <= proximal_gap)
        tandem.update(pairs["q"][t]); tandem.update(pairs["s"][t])
        proximal.update(pairs["q"][p]); proximal.update(pairs["s"][p])
        far = ~(t | p)
        q, s = pairs["q"][far].to_numpy(), pairs["s"][far].to_numpy()
        for a, b in zip(q, s):
            if a in anc and b not in anc:
                transposed.add(b)
            elif b in anc and a not in anc:
                transposed.add(a)
    else:
        # neighbour test on family members only
        for (fam, chrom), sub in genes.dropna(subset=["family"]).sort_values("idx").groupby(["family", "chr"]):
            idx, g = sub["idx"].to_numpy(), sub["gene"].to_numpy()
            if len(idx) < 2:
                continue
            d = np.diff(idx)
            for i, di in enumerate(d):
                tgt = tandem if di <= tandem_gap else proximal if di <= proximal_gap else None
                if tgt is not None:
                    tgt.add(g[i]); tgt.add(g[i + 1])

    def mode(row) -> str:
        g = row.gene
        if pd.isna(row.family) or row.fsize <= 1:
            return "singleton"
        if g in wgd:
            return "wgd"
        if g in tandem:
            return "tandem"
        if g in proximal:
            return "proximal"
        if g in transposed:
            return "transposed"
        return "dispersed"

    genes["fsize"] = fam_size.fillna(1).astype(int)
    genes["mode"] = [mode(r) for r in genes.itertuples(index=False)]
    genes["species"] = gt.species
    return genes[["species", "gene", "family", "mode"]]
