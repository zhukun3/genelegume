"""Allotetraploid end to end: genelegume subgenomes -> run -> subgenome leaves
behave like their progenitors.

The polyploid "Poly" is built from two simulated diploids: subgenome A is a copy
of Pvul and subgenome B a copy of Mtru (genes, positions, DIAMOND hits and
families), and it is placed next to Pvul in the OrthoFinder tree, as a real
allotetraploid usually is.
"""
import gzip
import os

import pandas as pd
import yaml

from genelegume import config as cfgmod
from genelegume import pipeline
from genelegume.polyploid import assign_chromosomes, run_subgenomes, split_tree, to_newick
from genelegume.simulate import Sim, SimParams
from genelegume.tree import Tree

A, B, P = "Pvul", "Mtru", "Poly"


def _rd(p):
    with (gzip.open(p, "rt") if p.endswith(".gz") else open(p)) as fh:
        return fh.read().splitlines()


def add_allotetraploid(sim: str):
    res = os.path.join(sim, "OrthoFinder", "Results_sim")
    wd = os.path.join(res, "WorkingDirectory")
    sp_ids = {}
    for ln in _rd(os.path.join(wd, "SpeciesIDs.txt")):
        i, f = ln.split(": ")
        sp_ids[f.rsplit(".", 1)[0]] = int(i)
    ia, ib, ip = sp_ids[A], sp_ids[B], max(sp_ids.values()) + 1
    with open(os.path.join(wd, "SpeciesIDs.txt"), "a") as fh:
        fh.write(f"{ip}: {P}.fa\n")
    seq = [ln.split(": ", 1) for ln in _rd(os.path.join(wd, "SequenceIDs.txt"))]
    a_ids = [(k, n) for k, n in seq if k.startswith(f"{ia}_")]
    b_ids = [(k, n) for k, n in seq if k.startswith(f"{ib}_")]
    idmap, name = {}, {}
    for j, (k, n) in enumerate(a_ids + b_ids):
        idmap[k] = f"{ip}_{j}"
        name[n] = ("PA_" if j < len(a_ids) else "PB_") + n
    with open(os.path.join(wd, "SequenceIDs.txt"), "a") as fh:
        for k, n in a_ids + b_ids:
            fh.write(f"{idmap[k]}: {name[n]}\n")

    def blast(i, j):
        return [ln.split("\t") for ln in _rd(os.path.join(wd, f"Blast{i}_{j}.txt.gz"))]

    def write(i, j, rows):
        with gzip.open(os.path.join(wd, f"Blast{i}_{j}.txt.gz"), "wt") as fh:
            fh.write("".join("\t".join(r) + "\n" for r in rows))

    others = [i for i in sp_ids.values()]
    for j in others:
        write(ip, j, [[idmap[r[0]]] + r[1:] for src in (ia, ib) for r in blast(src, j)])
        write(j, ip, [[r[0], idmap[r[1]]] + r[2:] for src in (ia, ib) for r in blast(j, src)])
    write(ip, ip, [[idmap[r[0]], idmap[r[1]]] + r[2:] for x in (ia, ib) for y in (ia, ib)
                   for r in blast(x, y)])
    # families: Poly column = renamed A + B members
    for rel in (("Phylogenetic_Hierarchical_Orthogroups", "N0.tsv"), ("Orthogroups", "Orthogroups.tsv"),
                ("Orthogroups", "Orthogroups_UnassignedGenes.tsv")):
        p = os.path.join(res, *rel)
        if not os.path.exists(p):
            continue
        df = pd.read_csv(p, sep="\t", dtype=str)

        def ren(v):
            return ", ".join(name[x] for x in str(v).split(", ")) if isinstance(v, str) and v else ""
        df[P] = [", ".join(x for x in (ren(a), ren(b)) if x) for a, b in zip(df[A], df[B])]
        df.to_csv(p, sep="\t", index=False)
    # annotation
    rows = []
    for sp, pre, cp in ((A, "PA_", "A_"), (B, "PB_", "B_")):
        for ln in _rd(os.path.join(sim, "bed", f"{sp}.bed")):
            f = ln.split("\t")
            f[0], f[3] = cp + f[0], pre + f[3]
            rows.append("\t".join(f))
    with open(os.path.join(sim, "bed", f"{P}.bed"), "w") as fh:
        fh.write("\n".join(rows) + "\n")
    # tree: Poly sister to Pvul
    tp = os.path.join(res, "Species_Tree", "SpeciesTree_rooted_node_labels.txt")
    t = open(tp).read().strip()
    assert f"{A}:" in t
    t = t.replace(f"{A}:3", f"({A}:3,{P}:3)PolyClade:0")
    open(tp, "w").write(t + "\n")


def test_assign_chromosomes_votes():
    chr_of = {f"g{i}": ("c1" if i < 10 else "c2") for i in range(20)}
    best = {"A": pd.Series({f"g{i}": (100 if i < 10 else 50) for i in range(20)}),
            "B": pd.Series({f"g{i}": (60 if i < 10 else 90) for i in range(20)})}
    t = assign_chromosomes(chr_of, best)
    assert dict(zip(t["chr"], t["assigned"])) == {"c1": "A", "c2": "B"}


def test_split_tree_keeps_polyploid_clade():
    t = Tree("(Ath:1,((Adur:1,(Amon:1,Ahyp:1)N12:1)N11:1,Aipa:2)N9:1)N0;")
    s = split_tree(t, ["Ahyp", "Amon"], {"A": "Adur", "B": "Aipa"}, lambda p, lab: f"{p}_{lab}")
    nw = to_newick(s.root)
    assert set(s.leaf_names) == {"Ath", "Adur", "Aipa", "Amon_A", "Ahyp_A", "Amon_B", "Ahyp_B"}
    # each subgenome pair stays together, next to its progenitor
    assert set(s.leaves_under(s.mrca(["Adur", "Ahyp_A"]).name)) == {"Adur", "Amon_A", "Ahyp_A"}
    assert set(s.leaves_under(s.mrca(["Aipa", "Ahyp_B"]).name)) == {"Aipa", "Amon_B", "Ahyp_B"}
    assert set(s.leaves_under(s.mrca(["Amon_A", "Ahyp_A"]).name)) == {"Amon_A", "Ahyp_A"}
    assert len({n.name for n in s.preorder()}) == len(list(s.preorder())), nw


def test_allotetraploid_end_to_end(tmp_path):
    Sim(p=SimParams(seed=7, genes_per_chr=60)).run().write(str(tmp_path))
    add_allotetraploid(str(tmp_path))
    cfg = {"orthofinder": "OrthoFinder/Results_sim", "workdir": "out_poly", "threads": 1,
           "bed_dir": "bed", "id_strip": r"\.1$", "synteny": {"scope": ["Gmax", "Vvin"]},
           "wgd": [{"name": "papilionoid", "mrca": ["Gmax", "Mtru"], "multiplier": 2},
                   {"name": "Glycine", "mrca": ["Gmax", "Gsoj"], "multiplier": 2}]}
    cfg_path = tmp_path / "gl.yaml"
    with open(cfg_path, "w") as fh:
        yaml.safe_dump(cfg, fh)
        fh.write("tree: null\nsubgenomes: {}\n")
    out = tmp_path / "gl_sub.yaml"
    res = run_subgenomes(str(cfg_path), [P], {"A": A, "B": B}, str(out), log=lambda *_: None)
    parts = res["subgenomes"][P]
    assert parts[f"{P}_A"] and all(c.startswith("A_") for c in parts[f"{P}_A"])
    assert parts[f"{P}_B"] and all(c.startswith("B_") for c in parts[f"{P}_B"])
    c2 = yaml.safe_load(open(out))
    assert c2["subgenomes"] == res["subgenomes"] and os.path.exists(c2["tree"])

    pipeline.run_all(cfgmod.load(str(out)))
    m = pd.read_csv(tmp_path / "out_poly" / "hoc" / "hoc_matrix.tsv", sep="\t", index_col=0)
    assert {f"{P}_A", f"{P}_B"} <= set(m.columns) and P not in m.columns
    for sub, prog in ((f"{P}_A", A), (f"{P}_B", B)):
        both = m[[sub, prog]].dropna()
        agree = (both[sub] == both[prog]).mean()
        assert agree > 0.97, (sub, prog, agree)
