import numpy as np
import pandas as pd
import pytest

from genelegume.hoc import build_hocs, mcl
from genelegume.recon import Costs, aggregate_accessions, classify, reconstruct
from genelegume.synteny import chain
from genelegume.tree import Tree

NWK = "((((Gm:1,Gs:1)Glycine:1,Mt:2)Papil:1,Lj:3):1,At:4);"
NWK_REORDERED = "(At:4,(Lj:3,(Mt:2,(Gs:1,Gm:1)Glycine:1)Papil:1):1);"


def test_tree_parse_and_names():
    t = Tree(NWK)
    assert sorted(t.leaf_names) == ["At", "Gm", "Gs", "Lj", "Mt"]
    assert t.root.name == "N0"
    assert t.mrca(["Gm", "Mt"]).name == "Papil"
    assert sorted(t.leaves_under("Glycine")) == ["Gm", "Gs"]
    assert Tree(t.to_newick()).leaf_names == t.leaf_names


def test_tree_quoted_and_comments():
    t = Tree("(('sp A':1[&x],B:2)X:1,C:3);")
    assert "sp A" in t.leaf_names and "X" in t.by_name


def test_recon_topology_invariant_and_any_size():
    c = pd.DataFrame({"Gm": [4, 2, 0], "Gs": [2, 2, 0], "Mt": [2, 1, 1],
                      "Lj": [0, 1, 1], "At": [1, 1, 1]}, index=["a", "b", "c"])
    r1 = reconstruct(c, Tree(NWK), {"Glycine": 2})
    r2 = reconstruct(c, Tree(NWK_REORDERED), {"Glycine": 2})
    cols = sorted(r1.states.columns)
    assert (r1.states[cols] == r2.states[cols]).all().all()


def test_recon_na_is_missing_not_zero():
    c = pd.DataFrame({"Gm": [np.nan], "Gs": [1], "Mt": [1], "Lj": [1], "At": [1]}, index=["u"])
    r = reconstruct(c, Tree(NWK), {})
    assert not (r.events["event"] == "loss").any()
    c0 = c.fillna(0)
    r0 = reconstruct(c0, Tree(NWK), {})
    assert ((r0.events["event"] == "loss") & (r0.events["node"] == "Gm")).any()


def test_recon_wgd_retention_not_expansion():
    c = pd.DataFrame({"Gm": [2], "Gs": [2], "Mt": [1], "Lj": [1], "At": [1]}, index=["u"])
    r = reconstruct(c, Tree(NWK), {"Glycine": 2})
    ev = dict(zip(r.events["node"], r.events["event"]))
    assert ev.get("Glycine") == "wgd_retention"
    assert "expansion" not in ev.values()


def test_recon_large_copy_numbers():
    c = pd.DataFrame({"Gm": [150], "Gs": [140], "Mt": [30], "Lj": [20], "At": [5]}, index=["nlr"])
    r = reconstruct(c, Tree(NWK), {})
    assert r.states.loc["nlr", "Gm"] == 150


def test_classify():
    p = np.array([0, 1, 2, 1, 1, 2])
    c = np.array([1, 0, 1, 3, 2, 2])
    assert list(classify(p, c, 1)) == ["gain", "loss", "contraction", "expansion", "expansion", ""]
    assert list(classify(np.array([1, 1, 1]), np.array([2, 1, 3]), 2)) == [
        "wgd_retention", "wgd_fractionation", "expansion"]


def test_aggregate_accessions_frequency():
    c = pd.DataFrame({"a1": [1, 0], "a2": [0, 0], "a3": [0, 2], "a4": [0, 2]}, index=["x", "y"])
    leaf, freq = aggregate_accessions(c, {"sp": ["a1", "a2", "a3", "a4"]}, 0.5)
    assert leaf.loc["x", "sp"] == 0  # 1 of 4 accessions: not present for the species
    assert leaf.loc["y", "sp"] == 2


def test_chain_finds_diagonal_and_antidiagonal():
    rng = np.random.default_rng(0)
    x = np.r_[np.arange(0, 40), np.arange(100, 130), rng.integers(0, 200, 50)]
    y = np.r_[np.arange(10, 50), np.arange(300, 270, -1), rng.integers(0, 400, 50)]
    fw = chain(x, y)
    rv = chain(x, -y)
    assert max(len(c) for c in fw) >= 38
    assert max(len(c) for c in rv) >= 28


def test_mcl_two_cliques():
    import scipy.sparse as sp
    A = np.zeros((6, 6))
    A[:3, :3] = 1
    A[3:, 3:] = 1
    A[2, 3] = A[3, 2] = 0.1
    np.fill_diagonal(A, 0)
    lab = mcl(sp.csr_matrix(A))
    assert len(set(lab[:3])) == 1 and len(set(lab[3:])) == 1 and lab[0] != lab[5]


def test_build_hocs_components():
    cl = pd.DataFrame({"cluster": ["A|f|1", "B|f|1", "C|f|1", "A|f|2"],
                       "species": ["A", "B", "C", "A"], "family": "f"})
    e = pd.DataFrame({"family": "f", "c1": ["A|f|1", "B|f|1"], "c2": ["B|f|1", "C|f|1"], "w": [5, 5]})
    h = build_hocs(cl, e)
    assert h["A|f|1"] == h["B|f|1"] == h["C|f|1"] != h["A|f|2"]


def test_parse_miniprot_paf(tmp_path):
    from genelegume.absence import parse_miniprot_paf
    p = tmp_path / "x.paf"
    p.write_text("##PAF\tdummy\n"
                 "P1\t300\t0\t290\t+\tHOC1\t20000\t5000\t5900\t250\t870\t0\tAS:i:500\tms:i:480\tfs:i:0\tst:i:0\tcg:Z:290M\n"
                 "P2\t300\t10\t120\t+\tHOC2\t20000\t100\t430\t60\t330\t0\tAS:i:100\tfs:i:1\tst:i:2\n")
    df = parse_miniprot_paf(str(p))
    assert list(df["q"]) == ["P1", "P2"]
    assert abs(df.loc[0, "cov"] - 290 / 300) < 1e-9 and df.loc[1, "fs"] == 1 and df.loc[1, "stop"] == 2
