import numpy as np
import pandas as pd

from genelegume import evidence as evm
from genelegume.recon import reconstruct, to_cafe
from genelegume.tree import Tree


def _orth(block, pairs, start=0):
    return pd.DataFrame({"block": block, "gene_a": [a for a, _ in pairs],
                         "gene_b": [b for _, b in pairs], "ia": range(start, start + len(pairs))})


def test_local_support_saturates_and_drops_at_block_ends():
    orth = _orth("b1", [(f"a{i}", f"b{i}") for i in range(30)])
    s = evm.local_support(orth, window=10).set_index("gene_a")["s"]
    assert s["a15"] == 1.0
    assert s["a0"] == 1.0  # 10 neighbours on one side
    small = evm.local_support(_orth("b2", [(f"x{i}", f"y{i}") for i in range(5)]), window=10)
    assert (small["s"] == 0.4).all()


def test_pair_evidence_relative_homology_and_family_filter():
    hits = pd.DataFrame({"q": ["a1", "a1", "a2", "a3"], "s": ["b1", "b2", "b2", "b9"],
                         "bits": [200.0, 100.0, 300.0, 500.0]})
    fam = {"a1": "F", "a2": "F", "b1": "F", "b2": "F", "a3": "F", "b9": "G"}
    ev = evm.pair_evidence(hits, fam, None).set_index(["gene_a", "gene_b"])
    assert ("a3", "b9") not in ev.index           # different families
    assert ev.loc[("a1", "b1"), "h"] == 1.0          # reciprocal best
    assert ev.loc[("a1", "b2"), "h"] == 100 / 300    # b2's best is a2
    assert (ev["s"] == 0).all()


def test_reciprocal_topk_keeps_wgd_coorthologs():
    # one Medicago gene, two soybean WGD copies
    ev = pd.DataFrame({"gene_a": ["m", "m"], "gene_b": ["g1", "g2"], "bits": [300.0, 280.0],
                       "s": [1.0, 0.9], "h": [1.0, 280 / 300]})
    assert evm.reciprocal_topk(ev, evm.hms(ev, 0.8), 1, 1).sum() == 1
    assert evm.reciprocal_topk(ev, evm.hms(ev, 0.8), 2, 1).sum() == 2


def test_tau_gates_homology_only_edges_by_alpha():
    ev = pd.DataFrame({"gene_a": ["a"], "gene_b": ["b"], "bits": [100.0], "s": [0.0], "h": [1.0]})
    assert len(evm.select_edges(ev, alpha=0.9, k_ab=1, k_ba=1, tau=0.25)) == 0   # close pair
    assert len(evm.select_edges(ev, alpha=0.5, k_ab=1, k_ba=1, tau=0.25)) == 1   # eroded pair


def test_synteny_overrides_a_slightly_better_paralog_hit():
    ev = pd.DataFrame({"gene_a": ["a", "a"], "gene_b": ["ortholog", "paralog"],
                       "bits": [280.0, 300.0], "s": [1.0, 0.0], "h": [280 / 300, 1.0]})
    sel = evm.select_edges(ev, alpha=0.8, k_ab=1, k_ba=1)
    assert list(sel["gene_b"]) == ["ortholog"]


def test_coverage_choose_alpha_and_decay_fit():
    d = np.array([1, 2, 3, 6, 8, 12, 16, 20.0])
    cov = 0.95 / (1 + np.exp((d - 10) / 2))
    st = pd.DataFrame({"distance": d, "coverage": cov, "n_rbh": 1000, "alpha_rbk": 0.5})
    a, params = evm.choose_alpha(st, "coverage")
    assert np.allclose(a, cov)
    assert params is not None and abs(params[1] - 10) < 0.5
    a_s, _ = evm.choose_alpha(st, "smooth")
    assert np.allclose(a_s, cov, atol=0.02)
    a_f, _ = evm.choose_alpha(st, 0.3)
    assert (a_f == 0.3).all()


def test_tree_distance():
    t = Tree("((A:1,B:2)X:3,C:4);")
    assert t.distance("A", "B") == 3 and t.distance("A", "C") == 8
    assert Tree("((A,B),C);").distance("A", "C") == 3


def test_cafe_export_drops_na_units(tmp_path):
    c = pd.DataFrame({"x": [1, np.nan], "y": [2, 0]}, index=["u1", "u2"])
    n, n_na = to_cafe(c, str(tmp_path / "c.tsv"), str(tmp_path / "na.tsv"))
    assert (n, n_na) == (1, 1)
    out = pd.read_csv(tmp_path / "c.tsv", sep="\t")
    assert list(out["Family ID"]) == ["u1"]


def test_ambiguity_flag():
    # A=1, B=0 under a cherry: gain-on-A vs loss-on-B is a genuine tie
    t = Tree("((A:1,B:1)X:1,C:1);")
    c = pd.DataFrame({"A": [1, 1], "B": [0, 1], "C": [0, 1]}, index=["tie", "clear"])
    r = reconstruct(c, t)
    assert r.ambiguous.loc["tie"].any()
    assert not r.ambiguous.loc["clear"].any()
    assert "ambiguous" in r.events.columns
