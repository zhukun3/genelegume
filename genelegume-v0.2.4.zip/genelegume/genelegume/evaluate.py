"""Score a pipeline run on simulated data against the simulation truth."""
from __future__ import annotations

import os
from typing import Dict

import numpy as np
import pandas as pd

from .recon import Costs, classify, reconstruct
from .tree import Tree


def _pairs(n):
    return n * (n - 1) // 2


def evaluate(sim_dir: str, out_dir: str, wgd: Dict[str, int], scope_node: str) -> Dict[str, object]:
    tg = pd.read_csv(os.path.join(sim_dir, "truth", "genes.tsv.gz"), sep="\t")
    tnc = pd.read_csv(os.path.join(sim_dir, "truth", "locus_node_counts.tsv.gz"), sep="\t", index_col=0)
    tree = Tree.from_file(os.path.join(out_dir, "recon_hoc", "tree_with_node_names.nwk"))
    hg = pd.read_csv(os.path.join(out_dir, "hoc", "hoc_genes.tsv.gz"), sep="\t")
    rep: Dict[str, object] = {}

    # ---------------- 1. HOC clustering vs true loci (pairwise, within families)
    m = hg.merge(tg[["gene", "locus"]], on="gene")
    ct = m.groupby(["hoc", "locus"]).size()
    tp = sum(_pairs(v) for v in ct)
    pp = sum(_pairs(v) for v in m.groupby("hoc").size())
    tt = sum(_pairs(v) for v in m.groupby("locus").size())
    rep["hoc_pair_precision"] = tp / pp if pp else 1.0
    rep["hoc_pair_recall"] = tp / tt if tt else 1.0
    maj = ct.reset_index(name="n").sort_values("n", ascending=False).drop_duplicates("hoc")
    hoc2loc = dict(zip(maj["hoc"], maj["locus"]))
    sizes = m.groupby("hoc").size()
    rep["hoc_purity"] = float(maj.set_index("hoc")["n"].sum() / sizes.sum())
    rep["n_hoc"] = int(hg["hoc"].nunique())
    leaves = tree.leaf_names
    true_loci_scope = tnc.index[(tnc[leaves] > 0).any(axis=1)]
    rep["n_true_loci_in_scope"] = int(len(true_loci_scope))

    # ---------------- 2. zero cells
    z = pd.read_csv(os.path.join(out_dir, "hoc", "hoc_zero_states.tsv.gz"), sep="\t")
    z["locus"] = z["hoc"].map(hoc2loc)
    leaf_true = tnc[leaves]
    # truth for a zero cell: is the locus really present in that genome?
    tt_present = tg.groupby(["locus", "species"]).agg(n=("gene", "size"),
                                                         unann=("annotated", lambda s: (~s).sum()),
                                                         gap=("in_gap", "sum"))
    z = z.merge(tt_present, left_on=["locus", "species"], right_index=True, how="left").fillna(
        {"n": 0, "unann": 0, "gap": 0})
    z["truth"] = np.where(z["n"] == 0, "absent",
                  np.where(z["gap"] > 0, "in_gap", np.where(z["unann"] > 0, "unannotated", "present_annotated")))
    rep["zero_cells"] = pd.crosstab(z["state"], z["truth"]).to_dict()
    called_abs = z[z["state"] == "absent"]
    rep["absent_call_precision"] = float((called_abs["truth"] == "absent").mean()) if len(called_abs) else None

    # ---------------- 3. events
    mat = pd.read_csv(os.path.join(out_dir, "hoc", "hoc_matrix.tsv"), sep="\t", index_col=0)
    ev = pd.read_csv(os.path.join(out_dir, "recon_hoc", "events.tsv.gz"), sep="\t")
    st = pd.read_csv(os.path.join(out_dir, "recon_hoc", "node_states.tsv.gz"), sep="\t", index_col=0)
    nodes = [n.name for n in tree.nodes]
    wgd_s = {k: v for k, v in wgd.items() if k in tree.by_name and k != tree.root.name}

    def truth_events(loci):
        S = tnc.reindex(loci).fillna(0)[nodes].to_numpy().astype(int)
        rows = []
        for node in tree.nodes:
            if node.parent is None:
                for l, c in zip(loci, S[:, node.idx]):
                    if c > 0:
                        rows.append((l, node.name, "gain"))
                continue
            e = classify(S[:, node.parent.idx], S[:, node.idx], wgd_s.get(node.name, 1))
            for l, x in zip(loci, e):
                if x:
                    rows.append((l, node.name, x))
        return set(rows)

    good = maj[maj["n"] / maj["hoc"].map(sizes) >= 0.8]
    one = good.groupby("locus").filter(lambda d: len(d) == 1)  # loci represented by one HOC
    h_ok = set(one["hoc"])
    loc_ok = list(one["locus"])
    T = truth_events(loc_ok)

    def score(events, label):
        e = events[events["unit"].isin(h_ok)]
        P = set(zip(e["unit"].map(hoc2loc), e["node"], e["event"]))
        out = {}
        for typ in ["gain", "loss", "expansion", "contraction", "wgd_retention", "wgd_fractionation"]:
            p = {x for x in P if x[2] == typ}
            t = {x for x in T if x[2] == typ}
            out[typ] = dict(pred=len(p), true=len(t), tp=len(p & t),
                            precision=round(len(p & t) / len(p), 3) if p else None,
                            recall=round(len(p & t) / len(t), 3) if t else None)
        rep[f"events_{label}"] = out
        return out

    score(ev, "genelegume")
    if "ambiguous" in ev.columns:
        score(ev[~ev["ambiguous"].astype(bool)], "genelegume_unambiguous")
        rep["ambiguous_event_fraction"] = float(ev["ambiguous"].astype(bool).mean()) if len(ev) else 0.0
    # baseline: zeros taken at face value (no NA), as in a plain count matrix
    naive = mat.fillna(0)
    rn = reconstruct(naive, tree, wgd_s, Costs())
    score(rn.events, "naive_zeros")
    # internal node exact-state accuracy
    inner = [n.name for n in tree.nodes if not n.is_leaf]
    tr = tnc.reindex(list(one["locus"])).fillna(0)[inner].to_numpy()
    pr = st.loc[list(one["hoc"]), inner].to_numpy()
    rep["internal_node_state_accuracy"] = float((tr == pr).mean())
    rep["n_loci_scored"] = len(loc_ok)
    return rep
