"""Classifying zeros in the HOC x species matrix.

For a HOC with no copy in species s:

  NA_nocontext  no orthologous syntenic block places the locus in s
                (rearranged, or synteny eroded) -> missing data
  NA_gap        the projected interval overlaps an assembly gap -> missing data
  unannotated   a family protein aligns (miniprot) to the interval as an intact
                gene model -> counted as 1 copy when rescue is on
  pseudo        the alignment has frameshifts or in-frame stop codons
                -> counted as 0 (lost as a functional gene)
  partial       only a partial alignment without frameshift/stop (a fragment,
                a truncated interval or a diverged copy) -> missing data
  absent        context present, no gap, no sequence found (verified=True if
                a sequence search was run, else False)

This is the step GoldMiner skips (there a zero is simply "no link"), and is
the main source of false PAV calls when annotations come from different
pipelines.
"""
from __future__ import annotations

import os
import subprocess
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd

from .io_genome import GeneTable


def project_genes(anchors: pd.DataFrame, gr: GeneTable, gs: GeneTable,
                  r_is_a: bool = True, max_span: int = 60) -> pd.DataFrame:
    """Project every gene of species r into species s through collinear blocks.

    anchors: orthologous anchors of the (r, s) comparison with columns block,
             gene_a, gene_b, ia, ib (a/b orientation given by r_is_a).
    Returns gene, chr_s, lo, hi (gene ranks in s, inclusive), span.
    """
    if anchors is None or anchors.empty:
        return pd.DataFrame(columns=["gene", "chr_s", "lo", "hi", "span"])
    ga_col, gb_col, pr, ps = (("gene_a", "gene_b", "ia", "ib") if r_is_a
                              else ("gene_b", "gene_a", "ib", "ia"))
    posr = gr.df.set_index("gene")
    poss = gs.df.set_index("gene")
    an = anchors[[ "block", ga_col, gb_col, pr, ps]].copy()
    an.columns = ["block", "gr", "gs", "pr", "ps"]
    an["chr_r"] = posr.loc[an["gr"], "chr"].to_numpy()
    an["chr_s"] = poss.loc[an["gs"], "chr"].to_numpy()
    out = []
    for (blk, cr), sub in an.groupby(["block", "chr_r"], sort=False):
        sub = sub.sort_values("pr")
        P = sub["pr"].to_numpy()
        Q = sub["ps"].to_numpy()
        genes = gr.df[(gr.df["chr"] == cr) & (gr.df["idx"] >= P[0]) & (gr.df["idx"] <= P[-1])]
        if genes.empty:
            continue
        x = genes["idx"].to_numpy()
        li = np.searchsorted(P, x, side="right") - 1
        ri = np.searchsorted(P, x, side="left")
        ri = np.minimum(ri, len(P) - 1)
        ql, qr = Q[li], Q[ri]
        lo, hi = np.minimum(ql, qr), np.maximum(ql, qr)
        ok = (P[ri] - P[li]) <= max_span
        out.append(pd.DataFrame({"gene": genes["gene"].to_numpy()[ok], "chr_s": sub["chr_s"].iloc[0],
                                 "lo": lo[ok], "hi": hi[ok], "span": (hi - lo)[ok]}))
    if not out:
        return pd.DataFrame(columns=["gene", "chr_s", "lo", "hi", "span"])
    return pd.concat(out, ignore_index=True)


def zero_cells_context(zero_cells: pd.DataFrame, hoc_genes: pd.DataFrame,
                       projections: pd.DataFrame, gs: GeneTable,
                       gaps: Optional[Tuple[Dict[str, np.ndarray], Dict[str, int]]] = None
                       ) -> pd.DataFrame:
    """Context state for every zero cell of one target species s.

    zero_cells: hoc (all HOCs with 0 copies in s)
    hoc_genes:  hoc, gene (members in other species)
    projections: gene -> interval in s (from project_genes, concatenated over r)
    Returns hoc, state, chr, start, end (bp, 0-based half-open), n_support.
    """
    z = zero_cells[["hoc"]].drop_duplicates()
    m = hoc_genes[hoc_genes["hoc"].isin(z["hoc"])][["hoc", "gene"]]
    j = m.merge(projections, on="gene", how="inner")
    res = z.copy()
    res["state"] = "NA_nocontext"
    res["chr"] = ""
    res["start"] = -1
    res["end"] = -1
    res["n_support"] = 0
    if not j.empty:
        j = j.sort_values(["hoc", "span"])
        sup = j.groupby("hoc").size()
        best = j.drop_duplicates("hoc").set_index("hoc")
        df = gs.df
        key = df.set_index(["chr", "idx"])
        st = key.loc[list(zip(best["chr_s"], best["lo"])), "start"].to_numpy()
        en = key.loc[list(zip(best["chr_s"], best["hi"])), "end"].to_numpy()
        best = best.assign(start=st, end=en)
        res = res.set_index("hoc")
        idx = best.index
        res.loc[idx, "chr"] = best["chr_s"]
        res.loc[idx, "start"] = best["start"]
        res.loc[idx, "end"] = best["end"]
        res.loc[idx, "n_support"] = sup.loc[idx]
        res.loc[idx, "state"] = "absent"
        res = res.reset_index()
    res["verified"] = False
    if gaps is not None:
        g, _ = gaps
        has = res["state"] == "absent"
        flags = np.zeros(len(res), dtype=bool)
        for i in np.where(has)[0]:
            arr = g.get(res.at[i, "chr"])
            if arr is None or len(arr) == 0:
                continue
            s, e = res.at[i, "start"], res.at[i, "end"]
            k = np.searchsorted(arr[:, 0], e)
            if k > 0 and (arr[:k, 1] > s).any():
                flags[i] = True
        res.loc[flags, "state"] = "NA_gap"
    return res


# --------------------------------------------------------------- miniprot
def parse_miniprot_paf(path: str) -> pd.DataFrame:
    """Parse miniprot's default PAF output.

    Columns: q, qlen, qs, qe, strand, t, tlen, ts, te, nmatch, alen, mapq + tags.
    Returns q, t, ts, te, cov, ident, fs, stop.
    """
    rows = []
    with open(path) as fh:
        for line in fh:
            if line.startswith("#") or not line.strip():
                continue
            f = line.rstrip("\n").split("\t")
            if len(f) < 12:
                continue
            tags = {t.split(":", 2)[0]: t.split(":", 2)[2] for t in f[12:] if t.count(":") >= 2}
            qlen, qs, qe = int(f[1]), int(f[2]), int(f[3])
            nm, al = int(f[9]), max(1, int(f[10]))
            rows.append((f[0], f[5], int(f[7]), int(f[8]), (qe - qs) / max(1, qlen), nm / al,
                         int(tags.get("fs", 0)), int(tags.get("st", 0))))
    return pd.DataFrame(rows, columns=["q", "t", "ts", "te", "cov", "ident", "fs", "stop"])


def merge_intervals(cells: pd.DataFrame, pad: int) -> List[Tuple[str, int, int]]:
    """Union of the padded cell intervals, per chromosome (sorted, non-overlapping)."""
    out: List[Tuple[str, int, int]] = []
    for chrom, sub in cells.groupby("chr", sort=True):
        iv = sorted((max(0, int(a) - pad), int(b) + pad) for a, b in zip(sub["start"], sub["end"]))
        cs, ce = iv[0]
        for a, b in iv[1:]:
            if a <= ce:
                ce = max(ce, b)
            else:
                out.append((str(chrom), cs, ce))
                cs, ce = a, b
        out.append((str(chrom), cs, ce))
    return out


def sequence_check(cells: pd.DataFrame, genome_fa: str, queries: Dict[str, List[str]],
                   proteins: Dict[str, str], workdir: str, miniprot: str = "miniprot",
                   threads: int = 4, pad: int = 5000, min_cov: float = 0.5,
                   min_ident: float = 0.4, intact_cov: float = 0.8,
                   max_secondary: int = 100, secondary_ratio: float = 0.1) -> pd.DataFrame:
    """Search family proteins in the projected intervals with miniprot.

    cells: rows with state == "absent" (hoc, chr, start, end)
    queries: hoc -> protein IDs to search (members from the closest species)
    proteins: protein ID -> sequence
    Updates state to unannotated / pseudo / partial and sets verified=True.

    The padded intervals are merged per chromosome before extraction, so each
    genome base is indexed once (overlapping intervals used to be written once
    per cell, several times the genome size). A hit counts for a cell only if
    its query belongs to that cell's HOC and it lies inside that cell's own
    interval. miniprot keeps weaker secondary alignments (``-p``/``--outs``),
    so a degraded copy inside the interval is not hidden by a stronger paralog
    elsewhere.
    """
    os.makedirs(workdir, exist_ok=True)
    todo = cells[(cells["state"] == "absent") & cells["chr"].notna()].copy()
    if todo.empty:
        return cells
    regions = merge_intervals(todo, pad)
    seqs = _read_regions(genome_fa, regions)
    reg_fa = os.path.join(workdir, "regions.fa")
    q_fa = os.path.join(workdir, "queries.fa")
    pairs = os.path.join(workdir, "pairs.tsv")
    offset = {}
    with open(reg_fa, "w") as o:
        for i, (chrom, a, b) in enumerate(regions):
            seq = seqs.get((chrom, a, b))
            if seq:
                name = f"R{i}"
                offset[name] = (chrom, a)
                o.write(f">{name}\n{seq}\n")
    total = sum(len(v) for v in seqs.values())
    with open(os.path.join(workdir, "regions_summary.txt"), "w") as o:
        o.write(f"cells\t{len(todo)}\nregions\t{len(offset)}\nbases\t{total}\n")
    seen = set()
    with open(q_fa, "w") as o, open(pairs, "w") as p:
        for h in todo["hoc"]:
            for pid in queries.get(h, []):
                if pid in proteins:
                    p.write(f"{pid}\t{h}\n")
                    if pid not in seen:
                        o.write(f">{pid}\n{proteins[pid]}\n")
                        seen.add(pid)
    cells = cells.copy()
    cells.loc[cells.index.isin(todo.index), "verified"] = True
    if not offset or not seen:
        return cells
    paf = os.path.join(workdir, "miniprot.paf")
    with open(paf, "w") as out:
        subprocess.run([miniprot, "-t", str(threads), "-N", str(max_secondary),
                        "-p", str(secondary_ratio), f"--outs={secondary_ratio}",
                        f"--outn={max_secondary}", reg_fa, q_fa],
                       stdout=out, check=True)
    hits = parse_miniprot_paf(paf)
    if hits.empty:
        return cells
    hits = hits[hits["t"].isin(offset.keys())]
    hits["chr"] = hits["t"].map(lambda t: offset[t][0])
    base = hits["t"].map(lambda t: offset[t][1])
    hits["gs"], hits["ge"] = hits["ts"] + base, hits["te"] + base
    allowed = pd.read_csv(pairs, sep="\t", header=None, names=["q", "hoc"], dtype=str)
    hits = hits.merge(allowed, on="q")                       # query -> its HOC(s)
    cell_iv = todo[["hoc", "chr", "start", "end"]].astype({"chr": str})
    hits = hits.merge(cell_iv, on=["hoc", "chr"])            # that HOC's cell here
    hits = hits[(hits["ge"] > hits["start"] - pad) & (hits["gs"] < hits["end"] + pad)]
    hits = hits[(hits["cov"] >= min_cov) & (hits["ident"] >= min_ident)]
    if hits.empty:
        return cells
    hits["broken"] = (hits["fs"] > 0) | (hits["stop"] > 0)
    hits["intact"] = (hits["cov"] >= intact_cov) & ~hits["broken"]
    agg = hits.groupby("hoc").agg(intact=("intact", "any"), broken=("broken", "any"))
    idx = todo.index[todo["hoc"].isin(agg.index)]
    a = agg.loc[cells.loc[idx, "hoc"]]
    cells.loc[idx, "state"] = np.where(a["intact"].to_numpy(), "unannotated",
                                       np.where(a["broken"].to_numpy(), "pseudo", "partial"))
    return cells


def _read_regions(genome_fa: str, regions: List[Tuple[str, int, int]]) -> Dict[Tuple[str, int, int], str]:
    want: Dict[str, List[Tuple[int, int]]] = {}
    for chrom, a, b in regions:
        want.setdefault(chrom, []).append((a, b))
    out: Dict[Tuple[str, int, int], str] = {}
    import gzip
    op = gzip.open if genome_fa.endswith(".gz") else open
    name, chunks = None, []

    def flush():
        if name in want:
            seq = "".join(chunks)
            for a, b in want[name]:
                out[(name, a, b)] = seq[a:b]

    with op(genome_fa, "rt") as fh:
        for line in fh:
            if line.startswith(">"):
                flush()
                name, chunks = line[1:].split()[0], []
            elif name in want:
                chunks.append(line.strip())
    flush()
    return out


COUNT_RULE = {"absent": 0.0, "pseudo": 0.0, "unannotated": 1.0, "partial": np.nan,
              "NA_gap": np.nan, "NA_nocontext": np.nan}
MISSING_STATES = {"NA_gap", "NA_nocontext", "partial"}
