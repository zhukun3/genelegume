"""GeneLegume: gene presence/absence and expansion/contraction from synteny + homology."""
__version__ = "0.2.4"
