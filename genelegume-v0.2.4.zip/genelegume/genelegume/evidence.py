"""Divergence-aware weighting of synteny and homology evidence.

For two genomes A and B, every same-family gene pair (a, b) found in the
OrthoFinder hits gets two scores in [0, 1]:

  s(a, b)  local synteny support: 0 unless (a, b) is an orthologous anchor;
           otherwise the number of anchors of the same block within +-W genes
           of a, divided by W (capped at 1). Local support is robust next to
           block breakpoints, where whole-block scores are misleading.
  h(a, b)  relative homology: bitscore / best bitscore of a in B, and of b in
           A; the smaller of the two. Equals 1 for a reciprocal best hit.
           (Normalising by the self score, as in a BLAST score ratio, cancels
           out here, so self hits are not needed.)

They are combined per genome pair, as in GeneTribe's homolog match score:

  HMS(a, b) = alpha_AB * s + (1 - alpha_AB) * h

Differences from GeneTribe:

* alpha_AB is by default the *synteny coverage* of the pair: the fraction of
  reciprocal best hits that are also orthologous syntenic anchors. Close
  genomes (high coverage) rely on synteny; distant or fragmented ones, where
  a missing syntenic partner says little, fall back on homology. GeneTribe's
  own criterion (the alpha that maximises reciprocal best hits) is available
  as ``alpha_method: rbk``, generalised to WGDs (see below).
* Edges are *reciprocal top-k* pairs, with k from the WGD history: Medicago ->
  Glycine keeps the best 2 soybean genes (Glycine WGD), Glycine -> Medicago
  the best 1. Plain reciprocal best hits would split true 1:2 co-orthologs.
* A pair must also reach HMS >= tau. A homology-only pair (s = 0) has
  HMS <= 1 - alpha, so it can only form an edge when alpha <= 1 - tau: in
  well-collinear genome pairs a copy without a syntenic partner (transposed
  copy, or partner lost) stays a separate locus; in eroded pairs homology
  links it.
"""
from __future__ import annotations

import json
from typing import Dict, Iterable, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

EVIDENCE_COLS = ["gene_a", "gene_b", "bits", "s", "h"]


# ------------------------------------------------------------------ scores
def local_support(orth: pd.DataFrame, window: int = 10) -> pd.DataFrame:
    """Synteny score of each orthologous anchor.

    orth: anchors with columns block, gene_a, gene_b, ia (rank in genome A).
    Returns gene_a, gene_b, s.
    """
    if orth is None or orth.empty:
        return pd.DataFrame(columns=["gene_a", "gene_b", "s"])
    out = []
    for _, sub in orth.groupby("block", sort=False):
        x = np.sort(sub["ia"].to_numpy())
        pos = sub["ia"].to_numpy()
        lo = np.searchsorted(x, pos - window, side="left")
        hi = np.searchsorted(x, pos + window, side="right")
        n = hi - lo - 1  # neighbours, excluding the anchor itself
        out.append(pd.DataFrame({"gene_a": sub["gene_a"].to_numpy(),
                                 "gene_b": sub["gene_b"].to_numpy(),
                                 "s": np.minimum(1.0, n / float(window))}))
    s = pd.concat(out, ignore_index=True)
    return s.groupby(["gene_a", "gene_b"], as_index=False)["s"].max()


def pair_evidence(hits: pd.DataFrame, fam_of: Dict[str, str], orth: Optional[pd.DataFrame],
                  window: int = 10) -> pd.DataFrame:
    """Candidate gene pairs between genomes A and B with their s and h scores.

    hits: columns q (gene in A), s (gene in B), bits; both search directions
          already merged (one row per pair, best bitscore).
    fam_of: gene -> family; only same-family pairs are kept.
    orth: orthologous anchors of the pair (block, gene_a, gene_b, ia).
    """
    h = hits[["q", "s", "bits"]].rename(columns={"q": "gene_a", "s": "gene_b"})
    fa, fb = h["gene_a"].map(fam_of), h["gene_b"].map(fam_of)
    h = h[fa.notna() & (fa == fb)]
    h = h.sort_values("bits", ascending=False).drop_duplicates(["gene_a", "gene_b"])
    sup = local_support(orth, window)
    if not sup.empty:
        # anchors always come from the hits, but keep any that were filtered
        extra = sup.merge(h[["gene_a", "gene_b"]], how="left", indicator=True)
        extra = extra[extra["_merge"] == "left_only"][["gene_a", "gene_b"]]
        if not extra.empty and orth is not None and "bits" in orth.columns:
            eb = orth[["gene_a", "gene_b", "bits"]].merge(extra)
            h = pd.concat([h, eb], ignore_index=True)
        h = h.merge(sup, on=["gene_a", "gene_b"], how="left")
    else:
        h = h.assign(s=np.nan)
    h["s"] = h["s"].fillna(0.0)
    fa, fb = h["gene_a"].map(fam_of), h["gene_b"].map(fam_of)
    h = h[fa.notna() & (fa == fb)]
    if h.empty:
        return pd.DataFrame(columns=EVIDENCE_COLS)
    best_a = h.groupby("gene_a")["bits"].transform("max")
    best_b = h.groupby("gene_b")["bits"].transform("max")
    h["h"] = np.minimum(h["bits"] / best_a, h["bits"] / best_b)
    return h[EVIDENCE_COLS].reset_index(drop=True)


# ---------------------------------------------------------------- selection
def _rank(keys: np.ndarray, score: np.ndarray, tiebreak: np.ndarray) -> np.ndarray:
    """1-based rank of each row within its key, by score then tiebreak (desc)."""
    order = np.lexsort((-tiebreak, -score, keys))
    k = keys[order]
    start = np.r_[True, k[1:] != k[:-1]]
    grp_start = np.maximum.accumulate(np.where(start, np.arange(len(k)), 0))
    r = np.empty(len(k), dtype=np.int64)
    r[order] = np.arange(len(k)) - grp_start + 1
    return r


def reciprocal_topk(ev: pd.DataFrame, score: np.ndarray, k_ab: int, k_ba: int,
                    min_score: float = 0.0) -> np.ndarray:
    """Boolean mask: b is among a's top k_ab in B and a among b's top k_ba in A
    (only rows with score > min_score are ranked)."""
    ok = score > min_score
    mask = np.zeros(len(ev), dtype=bool)
    if not ok.any():
        return mask
    idx = np.where(ok)[0]
    ga = pd.factorize(ev["gene_a"].to_numpy()[idx])[0]
    gb = pd.factorize(ev["gene_b"].to_numpy()[idx])[0]
    sc = score[idx]
    tb = ev["bits"].to_numpy()[idx]
    ra = _rank(ga, sc, tb)
    rb = _rank(gb, sc, tb)
    mask[idx[(ra <= k_ab) & (rb <= k_ba)]] = True
    return mask


def hms(ev: pd.DataFrame, alpha: float) -> np.ndarray:
    return alpha * ev["s"].to_numpy() + (1.0 - alpha) * ev["h"].to_numpy()


def select_edges(ev: pd.DataFrame, alpha: float, k_ab: int, k_ba: int,
                 tau: float = 0.25) -> pd.DataFrame:
    """Gene-pair edges kept for HOC building, with their HMS."""
    if ev.empty:
        return ev.assign(hms=[])
    sc = hms(ev, alpha)
    keep = reciprocal_topk(ev, sc, k_ab, k_ba) & (sc >= tau)
    return ev[keep].assign(hms=sc[keep])


# -------------------------------------------------------------------- alpha
def synteny_coverage(ev: pd.DataFrame) -> Tuple[float, int]:
    """Fraction of reciprocal best hits (h == 1) that are orthologous anchors."""
    if ev.empty:
        return float("nan"), 0
    rbh = ev[ev["h"] >= 1.0 - 1e-9]
    if rbh.empty:
        return float("nan"), 0
    return float((rbh["s"] > 0).mean()), int(len(rbh))


def scan_alpha(ev: pd.DataFrame, k_ab: int, k_ba: int,
               grid: Sequence[float] = tuple(np.round(np.arange(0, 1.0001, 0.05), 2)),
               max_rows: int = 400_000, seed: int = 0) -> Tuple[float, Dict[float, int]]:
    """GeneTribe's criterion, made WGD-aware: the alpha that maximises the
    number of reciprocal top-k pairs. Returns (alpha, {alpha: count}); the
    middle of the plateau within 0.1% of the maximum is chosen."""
    if ev.empty:
        return float("nan"), {}
    if len(ev) > max_rows:  # subsample whole query genes to keep it fast
        genes = ev["gene_a"].unique()
        rng = np.random.default_rng(seed)
        keep = rng.choice(genes, size=max(1, int(len(genes) * max_rows / len(ev))), replace=False)
        ev = ev[ev["gene_a"].isin(set(keep))]
    counts = {}
    for a in grid:
        counts[float(a)] = int(reciprocal_topk(ev, hms(ev, a), k_ab, k_ba).sum())
    best = max(counts.values())
    plateau = [a for a, c in counts.items() if c >= best - max(1, 0.001 * best)]
    return float(np.median(plateau)), counts


def fit_decay(dist: np.ndarray, cov: np.ndarray, weight: Optional[np.ndarray] = None
              ) -> Optional[Tuple[float, float, float]]:
    """Fit coverage = top / (1 + exp((d - d0) / sigma)). Returns (top, d0, sigma)
    or None when there are too few pairs or the fit fails."""
    ok = np.isfinite(dist) & np.isfinite(cov)
    if ok.sum() < 4 or np.ptp(dist[ok]) == 0:
        return None
    from scipy.optimize import curve_fit
    d, c = dist[ok], cov[ok]
    w = None if weight is None else 1.0 / np.sqrt(np.maximum(weight[ok], 1))
    f = lambda x, top, d0, sg: top / (1.0 + np.exp((x - d0) / sg))
    try:
        p, _ = curve_fit(f, d, c, p0=[max(c.max(), 0.05), np.median(d), max(np.ptp(d) / 4, 1e-3)],
                         sigma=w, bounds=([0, d.min() - np.ptp(d), 1e-4], [1, d.max() + 2 * np.ptp(d), 10 * np.ptp(d) + 1]),
                         maxfev=20000)
        return float(p[0]), float(p[1]), float(p[2])
    except Exception:
        return None


def decay_value(params: Tuple[float, float, float], d: np.ndarray) -> np.ndarray:
    top, d0, sg = params
    return top / (1.0 + np.exp((np.asarray(d, dtype=float) - d0) / sg))


def choose_alpha(stats: pd.DataFrame, mode="coverage") -> Tuple[pd.Series, Optional[tuple]]:
    """alpha per genome pair.

    mode: "coverage" (default), "rbk" (GeneTribe-style scan), "smooth" (the
    fitted decay curve of coverage vs distance), or a number (fixed).
    stats: index pair, columns distance, coverage, n_rbh, alpha_rbk.
    """
    params = fit_decay(stats["distance"].to_numpy(float), stats["coverage"].to_numpy(float),
                       stats["n_rbh"].to_numpy(float))
    if isinstance(mode, (int, float)) and not isinstance(mode, bool):
        return pd.Series(float(mode), index=stats.index), params
    if mode == "rbk":
        a = stats["alpha_rbk"]
    elif mode == "smooth":
        a = (pd.Series(decay_value(params, stats["distance"]), index=stats.index)
             if params else stats["coverage"])
    elif mode == "coverage":
        a = stats["coverage"]
    else:
        raise ValueError(f"unknown alpha mode {mode!r}")
    return a.fillna(0.0).clip(0.0, 1.0), params


def plot_decay(stats: pd.DataFrame, params, out: str) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(5.2, 3.6))
    ax.scatter(stats["distance"], stats["coverage"], s=16, color="#3b6ea5", label="genome pair", zorder=3)
    if params:
        x = np.linspace(0, stats["distance"].max() * 1.05, 200)
        ax.plot(x, decay_value(params, x), color="#c0504d", lw=1.6,
                label=f"logistic fit (d0={params[1]:.3g})")
    ax.set_xlabel("distance on species tree")
    ax.set_ylabel("synteny coverage of RBHs (alpha)")
    ax.set_ylim(-0.03, 1.03)
    ax.grid(alpha=0.3)
    ax.legend(frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(out)
    plt.close(fig)


def write_stats(path: str, **kw) -> None:
    with open(path, "w") as o:
        json.dump(kw, o)


def read_stats(path: str) -> dict:
    with open(path) as fh:
        return json.load(fh)
