"""Homologous gene clusters (HOCs): OrthoFinder families split into syntenic loci.

Within the synteny scope (a clade, e.g. angiosperms), each family (HOG) is
split into loci:

nodes  = local clusters (same family, same chromosome, <= cluster_gap apart)
edges  = orthologous syntenic anchors between two species, both genes in the
         same family; weight = number of anchor pairs between the two clusters
HOC    = a community in that graph (connected component, refined by MCL when a
         species has more clusters in it than its WGD history allows)

So a HOC is "all copies descended from one ancestral locus at the scope root",
and recent WGD copies stay in the same HOC (they are explained by the WGD
multipliers in the reconstruction, not counted as tandem expansion).
"""
from __future__ import annotations

from collections import defaultdict
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd

try:
    import scipy.sparse as sp
except Exception:  # pragma: no cover
    sp = None


# --------------------------------------------------------------------- MCL
def mcl(adj: "sp.csr_matrix", inflation: float = 2.0, max_iter: int = 100,
        prune: float = 1e-4, tol: float = 1e-6) -> np.ndarray:
    """Plain sparse MCL. Returns a cluster label per node."""
    n = adj.shape[0]
    M = adj.tocsc().astype(float) + sp.identity(n, format="csc")  # self loops
    M = _normalize(M)
    for _ in range(max_iter):
        last = M
        M = M @ M
        M = M.power(inflation)
        M.data[M.data < prune] = 0
        M.eliminate_zeros()
        M = _normalize(M)
        if abs(M - last).max() < tol:
            break
    # attractors: rows with positive diagonal; node j belongs to argmax row of column j
    M = M.tocsc()
    labels = np.full(n, -1, dtype=np.int64)
    for j in range(n):
        col = M.getcol(j)
        if col.nnz == 0:
            labels[j] = j
        else:
            labels[j] = col.indices[np.argmax(col.data)]
    _, labels = np.unique(labels, return_inverse=True)
    return labels


def _normalize(M):
    s = np.asarray(M.sum(axis=0)).ravel()
    s[s == 0] = 1
    return (M @ sp.diags(1.0 / s)).tocsc()


def _components(n: int, e1: np.ndarray, e2: np.ndarray) -> np.ndarray:
    parent = np.arange(n)

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    for a, b in zip(e1, e2):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb
    roots = np.array([find(i) for i in range(n)])
    _, lab = np.unique(roots, return_inverse=True)
    return lab


# ----------------------------------------------------------------- building
def cluster_edges(anchor_tables: Iterable[pd.DataFrame], cluster_of: Dict[str, str],
                  fam_of: Dict[str, str]) -> pd.DataFrame:
    """Aggregate orthologous anchors into weighted cluster-cluster edges."""
    parts = []
    for an in anchor_tables:
        if an is None or an.empty:
            continue
        a, b = an["gene_a"], an["gene_b"]
        fa, fb = a.map(fam_of), b.map(fam_of)
        ok = fa.notna() & (fa == fb)
        ca, cb = a[ok].map(cluster_of), b[ok].map(cluster_of)
        ok2 = ca.notna() & cb.notna()
        parts.append(pd.DataFrame({"c1": ca[ok2].to_numpy(), "c2": cb[ok2].to_numpy(),
                                   "family": fa[ok][ok2].to_numpy()}))
    if not parts:
        return pd.DataFrame(columns=["c1", "c2", "family", "w"])
    e = pd.concat(parts, ignore_index=True)
    lo = np.where(e["c1"] < e["c2"], e["c1"], e["c2"])
    hi = np.where(e["c1"] < e["c2"], e["c2"], e["c1"])
    e["c1"], e["c2"] = lo, hi
    return e.groupby(["family", "c1", "c2"], as_index=False).size().rename(columns={"size": "w"})


def build_hocs(clusters: pd.DataFrame, edges: pd.DataFrame,
               max_depth: Optional[Dict[str, int]] = None,
               method: str = "mcl", inflation: float = 2.0) -> pd.Series:
    """Assign every local cluster to a HOC.

    clusters: columns cluster, species, family (one row per cluster)
    edges:    family, c1, c2, w
    max_depth: species -> max clusters per HOC allowed by its WGD history
               (product of multipliers from the scope root); components that
               exceed it are refined by MCL. Default 1 for every species.
    Returns cluster -> HOC id ``<family>.L<k>``.
    """
    max_depth = max_depth or {}
    out: Dict[str, str] = {}
    e_by_fam = {f: g for f, g in edges.groupby("family")} if not edges.empty else {}
    for fam, cl in clusters.groupby("family", sort=False):
        names = cl["cluster"].to_numpy()
        species = cl["species"].to_numpy()
        n = len(names)
        if n == 1 or fam not in e_by_fam:
            for k, nm in enumerate(names):
                out[nm] = f"{fam}.L{k + 1}"
            continue
        ix = {nm: i for i, nm in enumerate(names)}
        e = e_by_fam[fam]
        e1 = e["c1"].map(ix).to_numpy()
        e2 = e["c2"].map(ix).to_numpy()
        w = e["w"].to_numpy(dtype=float)
        lab = _components(n, e1, e2)
        if method == "mcl" and sp is not None:
            lab = _refine(lab, species, e1, e2, w, max_depth, inflation)
        # stable numbering: by size desc then first member
        order = pd.Series(lab).value_counts().index.tolist()
        rank = {l: k + 1 for k, l in enumerate(order)}
        for nm, l in zip(names, lab):
            out[nm] = f"{fam}.L{rank[l]}"
    return pd.Series(out, name="hoc")


def _refine(lab, species, e1, e2, w, max_depth, inflation):
    lab = lab.copy()
    nxt = lab.max() + 1
    for comp in np.unique(lab):
        members = np.where(lab == comp)[0]
        if len(members) < 3:
            continue
        sp_counts = pd.Series(species[members]).value_counts()
        allowed = sp_counts.index.map(lambda s: max_depth.get(s, 1)).to_numpy()
        if (sp_counts.to_numpy() <= allowed).all():
            continue
        loc = {m: i for i, m in enumerate(members)}
        mask = np.isin(e1, members) & np.isin(e2, members)
        r = np.array([loc[x] for x in e1[mask]])
        c = np.array([loc[x] for x in e2[mask]])
        A = sp.coo_matrix((np.r_[w[mask], w[mask]], (np.r_[r, c], np.r_[c, r])),
                          shape=(len(members), len(members))).tocsr()
        sub = mcl(A, inflation=inflation)
        for s in np.unique(sub)[1:]:
            lab[members[sub == s]] = nxt
            nxt += 1
    return lab


def assign_unanchored(genes: pd.DataFrame, hoc_of_gene: Dict[str, str],
                      best_partner: Dict[str, str], na_cells: set) -> Dict[str, Tuple[str, str]]:
    """Fallback for genes whose cluster got no syntenic edge.

    genes: gene, species, family, cluster (only unanchored clusters' genes)
    best_partner: gene -> best-hit gene of the same family in another scope
                  species that *is* in a syntenic HOC
    na_cells: {(hoc, species)} where the species has no syntenic context
    A gene joins its partner's HOC only if that HOC has no syntenic context in
    the gene's species (synteny eroded, e.g. distant lineages); otherwise it is
    a relocated copy and keeps its own locus.
    Returns cluster -> (hoc, evidence).
    """
    res: Dict[str, Tuple[str, str]] = {}
    for cl, sub in genes.groupby("cluster"):
        sp_ = sub["species"].iloc[0]
        votes = defaultdict(int)
        for g in sub["gene"]:
            p = best_partner.get(g)
            if p and p in hoc_of_gene:
                votes[hoc_of_gene[p]] += 1
        if votes:
            h = max(votes, key=votes.get)
            if (h, sp_) in na_cells:
                res[cl] = (h, "homology")
    return res
