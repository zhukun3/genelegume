"""Multi-seed benchmark on simulated data: several scenarios x evidence modes.

Each (scenario, seed) simulation is written once; every method runs in its
own work directory on it, and is scored against the simulation truth.
Results: runs.tsv (one row per run) and summary.tsv (mean and SD per
scenario and method).
"""
from __future__ import annotations

import contextlib
import io
import os
import shutil
from typing import Dict, Iterable, List, Optional

import numpy as np
import pandas as pd
import yaml

from . import config as cfgmod
from . import pipeline
from .evaluate import evaluate
from .simulate import Sim, SimParams

SCENARIOS: Dict[str, dict] = {
    "default": {},
    # single genes leave their syntenic position (locus kept), more on long branches
    "eroded": {"shuffle": 0.02},
    # stronger erosion plus more annotation gaps in two genomes
    "eroded_strong": {"shuffle": 0.04, "unannotated": {"Pvul": 0.05, "Vvin": 0.03}},
}

METHODS: Dict[str, dict] = {
    "synteny_first": {"evidence": {"mode": "synteny_first"}},
    "weighted": {"evidence": {"mode": "weighted", "alpha": "coverage"}},
    "weighted_rbk": {"evidence": {"mode": "weighted", "alpha": "rbk"}},
    "weighted_smooth": {"evidence": {"mode": "weighted", "alpha": "smooth"}},
}

SIM_WGD = [{"mrca": ["Gmax", "Mtru"], "multiplier": 2, "name": "papilionoid"},
           {"mrca": ["Gmax", "Gsoj"], "multiplier": 2, "name": "Glycine"}]


def _flatten(r: dict) -> dict:
    out = {k: r[k] for k in ("hoc_pair_precision", "hoc_pair_recall", "hoc_purity",
                             "internal_node_state_accuracy", "absent_call_precision",
                             "ambiguous_event_fraction") if k in r}
    for label in ("genelegume", "genelegume_unambiguous"):
        for ev, v in (r.get(f"events_{label}") or {}).items():
            tag = "" if label == "genelegume" else "unamb_"
            out[f"{tag}{ev}_precision"] = v["precision"]
            out[f"{tag}{ev}_recall"] = v["recall"]
    return out


def run_benchmark(out: str, seeds: Iterable[int], scenarios: List[str], methods: List[str],
                  threads: int = 2, genes_per_chr: int = 150, extra_methods: Optional[dict] = None,
                  keep: bool = False, log=print) -> pd.DataFrame:
    os.makedirs(out, exist_ok=True)
    catalogue = dict(METHODS)
    catalogue.update(extra_methods or {})
    rows = []
    for sc in scenarios:
        for seed in seeds:
            d = os.path.join(out, f"{sc}_seed{seed}")
            if not os.path.exists(os.path.join(d, "truth")):
                Sim(p=SimParams(seed=seed, genes_per_chr=genes_per_chr, **SCENARIOS[sc])).run().write(d)
            for m in methods:
                cfg = {"orthofinder": "OrthoFinder/Results_sim", "workdir": f"out_{m}",
                       "threads": threads, "bed_dir": "bed", "genome_dir": "genome",
                       "id_strip": r"\.1$", "synteny": {"scope": ["Gmax", "Vvin"]}, "wgd": SIM_WGD}
                cfg.update(catalogue[m])
                cp = os.path.join(d, f"config_{m}.yaml")
                with open(cp, "w") as o:
                    yaml.safe_dump(cfg, o, sort_keys=False)
                with contextlib.redirect_stderr(io.StringIO()):
                    pipeline.run_all(cfgmod.load(cp))
                r = evaluate(d, os.path.join(d, f"out_{m}"), {"Papi": 2, "Glyc": 2}, "Eud")
                row = {"scenario": sc, "seed": seed, "method": m, **_flatten(r)}
                rows.append(row)
                log(f"{sc}\tseed {seed}\t{m}\tHOC P/R {row['hoc_pair_precision']:.3f}/"
                    f"{row['hoc_pair_recall']:.3f}\tabsent P {row.get('absent_call_precision') or 0:.3f}")
                if not keep:
                    shutil.rmtree(os.path.join(d, f"out_{m}"), ignore_errors=True)
    runs = pd.DataFrame(rows)
    runs.to_csv(os.path.join(out, "runs.tsv"), sep="\t", index=False, float_format="%.4f")
    summary = summarise(runs)
    summary.to_csv(os.path.join(out, "summary.tsv"), sep="\t", float_format="%.4f")
    return summary


def summarise(runs: pd.DataFrame) -> pd.DataFrame:
    num = [c for c in runs.columns if c not in ("scenario", "seed", "method")]
    g = runs.groupby(["scenario", "method"], sort=False)[num]
    mean, sd = g.mean(), g.std(ddof=1)
    mean.columns = [f"{c}_mean" for c in mean.columns]
    sd.columns = [f"{c}_sd" for c in sd.columns]
    out = pd.concat([mean, sd], axis=1)
    order = [x for c in num for x in (f"{c}_mean", f"{c}_sd")]
    return out[order]
