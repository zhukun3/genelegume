"""sequence_check: merged regions, hits counted only inside the cell's own interval."""
import os
import random
import stat
import sys

import pandas as pd

from genelegume.absence import merge_intervals, sequence_check

FAKE = r'''#!{py}
import sys
args = sys.argv[1:]
open({argv!r}, "w").write(" ".join(args))
reg = [l[1:].split()[0] for l in open(args[-2]) if l.startswith(">")]
L = {{n: 0 for n in reg}}
name = None
for l in open(args[-2]):
    if l.startswith(">"):
        name = l[1:].split()[0]
    else:
        L[name] += len(l.strip())
def paf(q, t, ts, te, qlen=100, qs=0, qe=95, fs=0):
    return "\t".join(map(str, [q, qlen, qs, qe, "+", t, L[t], ts, te, 280, 290, 0,
                               "AS:i:300", f"fs:i:{{fs}}", "st:i:0"]))
# R0 = merged chr1:5000-35000, R1 = chr1:95000-115000
print(paf("p1", "R0", 6000, 8000))           # genome 11000-13000: inside H1 -> unannotated
print(paf("p2", "R0", 0, 500))               # genome 5000-5500: outside H2's own interval
print(paf("p1", "R1", 1000, 2000))           # p1 is not a query of H3 -> ignored
print(paf("p3", "R1", 8000, 9000, fs=1))     # inside H3, frameshift -> pseudo
'''


def test_merge_intervals():
    cells = pd.DataFrame({"chr": ["c1", "c1", "c1", "c2"], "start": [100, 150, 1000, 5],
                          "end": [200, 300, 1100, 10]})
    assert merge_intervals(cells, 10) == [("c1", 90, 310), ("c1", 990, 1110), ("c2", 0, 20)]


def test_sequence_check_merged(tmp_path):
    random.seed(1)
    fa = tmp_path / "g.fa"
    fa.write_text(">chr1\n" + "".join(random.choice("ACGT") for _ in range(200_000)) + "\n")
    argv = tmp_path / "argv.txt"
    exe = tmp_path / "miniprot"
    exe.write_text(FAKE.format(py=sys.executable, argv=str(argv)))
    exe.chmod(exe.stat().st_mode | stat.S_IEXEC)
    cells = pd.DataFrame({"hoc": ["H1", "H2", "H3"], "species": "X", "chr": "chr1",
                          "start": [10_000, 15_000, 100_000], "end": [20_000, 30_000, 110_000],
                          "state": "absent"})
    queries = {"H1": ["p1"], "H2": ["p2"], "H3": ["p3"]}
    prot = {"p1": "M" * 100, "p2": "M" * 100, "p3": "M" * 100}
    out = sequence_check(cells, str(fa), queries, prot, str(tmp_path / "w"), str(exe), 2, pad=5000)
    assert dict(zip(out["hoc"], out["state"])) == {"H1": "unannotated", "H2": "absent", "H3": "pseudo"}
    assert out["verified"].all()
    summ = dict(l.split("\t") for l in open(tmp_path / "w" / "regions_summary.txt").read().split("\n") if l)
    assert int(summ["regions"]) == 2 and int(summ["bases"]) == 30_000 + 20_000
    a = argv.read_text()
    assert "-p 0.1" in a and "--outs=0.1" in a and "-N 100" in a
    assert os.path.exists(tmp_path / "w" / "miniprot.paf")
