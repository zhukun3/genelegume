"""YAML configuration with defaults."""
from __future__ import annotations

import copy
import os
from typing import Any, Dict, Optional

import yaml

DEFAULTS: Dict[str, Any] = {
    "orthofinder": None,          # OrthoFinder Results_* directory
    "orthofinder_workdir": None,  # override WorkingDirectory (Blast files)
    "workdir": "genelegume_out",
    "threads": 4,
    "tree": None,                 # Newick; default = OrthoFinder rooted tree with node labels
    "family_level": "hog",        # hog (N0.tsv) | og
    "include_unassigned": True,
    "bed_dir": None,              # {bed_dir}/{species}.bed
    "gff_dir": None,              # {gff_dir}/{species}.gff3
    "genome_dir": None,           # {genome_dir}/{species}.fa[.gz] (gaps, miniprot)
    "proteome_dir": None,         # OrthoFinder input fasta dir (miniprot queries)
    "species": {},                # per-species overrides: {sp: {bed:, gff:, genome:, proteome:}}
    "id_strip": None,             # regex removed from protein IDs to match annotation IDs
    "synteny": {
        "scope": None,            # [spA, spB] -> MRCA clade where synteny is used
        "evalue": 1e-5,
        "top_hits": 5,
        "match_score": 50,
        "gap_penalty": 1,
        "max_gap": 25,
        "min_anchors": 5,
        "pid_delta": 10.0,
    },
    "evidence": {
        "mode": "weighted",       # weighted | synteny_first (v0.1 behaviour)
        "alpha": "coverage",      # coverage | rbk | smooth | <number in [0, 1]>
        "tau": 0.25,              # min HMS of an edge; homology-only edges need alpha <= 1 - tau
        "window": 10,             # +- genes for local synteny support
        "scan": True,             # also run the GeneTribe-style alpha scan (reported in pair_alpha.tsv)
    },
    "wgd": [],                  # [{mrca: [a, b] | node: N12, multiplier: 2, name: ...}]
    "clusters": {"cluster_gap": 5, "tandem_gap": 1, "proximal_gap": 10},
    "hoc": {"method": "mcl", "inflation": 2.0, "fallback": True,
            "young_blocks": True,     # link in-scope WGD paralogs via blocks younger than scope root
            "self_min_pid": 70.0},    # identity threshold if no cross-root orthologs exist
    "absence": {
        "gap_min": 10,
        "miniprot": None,         # path to miniprot to enable the sequence check
        "rescue_unannotated": True,
        "queries_per_hoc": 3,
        "max_span": 60,
    },
    "subgenomes": {},             # {OrthoFinder_species: {leaf_A: [chr..], leaf_B: [chr..]}}
    "accessions": {},             # {species_leaf: [accession, ...]} pan-genome collapsing
    "min_presence_freq": 0.5,
    "recon": {"gain": 3.0, "loss": 1.0, "dup": 2.0, "shrink": 1.0, "frac": 0.25,
              "root_gain": 1.0},  # presence at the scope/tree root; lower = favour old origin + losses
}


def _merge(base: dict, new: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (new or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _merge(out[k], v)
        else:
            out[k] = v
    return out


def load(path: Optional[str] = None, *, overrides: Optional[dict] = None) -> Dict[str, Any]:
    user = {}
    if path is not None:
        with open(path) as fh:
            user = yaml.safe_load(fh) or {}
    cfg = _merge(DEFAULTS, user)
    base = os.path.dirname(os.path.abspath(path)) if path is not None else os.getcwd()
    for k in ("orthofinder", "orthofinder_workdir", "workdir", "tree", "bed_dir",
              "gff_dir", "genome_dir", "proteome_dir"):
        if cfg.get(k) and not os.path.isabs(cfg[k]):
            cfg[k] = os.path.join(base, cfg[k])
    for sp, d in cfg["species"].items():
        for k, v in list(d.items()):
            if isinstance(v, str) and not os.path.isabs(v):
                d[k] = os.path.join(base, v)
    cfg = _merge(cfg, overrides)
    if cfg["orthofinder"] is None:
        raise ValueError("config: 'orthofinder' (Results directory) is required")
    return cfg


def species_file(cfg: dict, sp: str, kind: str) -> str | None:
    """Find an annotation or sequence file using an override or the species name."""
    d = cfg["species"].get(sp, {})
    if d.get(kind):
        return d[kind]
    root = cfg.get(f"{kind}_dir")
    if not root:
        return None
    exts = {"bed": [".bed", ".bed.gz"],
            "gff": [".gff3", ".gff", ".gff3.gz", ".gff.gz"],
            "genome": [".fa", ".fasta", ".fna", ".fa.gz", ".fasta.gz", ".fna.gz"],
            "proteome": [".fa", ".faa", ".fasta", ".pep"]}[kind]
    for e in exts:
        p = os.path.join(root, sp + e)
        if os.path.isfile(p):
            return p
    return None
