"""Rooted species tree: a small, dependency-free Newick parser.

Unlike GoldMiner's OdlRecon (which reads leaf names off the Newick text with a
regex and assumes a ladder-shaped tree), this module parses the real topology,
so any rooted, possibly multifurcating tree works.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Iterator, List, Optional


@dataclass
class Node:
    name: str = ""
    length: Optional[float] = None
    children: List["Node"] = field(default_factory=list)
    parent: Optional["Node"] = None
    idx: int = -1  # postorder index, set by Tree

    @property
    def is_leaf(self) -> bool:
        return not self.children

    def __repr__(self) -> str:  # pragma: no cover
        return f"Node({self.name!r}, leaf={self.is_leaf})"


class NewickError(ValueError):
    pass


def _parse(s: str) -> Node:
    s = s.strip()
    if not s.endswith(";"):
        s += ";"
    pos = 0

    def read_label() -> str:
        nonlocal pos
        if s[pos] == "'":
            end = s.index("'", pos + 1)
            lab = s[pos + 1:end]
            pos = end + 1
            return lab
        start = pos
        while s[pos] not in ",():;[":
            pos += 1
        return s[start:pos].strip()

    def skip_comment() -> None:
        nonlocal pos
        if s[pos] == "[":
            pos = s.index("]", pos) + 1

    def read_node() -> Node:
        nonlocal pos
        node = Node()
        if s[pos] == "(":
            pos += 1
            while True:
                child = read_node()
                child.parent = node
                node.children.append(child)
                if s[pos] == ",":
                    pos += 1
                    continue
                if s[pos] == ")":
                    pos += 1
                    break
                raise NewickError(f"unexpected {s[pos]!r} at {pos}")
        node.name = read_label()
        skip_comment()
        if s[pos] == ":":
            pos += 1
            start = pos
            while s[pos] not in ",();[":
                pos += 1
            txt = s[start:pos].strip()
            node.length = float(txt) if txt else None
            skip_comment()
        return node

    root = read_node()
    if s[pos] != ";":
        raise NewickError(f"trailing text at {pos}: {s[pos:pos+20]!r}")
    return root


class Tree:
    """Rooted tree with postorder-indexed nodes.

    Internal nodes without a name are labelled N0, N1, ... in preorder (root =
    N0), matching OrthoFinder's convention for its rooted species tree.
    """

    def __init__(self, newick: str):
        self.root = _parse(newick)
        # name internal nodes in preorder like OrthoFinder (N0 = root)
        k = 0
        used = {n.name for n in self._preorder() if n.name}
        for n in self._preorder():
            if not n.is_leaf and not n.name:
                while f"N{k}" in used:
                    k += 1
                n.name = f"N{k}"
                used.add(n.name)
                k += 1
        self.nodes: List[Node] = list(self._postorder())
        for i, n in enumerate(self.nodes):
            n.idx = i
        names = [n.name for n in self.nodes]
        if len(set(names)) != len(names):
            dup = sorted({x for x in names if names.count(x) > 1})
            raise NewickError(f"duplicated node names: {dup}")
        self.by_name: Dict[str, Node] = {n.name: n for n in self.nodes}
        self.leaves: List[Node] = [n for n in self.nodes if n.is_leaf]

    @classmethod
    def from_file(cls, path: str) -> "Tree":
        with open(path) as fh:
            return cls(fh.read())

    def _preorder(self) -> Iterator[Node]:
        stack = [self.root]
        while stack:
            n = stack.pop()
            yield n
            stack.extend(reversed(n.children))

    def _postorder(self) -> Iterator[Node]:
        out: List[Node] = []
        stack = [(self.root, False)]
        while stack:
            n, seen = stack.pop()
            if seen:
                out.append(n)
            else:
                stack.append((n, True))
                for c in reversed(n.children):
                    stack.append((c, False))
        return iter(out)

    def preorder(self) -> List[Node]:
        return list(self._preorder())

    @property
    def leaf_names(self) -> List[str]:
        return [n.name for n in self.leaves]

    def leaves_under(self, name: str) -> List[str]:
        node = self.by_name[name]
        out, stack = [], [node]
        while stack:
            n = stack.pop()
            if n.is_leaf:
                out.append(n.name)
            stack.extend(n.children)
        return out

    def distance(self, a: str, b: str) -> float:
        """Patristic distance between two nodes. Uses branch lengths when every
        branch on the path has one, otherwise counts branches."""
        m = self.mrca([a, b])
        lens, steps = [], 0
        for nm in (a, b):
            n = self.by_name[nm]
            while n is not m:
                lens.append(n.length)
                steps += 1
                n = n.parent
        if lens and all(x is not None for x in lens):
            return float(sum(lens))
        return float(steps)

    def mrca(self, names: List[str]) -> Node:
        bad = [n for n in names if n not in self.by_name]
        if bad:
            raise KeyError(f"not in species tree: {bad}; leaves are {self.leaf_names}")
        paths = []
        for nm in names:
            p, n = [], self.by_name[nm]
            while n is not None:
                p.append(n)
                n = n.parent
            paths.append(p[::-1])
        m = None
        for level in zip(*paths):
            if all(x is level[0] for x in level):
                m = level[0]
            else:
                break
        assert m is not None
        return m

    def to_newick(self, node: Optional[Node] = None, internal_names: bool = True) -> str:
        node = node or self.root

        def rec(n: Node) -> str:
            s = ""
            if n.children:
                s = "(" + ",".join(rec(c) for c in n.children) + ")"
                if internal_names:
                    s += n.name
            else:
                s = n.name
            if n.length is not None:
                s += f":{n.length:g}"
            return s

        return rec(node) + ";"
