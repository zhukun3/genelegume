"""Collinear block detection from homology hits (MCScanX-style chaining).

The hits come straight from OrthoFinder's WorkingDirectory, so no new
DIAMOND run is needed. Gene positions are ranks along chromosomes.

Scoring (MCScanX defaults): each anchor +match_score; a step between two
anchors costs gap_penalty * (max(dx, dy) - 1); steps longer than max_gap
genes are not allowed; a block needs >= min_anchors anchors.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from .io_genome import GeneTable

try:  # numba JIT-compiles the chaining kernel; optional
    from numba import njit
except Exception:  # pragma: no cover
    def njit(*a, **k):
        if a and callable(a[0]):
            return a[0]
        return lambda f: f


@njit(cache=True)
def _chain_once(x, y, alive, match, gap_pen, max_gap):
    """One DP pass over anchors sorted by (x, y). Returns (dp, prev)."""
    n = x.shape[0]
    dp = np.full(n, -1e18)
    prev = np.full(n, -1, dtype=np.int64)
    for i in range(n):
        if not alive[i]:
            continue
        best = match
        bj = -1
        j = i - 1
        while j >= 0 and x[i] - x[j] <= max_gap + 1:
            if alive[j]:
                dx = x[i] - x[j]
                dy = y[i] - y[j]
                if dx > 0 and dy > 0 and dy <= max_gap + 1:
                    g = dx if dx > dy else dy
                    s = dp[j] + match - gap_pen * (g - 1)
                    if s > best:
                        best = s
                        bj = j
            j -= 1
        dp[i] = best
        prev[i] = bj
    return dp, prev


def chain(x: np.ndarray, y: np.ndarray, match: float = 50.0, gap_pen: float = 1.0,
          max_gap: int = 25, min_anchors: int = 5, max_passes: int = 20) -> List[np.ndarray]:
    """Extract collinear chains (increasing x and y). Returns index arrays.

    DAGchainer-style: one DP pass, then chains are traced back greedily from
    the best-scoring end points; a trace stops at an anchor already used.
    Further passes run on the remaining anchors only while they still yield
    new chains (needed when a good chain was cut by a higher-scoring one).
    """
    if len(x) < min_anchors:
        return []
    order = np.lexsort((y, x))
    xs, ys = x[order].astype(np.int64), y[order].astype(np.int64)
    alive = np.ones(len(xs), dtype=np.bool_)
    chains = []
    min_score = match * min_anchors - gap_pen * max_gap * (min_anchors - 1)
    for _ in range(max_passes):
        if alive.sum() < min_anchors:
            break
        dp, prev = _chain_once(xs, ys, alive, float(match), float(gap_pen), int(max_gap))
        cand = np.where(alive & (dp >= min_score))[0]
        if len(cand) == 0:
            break
        cand = cand[np.argsort(-dp[cand], kind="stable")]
        used = ~alive
        found = 0
        for i in cand:
            if used[i]:
                continue
            path = []
            k = int(i)
            while k != -1 and not used[k]:
                path.append(k)
                k = int(prev[k])
            if len(path) >= min_anchors:
                path = path[::-1]
                used[path] = True
                alive[path] = False
                chains.append(order[np.array(path)])
                found += 1
        if found == 0:
            break
    return chains


@dataclass
class SyntenyResult:
    blocks: pd.DataFrame   # block, sp_a, chr_a, a_lo, a_hi, sp_b, chr_b, b_lo, b_hi, strand, n, score, pid
    anchors: pd.DataFrame  # block, gene_a, gene_b, ia, ib, pident, bits


def find_blocks(hits: pd.DataFrame, ga: GeneTable, gb: GeneTable,
                match: float = 50.0, gap_pen: float = 1.0, max_gap: int = 25,
                min_anchors: int = 5, block_prefix: str = "") -> SyntenyResult:
    """Collinear blocks between genome A (queries) and B (subjects).

    ``hits`` needs columns q, s (already mapped to BED gene IDs), pident, bits.
    For a self comparison (ga is gb) each pair is used once and blocks along
    the main diagonal are excluded.
    """
    same = ga is gb or ga.species == gb.species
    h = hits[hits["q"].isin(ga.pos.keys()) & hits["s"].isin(gb.pos.keys())].copy()
    if h.empty:
        return _empty()
    pa = ga.df.set_index("gene")
    pb = gb.df.set_index("gene")
    h["ca"] = pa.loc[h["q"], "chr"].to_numpy()
    h["ia"] = pa.loc[h["q"], "idx"].to_numpy()
    h["cb"] = pb.loc[h["s"], "chr"].to_numpy()
    h["ib"] = pb.loc[h["s"], "idx"].to_numpy()
    if same:
        # orient every pair as (lower gid, higher gid) and dedupe
        ga_id = pa.loc[h["q"], "gid"].to_numpy()
        gb_id = pb.loc[h["s"], "gid"].to_numpy()
        swap = ga_id > gb_id
        for c1, c2 in (("q", "s"), ("ca", "cb"), ("ia", "ib")):
            a, b = h[c1].to_numpy().copy(), h[c2].to_numpy().copy()
            h[c1] = np.where(swap, b, a)
            h[c2] = np.where(swap, a, b)
        h = h.sort_values("bits", ascending=False).drop_duplicates(["q", "s"])
    blocks, anchors = [], []
    bid = 0
    for (ca, cb), sub in h.groupby(["ca", "cb"], sort=True):
        x = sub["ia"].to_numpy()
        y = sub["ib"].to_numpy()
        for strand, yy in (("+", y), ("-", -y)):
            for idx in chain(x, yy, match, gap_pen, max_gap, min_anchors):
                s = sub.iloc[idx]
                if same and ca == cb and np.all(np.abs(s["ia"].to_numpy() - s["ib"].to_numpy()) <= max_gap):
                    continue  # tandem diagonal, not a segmental block
                name = f"{block_prefix}{bid}"
                bid += 1
                blocks.append((name, ga.species, ca, int(s["ia"].min()), int(s["ia"].max()),
                               gb.species, cb, int(s["ib"].min()), int(s["ib"].max()),
                               strand, len(s), float(len(s) * match), float(s["pident"].median())))
                anchors.append(pd.DataFrame({
                    "block": name, "gene_a": s["q"].to_numpy(), "gene_b": s["s"].to_numpy(),
                    "ia": s["ia"].to_numpy(), "ib": s["ib"].to_numpy(),
                    "pident": s["pident"].to_numpy(), "bits": s["bits"].to_numpy()}))
    if not blocks:
        return _empty()
    bdf = pd.DataFrame(blocks, columns=["block", "sp_a", "chr_a", "a_lo", "a_hi", "sp_b",
                                        "chr_b", "b_lo", "b_hi", "strand", "n", "score", "pid"])
    return SyntenyResult(bdf, pd.concat(anchors, ignore_index=True))


def _empty() -> SyntenyResult:
    return SyntenyResult(
        pd.DataFrame(columns=["block", "sp_a", "chr_a", "a_lo", "a_hi", "sp_b", "chr_b",
                              "b_lo", "b_hi", "strand", "n", "score", "pid"]),
        pd.DataFrame(columns=["block", "gene_a", "gene_b", "ia", "ib", "pident", "bits"]))


def rank_blocks_by_depth(res: SyntenyResult, side: str = "a") -> pd.Series:
    """For each anchor, rank (1 = best) of its block among all blocks covering
    the anchor's gene position on ``side`` (by block median identity).

    Used to keep only the expected number of orthologous layers when the other
    genome carries extra WGD copies (e.g. Glycine vs Medicago -> 2 layers).
    """
    if res.anchors.empty:
        return pd.Series(dtype=int)
    b = res.blocks.set_index("block")
    chr_col, lo, hi = (("chr_a", "a_lo", "a_hi") if side == "a" else ("chr_b", "b_lo", "b_hi"))
    pos_col = "ia" if side == "a" else "ib"
    an = res.anchors
    chrs = b.loc[an["block"], chr_col].to_numpy()
    pos = an[pos_col].to_numpy()
    own_pid = b.loc[an["block"], "pid"].to_numpy()
    ranks = np.ones(len(an), dtype=int)
    for c, bb in res.blocks.groupby(chr_col):
        m = chrs == c
        if not m.any():
            continue
        p = pos[m][:, None]
        cover = (bb[lo].to_numpy()[None, :] <= p) & (bb[hi].to_numpy()[None, :] >= p)
        better = cover & (bb["pid"].to_numpy()[None, :] > own_pid[m][:, None])
        ranks[m] = 1 + better.sum(axis=1)
    return pd.Series(ranks, index=an.index)


def orthologous_anchors(res: SyntenyResult, depth_ab: int, depth_ba: int,
                        pid_delta: float = 10.0) -> pd.DataFrame:
    """Keep anchors from blocks that are among the top ``depth`` layers on both
    sides and whose median identity is within ``pid_delta`` of the best layer.

    depth_ab = expected number of B copies per A locus (product of WGD
    multipliers on the B lineage since the A-B split), and vice versa.
    """
    an = res.anchors.copy()
    if an.empty:
        return an
    an["rank_a"] = rank_blocks_by_depth(res, "a")
    an["rank_b"] = rank_blocks_by_depth(res, "b")
    pid = res.blocks.set_index("block")["pid"]
    an["bpid"] = pid.loc[an["block"]].to_numpy()
    best_a = an.groupby("gene_a")["bpid"].transform("max")
    best_b = an.groupby("gene_b")["bpid"].transform("max")
    keep = ((an["rank_a"] <= depth_ab) & (an["rank_b"] <= depth_ba) &
            (an["bpid"] >= best_a - pid_delta) & (an["bpid"] >= best_b - pid_delta))
    return an[keep].reset_index(drop=True)
