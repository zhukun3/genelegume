"""End-to-end pipeline: prepare -> synteny -> hoc -> recon.

Every step reads/writes files under cfg['workdir'] so steps can be rerun
independently (and the synteny step resumes pair by pair).
"""
from __future__ import annotations

import os
import sys
import time
from functools import reduce
from multiprocessing import get_context
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from . import absence as ab
from .config import species_file
from .dupmode import duplication_modes, local_clusters
from .hoc import assign_unanchored, build_hocs, cluster_edges
from .io_genome import GeneTable, read_bed, read_gaps, read_gff, scan_gaps, write_gaps
from .io_orthofinder import OrthoFinderResults
from .recon import (Costs, aggregate_accessions, branch_summary, origin_table,
                    reconstruct, to_cafe)
from .synteny import find_blocks, orthologous_anchors
from .tree import Tree


def log(msg: str) -> None:
    print(time.strftime("[%H:%M:%S] ") + msg, file=sys.stderr, flush=True)


# ===================================================================== context
class Context:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.wd = cfg["workdir"]
        os.makedirs(self.wd, exist_ok=True)
        self.of = OrthoFinderResults(cfg["orthofinder"], cfg.get("orthofinder_workdir"))
        tpath = cfg.get("tree") or self.of.species_tree_path()
        if not tpath:
            raise ValueError("no species tree: set 'tree' in the config")
        self.tree = Tree.from_file(tpath)
        self.wgd = self._resolve_wgd(cfg.get("wgd") or [])
        self.parent_of = {}        # subgenome leaf -> OrthoFinder species
        for parent, subs in (cfg.get("subgenomes") or {}).items():
            for sub in subs:
                self.parent_of[sub] = parent
        self.leaf_of = {}          # OrthoFinder species (accession) -> tree leaf
        for leaf, accs in (cfg.get("accessions") or {}).items():
            for a in accs:
                self.leaf_of[a] = leaf
        self.scope_node = self._scope_node()
        self.scope_species: List[str] = []
        self.genes: Dict[str, GeneTable] = {}
        self._all_species = None

    # ------------------------------------------------------------------
    def _resolve_wgd(self, items) -> Dict[str, int]:
        out: Dict[str, int] = {}
        for it in items:
            if "node" in it:
                node = it["node"]
            else:
                node = self.tree.mrca(list(it["mrca"])).name
            if node not in self.tree.by_name:
                raise ValueError(f"WGD node {node} not in tree")
            out[node] = out.get(node, 1) * int(it.get("multiplier", 2))
        return out

    def _scope_node(self) -> str:
        sc = self.cfg["synteny"].get("scope")
        if not sc:
            return self.tree.root.name
        try:
            return self.tree.mrca(list(sc)).name
        except KeyError as exc:
            raise ValueError(exc.args[0]) from exc

    def species_list(self) -> List[str]:
        """OrthoFinder species (family table columns)."""
        if self._all_species is None:
            fam = self.families()
            self._all_species = sorted(fam["species"].unique())
        return self._all_species

    def leaf(self, sp: str) -> str:
        return self.leaf_of.get(sp, sp)

    def parent(self, sp: str) -> str:
        """OrthoFinder species holding this (sub)genome."""
        return self.parent_of.get(sp, sp)

    def file(self, sp: str, kind: str):
        return species_file(self.cfg, self.parent(sp), kind)

    def hits(self, a: str, b: str, **kw) -> pd.DataFrame:
        return self.of.hits(self.parent(a), self.parent(b), **kw)

    def annotation(self, sp: str, fam: pd.DataFrame) -> Optional[GeneTable]:
        parent = self.parent(sp)
        files = self.cfg["species"].get(parent, {})
        bed, gff = files.get("bed"), files.get("gff")
        if not (bed or gff):
            bed, gff = self.file(sp, "bed"), self.file(sp, "gff")
        if bed:
            return read_bed(bed, sp)
        if gff:
            subgenomes = (self.cfg.get("subgenomes") or {}).get(parent, {})
            proteins = fam.loc[fam["species"].isin([parent, *subgenomes]), "gene"]
            return read_gff(gff, sp, proteins, self.cfg.get("id_strip"))
        return None

    def load_genes(self) -> None:
        scope_leaves = set(self.tree.leaves_under(self.scope_node))
        missing = []
        for sp in self.species_list():
            if self.leaf(sp) not in scope_leaves:
                continue
            gt = self.annotation(sp, self.families())
            if gt is None:
                missing.append(sp)
                continue
            if sp in self.parent_of:
                chrs = set(self.cfg["subgenomes"][self.parent(sp)][sp])
                gt = GeneTable(sp, gt.df[gt.df["chr"].isin(chrs)][["chr", "start", "end", "gene", "strand"]].copy())
            self.genes[sp] = gt
            self.scope_species.append(sp)
        if missing and self.cfg.get("require_annotations"):
            raise ValueError("missing BED or GFF3 annotation for: " + ", ".join(missing)
                             + ". Use the OrthoFinder species names as filenames.")
        for sp in missing:
            log(f"warning: no BED or GFF3 for {sp}; excluded from synteny")

    def families(self) -> pd.DataFrame:
        p = os.path.join(self.wd, "families.tsv.gz")
        if not hasattr(self, "_fam"):
            self._fam = pd.read_csv(p, sep="\t", dtype=str)
        return self._fam

    def depth(self, a: str, b: str) -> int:
        """Expected copies in b per locus of a from WGDs on b's lineage since a-b split."""
        la, lb = self.leaf(a), self.leaf(b)
        m = self.tree.mrca([la, lb])
        d, n = 1, self.tree.by_name[lb]
        while n is not None and n is not m:
            d *= self.wgd.get(n.name, 1)
            n = n.parent
        return d

    def scope_depth(self, sp: str) -> int:
        d, n = 1, self.tree.by_name[self.leaf(sp)]
        root = self.tree.by_name[self.scope_node]
        while n is not None and n is not root:
            d *= self.wgd.get(n.name, 1)
            n = n.parent
        return d

    def path(self, *parts) -> str:
        p = os.path.join(self.wd, *parts)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        return p


# ===================================================================== prepare
def step_prepare(cfg: dict) -> None:
    ctx = Context(cfg)
    log("reading OrthoFinder families")
    fam = ctx.of.families(cfg["family_level"], cfg["include_unassigned"])
    fam = _split_subgenomes(ctx, fam)
    tree_leaves = set(ctx.tree.leaf_names)
    sp_in = set(fam["species"])
    leaves_of = {ctx.leaf(s) for s in sp_in}
    miss = sorted(tree_leaves - leaves_of)
    extra = sorted(s for s in sp_in if ctx.leaf(s) not in tree_leaves)
    if miss:
        raise ValueError(f"tree leaves missing from OrthoFinder species: {miss}")
    if extra:
        log(f"warning: OrthoFinder species not in tree, ignored: {extra}")
        fam = fam[~fam["species"].isin(extra)]
    import re
    strip = re.compile(cfg["id_strip"]) if cfg.get("id_strip") else None
    fam["bed_id"] = pd.Series([None] * len(fam), index=fam.index, dtype=object)
    ctx._fam = fam
    ctx._all_species = sorted(fam["species"].unique())
    ctx.load_genes()
    rows = []
    for sp, gt in ctx.genes.items():
        m = fam["species"] == sp
        names = fam.loc[m, "gene"]
        mapped = names.where(names.isin(gt.pos.keys()))
        if strip is not None:
            alt = names.str.replace(strip, "", regex=True)
            mapped = mapped.fillna(alt.where(alt.isin(gt.pos.keys())))
        fam.loc[m, "bed_id"] = mapped.astype(object)
        rate = mapped.notna().mean()
        rows.append((sp, len(names), int(mapped.notna().sum()), round(rate, 4)))
        if rate < 0.9:
            log(f"warning: only {rate:.1%} of {sp} proteins matched annotation IDs (check id_strip)")
    pd.DataFrame(rows, columns=["species", "proteins", "mapped", "rate"]).to_csv(
        ctx.path("id_match.tsv"), sep="\t", index=False)
    unmapped = [sp for sp, _, n, _ in rows if n == 0]
    if unmapped:
        raise ValueError("no OrthoFinder protein IDs match the annotation for: " + ", ".join(unmapped)
                         + ". Check the annotation IDs or adjust id_strip. See id_match.tsv.")
    # gene IDs must be unique across species for the gene-keyed indexes
    b = fam.dropna(subset=["bed_id"])
    if b.groupby("bed_id")["species"].nunique().gt(1).any():
        ex = b.groupby("bed_id")["species"].nunique()
        raise ValueError(f"gene IDs shared between species, e.g. {ex[ex > 1].index[:5].tolist()}; "
                         "prefix IDs with the species name")
    fam.to_csv(ctx.path("families.tsv.gz"), sep="\t", index=False)
    log(f"families: {fam['family'].nunique()} families, {len(fam)} genes, "
        f"{len(ctx.genes)} species with synteny data (scope {ctx.scope_node})")


def _split_subgenomes(ctx: Context, fam: pd.DataFrame) -> pd.DataFrame:
    """Reassign genes of polyploid species to subgenome leaves by chromosome."""
    import re as _re
    subs = ctx.cfg.get("subgenomes") or {}
    if not subs:
        return fam
    strip = _re.compile(ctx.cfg["id_strip"]) if ctx.cfg.get("id_strip") else None
    for parent, parts in subs.items():
        annotation = ctx.annotation(parent, fam)
        if annotation is None:
            raise ValueError(f"subgenomes: no BED or GFF3 for {parent}")
        b = annotation.df
        chr_of = dict(zip(b["gene"], b["chr"]))
        sub_of_chr = {c: sub for sub, chrs in parts.items() for c in chrs}
        m = fam["species"] == parent
        g = fam.loc[m, "gene"]
        chrom = g.map(chr_of)
        if strip is not None:
            chrom = chrom.fillna(g.str.replace(strip, "", regex=True).map(chr_of))
        sub = chrom.map(sub_of_chr)
        n_un = int(sub.isna().sum())
        if n_un:
            log(f"subgenomes: {n_un} {parent} genes on unassigned chromosomes dropped")
        fam.loc[m, "species"] = sub
        fam = fam.dropna(subset=["species"])
        log(f"subgenomes: {parent} -> " + ", ".join(f"{k} ({(fam['species'] == k).sum()} genes)" for k in parts))
    return fam


# ===================================================================== synteny
_G: dict = {}


def _init_worker(ctx: Context, idmap: Dict[str, Dict[str, str]], fam_of: Optional[Dict[str, str]] = None):
    _G["ctx"] = ctx
    _G["idmap"] = idmap
    _G["fam_of"] = fam_of or {}


def _hits_mapped(ctx: Context, idmap, a: str, b: str) -> pd.DataFrame:
    sc = ctx.cfg["synteny"]
    h = ctx.hits(a, b, evalue=sc["evalue"], top=sc["top_hits"])
    h["q"] = h["q"].map(idmap[a])
    h["s"] = h["s"].map(idmap[b])
    return h.dropna(subset=["q", "s"])


def _pair_job(pair: Tuple[str, str]) -> str:
    a, b = pair
    ctx: Context = _G["ctx"]
    idmap = _G["idmap"]
    sc = ctx.cfg["synteny"]
    out_b = ctx.path("synteny", f"{a}__{b}.blocks.tsv.gz")
    out_a = ctx.path("synteny", f"{a}__{b}.anchors.tsv.gz")
    out_e = ctx.path("synteny", f"{a}__{b}.evidence.tsv.gz")
    need_ev = a != b and not os.path.exists(out_e)
    if os.path.exists(out_a) and os.path.exists(out_b) and not need_ev:
        return f"{a}-{b} cached"
    h = _hits_mapped(ctx, idmap, a, b)
    if a != b:
        h2 = _hits_mapped(ctx, idmap, b, a).rename(columns={"q": "s", "s": "q"})
        h = pd.concat([h, h2[h.columns]], ignore_index=True)
        h = h.sort_values("bits", ascending=False).drop_duplicates(["q", "s"])
    msg = f"{a}-{b}"
    if os.path.exists(out_a) and os.path.exists(out_b):
        an = pd.read_csv(out_a, sep="\t", dtype={"gene_a": str, "gene_b": str})
        msg += " blocks cached"
    else:
        res = find_blocks(h, ctx.genes[a], ctx.genes[b], match=sc["match_score"],
                          gap_pen=sc["gap_penalty"], max_gap=sc["max_gap"],
                          min_anchors=sc["min_anchors"], block_prefix=f"{a}__{b}#")
        an = res.anchors
        if a != b and not an.empty:
            orth = orthologous_anchors(res, ctx.depth(a, b), ctx.depth(b, a), sc["pid_delta"])
            key = set(zip(orth["gene_a"], orth["gene_b"]))
            an = an.assign(orth=[(x, y) in key for x, y in zip(an["gene_a"], an["gene_b"])])
        else:
            an = an.assign(orth=False)
        res.blocks.to_csv(out_b + ".tmp", sep="\t", index=False, compression="gzip")
        an.to_csv(out_a + ".tmp", sep="\t", index=False, compression="gzip")
        os.replace(out_b + ".tmp", out_b)
        os.replace(out_a + ".tmp", out_a)
        msg += f": {len(res.blocks)} blocks, {int(an['orth'].sum()) if len(an) else 0} orth anchors"
    if need_ev:
        msg += "; " + _evidence_job(ctx, a, b, h, an, out_e)
    return msg


def _evidence_job(ctx: Context, a: str, b: str, hits: pd.DataFrame, anchors: pd.DataFrame,
                  out_e: str) -> str:
    """Synteny/homology scores of all same-family pairs of a genome pair, plus
    the pair statistics used to choose alpha (see evidence.py)."""
    from . import evidence as evm
    ecfg = ctx.cfg["evidence"]
    orth = anchors[anchors["orth"].astype(bool)] if not anchors.empty else anchors
    ev = evm.pair_evidence(hits, _G.get("fam_of", {}), orth, ecfg["window"])
    cov, n_rbh = evm.synteny_coverage(ev)
    k_ab, k_ba = ctx.depth(a, b), ctx.depth(b, a)
    a_rbk, counts = evm.scan_alpha(ev, k_ab, k_ba) if ecfg.get("scan", True) else (float("nan"), {})
    ev.to_csv(out_e + ".tmp", sep="\t", index=False, compression="gzip", float_format="%.4g")
    evm.write_stats(out_e.replace(".evidence.tsv.gz", ".alpha.json"), a=a, b=b, k_ab=k_ab, k_ba=k_ba,
                    coverage=cov, n_rbh=n_rbh, alpha_rbk=a_rbk, n_pairs=int(len(ev)),
                    rbk_counts={str(k): v for k, v in counts.items()},
                    distance=ctx.tree.distance(ctx.leaf(a), ctx.leaf(b)))
    os.replace(out_e + ".tmp", out_e)
    return f"coverage {cov:.2f}, rbk alpha {a_rbk:.2f}"


def _idmap(ctx: Context) -> Dict[str, Dict[str, str]]:
    fam = ctx.families().dropna(subset=["bed_id"])
    return {sp: dict(zip(g["gene"], g["bed_id"])) for sp, g in fam.groupby("species")}


def step_synteny(cfg: dict) -> None:
    ctx = Context(cfg)
    ctx.load_genes()
    if not ctx.of.has_hits():
        raise ValueError("OrthoFinder WorkingDirectory with Blast*_*.txt(.gz) files not found; "
                         "rerun OrthoFinder without deleting them or set orthofinder_workdir")
    sps = ctx.scope_species
    pairs = [(a, b) for i, a in enumerate(sps) for b in sps[i:]]
    idmap = _idmap(ctx)
    fs = ctx.families().dropna(subset=["bed_id"])
    fam_of = dict(zip(fs["bed_id"], fs["family"]))
    log(f"synteny: {len(pairs)} genome pairs on {cfg['threads']} threads")
    if cfg["threads"] > 1:
        with get_context("fork").Pool(cfg["threads"], _init_worker, (ctx, idmap, fam_of)) as pool:
            for k, msg in enumerate(pool.imap_unordered(_pair_job, pairs), 1):
                log(f"  [{k}/{len(pairs)}] {msg}")
    else:
        _init_worker(ctx, idmap, fam_of)
        for k, p in enumerate(pairs, 1):
            log(f"  [{k}/{len(pairs)}] {_pair_job(p)}")


def _load_pair(ctx: Context, a: str, b: str, what: str) -> pd.DataFrame:
    p = ctx.path("synteny", f"{a}__{b}.{what}.tsv.gz")
    if os.path.exists(p):
        return pd.read_csv(p, sep="\t", dtype={"gene_a": str, "gene_b": str})
    return pd.DataFrame()


# ========================================================================= hoc
def step_hoc(cfg: dict) -> None:
    ctx = Context(cfg)
    ctx.load_genes()
    fam = ctx.families()
    sps = ctx.scope_species
    fs = fam[fam["species"].isin(sps)].dropna(subset=["bed_id"])
    fam_of = dict(zip(fs["bed_id"], fs["family"]))
    sp_of = dict(zip(fs["bed_id"], fs["species"]))
    cc = cfg["clusters"]

    log("local clusters")
    cluster_of: Dict[str, str] = {}
    for sp in sps:
        cluster_of.update(local_clusters(ctx.genes[sp], fam_of, cc["cluster_gap"]).to_dict())
    clusters = pd.DataFrame({"cluster": list(cluster_of.values())}).drop_duplicates()
    clusters["species"] = clusters["cluster"].str.split("|").str[0]
    clusters["family"] = clusters["cluster"].str.split("|").str[1]

    log("loading orthologous anchors")
    orth_tables, self_anchor_genes, anc_genes = [], {s: set() for s in sps}, {s: set() for s in sps}
    pair_orth: Dict[Tuple[str, str], pd.DataFrame] = {}
    for i, a in enumerate(sps):
        for b in sps[i:]:
            an = _load_pair(ctx, a, b, "anchors")
            if an.empty:
                continue
            if a == b:
                self_anchor_genes[a].update(an["gene_a"]); self_anchor_genes[a].update(an["gene_b"])
                continue
            o = an[an["orth"].astype(bool)]
            pair_orth[(a, b)] = o
            orth_tables.append(o)
            anc_genes[a].update(o["gene_a"]); anc_genes[b].update(o["gene_b"])
    ecfg = cfg["evidence"]
    if ecfg["mode"] == "weighted":
        log("weighted synteny/homology edges")
        edges, syn_clusters = _weighted_edges(ctx, sps, cluster_of, fam_of)
    elif ecfg["mode"] == "synteny_first":
        edges = cluster_edges(orth_tables, cluster_of, fam_of)
        syn_clusters = None
    else:
        raise ValueError(f"evidence.mode must be synteny_first or weighted, not {ecfg['mode']!r}")
    edges = edges[edges["c1"].str.split("|").str[0] != edges["c2"].str.split("|").str[0]]
    if syn_clusters is None:
        syn_clusters = set(edges["c1"]) | set(edges["c2"])
    young = _young_block_edges(ctx, pair_orth, cluster_of, fam_of)
    if not young.empty:
        log(f"edges from blocks younger than the scope root: {len(young)}")
        edges = pd.concat([edges, young], ignore_index=True)
        edges = edges.groupby(["family", "c1", "c2"], as_index=False)["w"].sum()

    log("duplication modes")
    modes = []
    idmap_all = _idmap(ctx)
    for sp in sps:
        try:
            sh = ctx.hits(sp, sp, evalue=cfg["synteny"]["evalue"], top=cfg["synteny"]["top_hits"])
            idm = idmap_all[sp]
            sh["q"], sh["s"] = sh["q"].map(idm), sh["s"].map(idm)
            sh = sh.dropna(subset=["q", "s"])
        except Exception:
            sh = None
        modes.append(duplication_modes(ctx.genes[sp], fam_of, sh, self_anchor_genes[sp],
                                       anc_genes[sp], cc["tandem_gap"], cc["proximal_gap"]))
    modes = pd.concat(modes, ignore_index=True)
    modes.to_csv(ctx.path("hoc", "duplication_modes.tsv.gz"), sep="\t", index=False)

    log(f"building HOCs from {len(edges)} cluster edges")
    max_depth = {sp: ctx.scope_depth(sp) for sp in sps}
    hoc_of_cluster = build_hocs(clusters, edges, max_depth, cfg["hoc"]["method"],
                                cfg["hoc"]["inflation"])
    genes = pd.DataFrame({"gene": list(cluster_of.keys()), "cluster": list(cluster_of.values())})
    genes["species"] = genes["gene"].map(sp_of)
    genes["family"] = genes["gene"].map(fam_of)
    linked = set(edges["c1"]) | set(edges["c2"])
    genes["evidence"] = np.where(genes["cluster"].isin(syn_clusters | set(young["c1"] if not young.empty else [])
                                                      | set(young["c2"] if not young.empty else [])),
                                 "synteny", np.where(genes["cluster"].isin(linked), "homology", "none"))
    genes["hoc"] = genes["cluster"].map(hoc_of_cluster)

    log("projecting loci for zero cells")
    states = _zero_states(ctx, genes, pair_orth)
    n = _positional_rescue(ctx, genes, states)
    log(f"positional rescue: {n} unanchored clusters placed in their HOC's projected interval")
    if n:
        present = set(zip(genes["hoc"], genes["species"]))
        keep = [(h, s_) not in present for h, s_ in zip(states["hoc"], states["species"])]
        states = states[keep]
        states = states[states["hoc"].isin(set(genes["hoc"]))].reset_index(drop=True)

    if cfg["hoc"].get("fallback", True):
        n = _fallback(ctx, genes, states)
        log(f"fallback: {n} unanchored clusters joined HOCs without syntenic context")
        present = set(zip(genes["hoc"], genes["species"]))
        states = states[[ (h, s) not in present for h, s in zip(states["hoc"], states["species"])]]
        states = states[states["hoc"].isin(set(genes["hoc"]))]

    abs_cfg = cfg["absence"]
    if abs_cfg.get("miniprot"):
        states = _sequence_check(ctx, genes, states)

    genes = genes.merge(modes[["gene", "mode"]], on="gene", how="left")
    genes[["hoc", "family", "species", "gene", "cluster", "evidence", "mode"]].to_csv(
        ctx.path("hoc", "hoc_genes.tsv.gz"), sep="\t", index=False)
    states.to_csv(ctx.path("hoc", "hoc_zero_states.tsv.gz"), sep="\t", index=False)
    counts = genes.groupby(["hoc", "species"]).size().unstack(fill_value=0)
    counts = counts.reindex(columns=sps, fill_value=0)
    rule = ab.COUNT_RULE.copy()
    if not abs_cfg.get("rescue_unannotated", True):
        rule["unannotated"] = 0.0
    sw = (states.pivot(index="hoc", columns="species", values="state")
          .reindex(index=counts.index, columns=counts.columns) if not states.empty
          else pd.DataFrame(np.nan, index=counts.index, columns=counts.columns, dtype=object))
    zero = (counts == 0).to_numpy()
    has = sw.notna().to_numpy()
    vals = sw.apply(lambda c: c.map(rule)).to_numpy(dtype=float)
    mat = counts.astype(float).to_numpy().copy()
    mat[zero & has] = vals[zero & has]
    mat = pd.DataFrame(mat, index=counts.index, columns=counts.columns)
    mat.to_csv(ctx.path("hoc", "hoc_matrix.tsv"), sep="\t")
    st = np.where(~zero, "present", np.where(has, sw.to_numpy(), "absent"))
    st = pd.DataFrame(st, index=counts.index, columns=counts.columns)
    st.to_csv(ctx.path("hoc", "hoc_state.tsv"), sep="\t")
    summ = st.apply(pd.Series.value_counts).fillna(0).astype(int).T
    summ.to_csv(ctx.path("hoc", "state_summary_by_species.tsv"), sep="\t")
    log(f"HOCs: {mat.shape[0]} loci in {genes['family'].nunique()} families")


def _weighted_edges(ctx: Context, sps: List[str], cluster_of: Dict[str, str],
                    fam_of: Dict[str, str]) -> Tuple[pd.DataFrame, set]:
    """Cluster edges from reciprocal top-k gene pairs ranked by
    HMS = alpha * synteny + (1 - alpha) * homology (see evidence.py).
    Returns (edges, clusters with at least one syntenic edge)."""
    from . import evidence as evm
    ecfg = ctx.cfg["evidence"]
    rows, missing = [], []
    for i, a in enumerate(sps):
        for b in sps[i + 1:]:
            js = ctx.path("synteny", f"{a}__{b}.alpha.json")
            if not os.path.exists(js):
                missing.append(f"{a}-{b}")
                continue
            st = evm.read_stats(js)
            rows.append({"a": a, "b": b, "distance": st["distance"], "coverage": st["coverage"],
                         "n_rbh": st["n_rbh"], "alpha_rbk": st["alpha_rbk"], "k_ab": st["k_ab"],
                         "k_ba": st["k_ba"], "n_pairs": st["n_pairs"]})
    if missing:
        raise ValueError("synteny evidence missing for " + ", ".join(missing[:5])
                         + "; rerun `genelegume synteny` (only the missing parts are computed)")
    stats = pd.DataFrame(rows)
    if stats.empty:
        return pd.DataFrame(columns=["family", "c1", "c2", "w"]), set()
    stats.index = list(zip(stats["a"], stats["b"]))
    alpha, params = evm.choose_alpha(stats, ecfg["alpha"])
    stats["alpha"] = alpha
    if params:
        stats["coverage_fit"] = evm.decay_value(params, stats["distance"])
        log(f"  synteny decay fit: top={params[0]:.2f}, midpoint distance={params[1]:.3g}, scale={params[2]:.3g}")
    tau = float(ecfg["tau"])
    parts, syn = [], set()
    for (a, b), r in stats.iterrows():
        ev = pd.read_csv(ctx.path("synteny", f"{a}__{b}.evidence.tsv.gz"), sep="\t",
                         dtype={"gene_a": str, "gene_b": str})
        sel = evm.select_edges(ev, float(r["alpha"]), int(r["k_ab"]), int(r["k_ba"]), tau)
        stats.loc[[(a, b)], "n_edges"] = len(sel)
        stats.loc[[(a, b)], "n_homology_only"] = int((sel["s"] == 0).sum())
        if sel.empty:
            continue
        c1, c2 = sel["gene_a"].map(cluster_of), sel["gene_b"].map(cluster_of)
        ok = c1.notna() & c2.notna()
        e = pd.DataFrame({"c1": c1[ok].to_numpy(), "c2": c2[ok].to_numpy(),
                          "family": sel.loc[ok, "gene_a"].map(fam_of).to_numpy(),
                          "w": sel.loc[ok, "hms"].to_numpy(), "s": sel.loc[ok, "s"].to_numpy()})
        syn.update(e.loc[e["s"] > 0, "c1"]); syn.update(e.loc[e["s"] > 0, "c2"])
        parts.append(e)
    out = stats.drop(columns=[]).reset_index(drop=True)
    out.to_csv(ctx.path("hoc", "pair_alpha.tsv"), sep="\t", index=False, float_format="%.4g")
    try:
        evm.plot_decay(stats, params, ctx.path("hoc", "synteny_decay.pdf"))
    except Exception as exc:  # plotting is optional
        log(f"decay plot skipped: {exc}")
    log(f"  {len(stats)} genome pairs, alpha {stats['alpha'].min():.2f}-{stats['alpha'].max():.2f}, "
        f"{int(stats['n_edges'].sum())} gene-pair edges ({int(stats['n_homology_only'].sum())} homology-only)")
    if not parts:
        return pd.DataFrame(columns=["family", "c1", "c2", "w"]), syn
    e = pd.concat(parts, ignore_index=True)
    lo = np.where(e["c1"] < e["c2"], e["c1"], e["c2"])
    hi = np.where(e["c1"] < e["c2"], e["c2"], e["c1"])
    e["c1"], e["c2"] = lo, hi
    return e.groupby(["family", "c1", "c2"], as_index=False)["w"].sum(), syn


def _young_block_edges(ctx: Context, pair_orth, cluster_of, fam_of) -> pd.DataFrame:
    """Edges from collinear blocks younger than the scope root.

    By definition a HOC holds every copy descended from one locus at the scope
    root, so syntenic pairs created by in-scope WGDs belong together even when
    they are paralogous (e.g. papilionoid WGD copy b of Medicago vs copy a of
    soybean when Medicago's copy a is lost or unassembled). For two species on
    the same side of the root (including a species with itself), a block is
    kept if its median identity is >= the median identity of orthologous
    anchors that cross the scope root for these species. Pairs that span the
    root only contribute orthologous anchors.
    """
    mode = ctx.cfg["hoc"].get("young_blocks", True)
    if not mode:
        return pd.DataFrame(columns=["family", "c1", "c2", "w"])
    root = ctx.tree.by_name[ctx.scope_node]
    side = {}
    for ch in root.children:
        for l in ctx.tree.leaves_under(ch.name):
            side[l] = ch.name
    thr = {}
    for sp in ctx.scope_species:
        pids = [o["pident"].to_numpy() for (a, b), o in pair_orth.items()
                if sp in (a, b) and side.get(ctx.leaf(b if a == sp else a)) != side.get(ctx.leaf(sp))]
        thr[sp] = float(np.median(np.concatenate(pids))) if pids else ctx.cfg["hoc"].get("self_min_pid", 70.0)
    sps = ctx.scope_species
    tabs = []
    for i, a in enumerate(sps):
        for b in sps[i:]:
            if side.get(ctx.leaf(a)) != side.get(ctx.leaf(b)):
                continue
            an = _load_pair(ctx, a, b, "anchors")
            if an.empty:
                continue
            t = max(thr[a], thr[b])
            bp = an.groupby("block")["pident"].median()
            keep = bp[bp >= t].index
            sub = an[an["block"].isin(keep) & ~an["orth"].astype(bool)]
            if not sub.empty:
                tabs.append(sub)
    if not tabs:
        return pd.DataFrame(columns=["family", "c1", "c2", "w"])
    e = cluster_edges(tabs, cluster_of, fam_of)
    log("  identity thresholds (cross-root ortholog median): " +
        ", ".join(f"{k}={v:.1f}" for k, v in thr.items()))
    return e[e["c1"] != e["c2"]]


def _positional_rescue(ctx: Context, genes: pd.DataFrame, states: pd.DataFrame) -> int:
    """An unanchored cluster whose genes lie inside the projected interval of
    a same-family HOC that is 'absent' in this species is that HOC's copy
    (anchors were missing, e.g. near a breakpoint or outside the top hits)."""
    cand = states[states["state"].isin(["absent", "NA_gap"]) & (states["start"] >= 0)].copy()
    if cand.empty:
        return 0
    cand["family"] = cand["hoc"].str.rsplit(".L", n=1).str[0]
    cand["span"] = cand["end"] - cand["start"]
    un = genes[genes["evidence"] == "none"]
    if un.empty:
        return 0
    moved = {}
    for s, us in un.groupby("species"):
        pos = ctx.genes[s].df.set_index("gene")
        locations = pos.loc[us["gene"]]
        u = us[["family", "cluster"]].assign(
            chr=locations["chr"].to_numpy(),
            gs=locations["start"].to_numpy(),
            ge=locations["end"].to_numpy(),
        )
        c = cand[cand["species"] == s]
        j = u.merge(c[["hoc", "family", "chr", "start", "end", "span"]], on=["family", "chr"])
        j = j[(j["gs"] >= j["start"]) & (j["ge"] <= j["end"])]
        if j.empty:
            continue
        j = j.sort_values("span").drop_duplicates("cluster")
        j = j.drop_duplicates("hoc")  # one cluster per HOC
        moved.update(dict(zip(j["cluster"], j["hoc"])))
    for cl, h in moved.items():
        m = genes["cluster"] == cl
        genes.loc[m, "hoc"] = h
        genes.loc[m, "evidence"] = "position"
    return len(moved)


def _zero_states(ctx: Context, genes: pd.DataFrame,
                 pair_orth: Dict[Tuple[str, str], pd.DataFrame]) -> pd.DataFrame:
    sps = ctx.scope_species
    present = genes.groupby("hoc")["species"].agg(set)
    all_hocs = present.index.to_numpy()
    out = []
    gap_min = ctx.cfg["absence"]["gap_min"]
    for s in sps:
        projs = []
        for r in sps:
            if r == s:
                continue
            key, r_is_a = ((r, s), True) if (r, s) in pair_orth else ((s, r), False)
            an = pair_orth.get(key)
            if an is None or an.empty:
                continue
            projs.append(ab.project_genes(an, ctx.genes[r], ctx.genes[s], r_is_a,
                                          ctx.cfg["absence"]["max_span"]))
        proj = pd.concat(projs, ignore_index=True) if projs else pd.DataFrame(
            columns=["gene", "chr_s", "lo", "hi", "span"])
        zero = pd.DataFrame({"hoc": [h for h in all_hocs if s not in present[h]]})
        if zero.empty:
            continue
        gaps = None
        fa = ctx.file(s, "genome")
        if fa:
            gp = ctx.path("gaps", f"{s}.gaps.tsv")
            if not os.path.exists(gp):
                write_gaps(scan_gaps(fa, gap_min), gp)
            gaps = read_gaps(gp)
        res = ab.zero_cells_context(zero, genes[genes["species"] != s][["hoc", "gene"]],
                                    proj, ctx.genes[s], gaps)
        res.insert(1, "species", s)
        out.append(res)
    if not out:
        return pd.DataFrame(columns=["hoc", "species", "state", "chr", "start", "end",
                                     "n_support", "verified"])
    return pd.concat(out, ignore_index=True)


def _fallback(ctx: Context, genes: pd.DataFrame, states: pd.DataFrame) -> int:
    """Attach unanchored clusters to a HOC via best same-family hit when the
    HOC has no syntenic context in that species (eroded synteny)."""
    idmap = _idmap(ctx)
    na_cells = set(zip(states.loc[states["state"] == "NA_nocontext", "hoc"],
                       states.loc[states["state"] == "NA_nocontext", "species"]))
    un = genes[genes["evidence"] == "none"]
    if un.empty or not na_cells:
        return 0
    syn = genes[genes["evidence"].isin(["synteny", "homology"])]
    hoc_of_gene = dict(zip(syn["gene"], syn["hoc"]))
    fam_of = dict(zip(genes["gene"], genes["family"]))
    best: Dict[str, Tuple[float, str]] = {}
    for s, sub in un.groupby("species"):
        want = set(sub["gene"])
        for r in ctx.scope_species:
            if r == s:
                continue
            try:
                h = ctx.hits(s, r, evalue=ctx.cfg["synteny"]["evalue"], top=ctx.cfg["synteny"]["top_hits"])
            except FileNotFoundError:
                continue
            h["q"], h["s"] = h["q"].map(idmap.get(s, {})), h["s"].map(idmap.get(r, {}))
            h = h[h["q"].isin(want) & h["s"].isin(hoc_of_gene.keys())]
            h = h[h["q"].map(fam_of) == h["s"].map(fam_of)]
            for q, t, bts in zip(h["q"], h["s"], h["bits"]):
                if q not in best or bts > best[q][0]:
                    best[q] = (bts, t)
    partner = {q: t for q, (b, t) in best.items()}
    moved = assign_unanchored(un, hoc_of_gene, partner, na_cells)
    for cl, (h, ev) in moved.items():
        m = genes["cluster"] == cl
        genes.loc[m, "hoc"] = h
        genes.loc[m, "evidence"] = ev
    return len(moved)


def _sequence_check(ctx: Context, genes: pd.DataFrame, states: pd.DataFrame) -> pd.DataFrame:
    from .absence import sequence_check
    acfg = ctx.cfg["absence"]
    out = []
    for s, sub in states.groupby("species"):
        fa = ctx.file(s, "genome")
        if not fa or not (sub["state"] == "absent").any():
            out.append(sub)
            continue
        cand = genes[genes["species"] != s]
        # queries: members from the species closest to s
        dist = {r: _tree_dist(ctx, s, r) for r in ctx.scope_species}
        cand = cand.assign(d=cand["species"].map(dist)).sort_values("d")
        q = cand.groupby("hoc").head(acfg["queries_per_hoc"])
        need = set(sub.loc[sub["state"] == "absent", "hoc"])
        q = q[q["hoc"].isin(need)]
        prot = {}
        for r, gg in q.groupby("species"):
            pf = ctx.file(r, "proteome")
            if pf:
                prot.update(_read_fasta(pf, set(gg["gene"]), ctx.cfg.get("id_strip")))
        queries = q.groupby("hoc")["gene"].agg(list).to_dict()
        log(f"miniprot: {s}, {len(need)} intervals")
        out.append(ab.sequence_check(sub, fa, queries, prot, ctx.path("miniprot", s, "x")[:-2],
                                     acfg["miniprot"], ctx.cfg["threads"]))
    return pd.concat(out, ignore_index=True) if out else states


def _tree_dist(ctx: Context, a: str, b: str) -> int:
    la, lb = ctx.leaf(a), ctx.leaf(b)
    m = ctx.tree.mrca([la, lb])
    d = 0
    for x in (la, lb):
        n = ctx.tree.by_name[x]
        while n is not m:
            d += 1
            n = n.parent
    return d


def _read_fasta(path: str, want: set, strip: Optional[str]) -> Dict[str, str]:
    import gzip
    import re
    rx = re.compile(strip) if strip else None
    out, name, buf = {}, None, []
    op = gzip.open if path.endswith(".gz") else open
    with op(path, "rt") as fh:
        for line in fh:
            if line.startswith(">"):
                if name:
                    out[name] = "".join(buf)
                n = line[1:].split()[0]
                n2 = rx.sub("", n) if rx else n
                name = n if n in want else (n2 if n2 in want else None)
                buf = []
            elif name:
                buf.append(line.strip())
    if name:
        out[name] = "".join(buf)
    return out


# ======================================================================= recon
def step_recon(cfg: dict) -> None:
    ctx = Context(cfg)
    fam = ctx.families()
    costs = Costs(**cfg["recon"])
    acc = cfg.get("accessions") or {}

    # ---------------- family level, whole tree
    fcounts = fam.groupby(["family", "species"]).size().unstack(fill_value=0).astype(float)
    sp_cols = list(fcounts.columns)
    zpath = ctx.path("hoc", "hoc_zero_states.tsv.gz")
    if os.path.exists(zpath):
        z = pd.read_csv(zpath, sep="\t")
        if not z.empty:
            z["family"] = z["hoc"].str.rsplit(".L", n=1).str[0]
            rescue = cfg["absence"].get("rescue_unannotated", True)
            g = z.groupby(["family", "species"])["state"].agg(set)
            for (f, s), stset in g.items():
                if f not in fcounts.index or s not in fcounts.columns or fcounts.at[f, s] > 0:
                    continue
                if rescue and "unannotated" in stset:
                    fcounts.at[f, s] = 1.0
                elif stset <= ab.MISSING_STATES:
                    fcounts.at[f, s] = np.nan
    _recon_level(ctx, fcounts, ctx.tree, ctx.wgd, costs, acc, "family", None)

    # ---------------- HOC level, synteny scope subtree
    mpath = ctx.path("hoc", "hoc_matrix.tsv")
    if os.path.exists(mpath):
        hm = pd.read_csv(mpath, sep="\t", index_col=0)
        sub = Tree(ctx.tree.to_newick(ctx.tree.by_name[ctx.scope_node]))
        wgd = {k: v for k, v in ctx.wgd.items() if k in sub.by_name and k != sub.root.name}
        genes = pd.read_csv(ctx.path("hoc", "hoc_genes.tsv.gz"), sep="\t")
        _recon_level(ctx, hm, sub, wgd, costs, acc, "hoc", genes)


def _recon_level(ctx: Context, counts: pd.DataFrame, tree: Tree, wgd: Dict[str, int],
                 costs: Costs, acc: dict, level: str, genes: Optional[pd.DataFrame]) -> None:
    leaves = tree.leaf_names
    if acc:
        groups = {l: [a for a in acc.get(l, [l]) if a in counts.columns] for l in leaves}
        counts, freq = aggregate_accessions(counts, groups, ctx.cfg["min_presence_freq"])
        freq.to_csv(ctx.path(f"recon_{level}", "presence_frequency.tsv"), sep="\t")
    counts = counts.reindex(columns=leaves)
    absent_cols = counts.columns[counts.isna().all()]
    log(f"recon[{level}]: {counts.shape[0]} units x {len(leaves)} leaves"
        + (f" (no data for {list(absent_cols)})" if len(absent_cols) else ""))
    res = reconstruct(counts, tree, wgd, costs)
    ev = res.events
    if genes is not None and not ev.empty:
        ev = _mode_hints(ev, genes, tree, ctx)
    d = lambda f: ctx.path(f"recon_{level}", f)
    res.states.to_csv(d("node_states.tsv.gz"), sep="\t")
    ev.to_csv(d("events.tsv.gz"), sep="\t", index=False)
    bs = branch_summary(ev, tree)
    bs.to_csv(d("branch_summary.tsv"), sep="\t")
    origin_table(res.states, tree).to_csv(d("origins.tsv"), sep="\t")
    res.cost.rename("parsimony_cost").to_csv(d("cost.tsv"), sep="\t")
    n_cafe, n_na = to_cafe(counts, d("cafe5_input.tsv"), d("cafe5_excluded_na.tsv"))
    if n_na:
        log(f"recon[{level}]: CAFE5 table has {n_cafe} complete units; {n_na} units with missing "
            "data (NA) are listed in cafe5_excluded_na.tsv, not written as 0")
    with open(d("tree_with_node_names.nwk"), "w") as o:
        o.write(tree.to_newick() + "\n")
    try:
        from .plot import plot_tree_events
        plot_tree_events(tree, bs, d("tree_events.pdf"), title=f"{level}-level events", wgd=wgd)
    except Exception as e:  # plotting is optional
        log(f"plot skipped: {e}")


def _mode_hints(ev: pd.DataFrame, genes: pd.DataFrame, tree: Tree, ctx: Context) -> pd.DataFrame:
    g = genes.dropna(subset=["mode"]).copy()
    g["leaf"] = g["species"].map(ctx.leaf)
    tab = g.groupby(["hoc", "leaf", "mode"]).size().rename("n").reset_index()
    under = {n.name: set(tree.leaves_under(n.name)) for n in tree.nodes}
    hint = []
    exp = ev["event"].isin(["expansion", "gain"])
    by_hoc = {h: t for h, t in tab.groupby("hoc")}
    for u, node, isexp in zip(ev["unit"], ev["node"], exp):
        if not isexp or u not in by_hoc:
            hint.append("")
            continue
        t = by_hoc[u]
        t = t[t["leaf"].isin(under[node]) & (t["mode"] != "singleton")]
        if t.empty:
            hint.append("")
            continue
        s = t.groupby("mode")["n"].sum().sort_values(ascending=False)
        hint.append(",".join(f"{k}:{v}" for k, v in s.items()))
    ev = ev.copy()
    ev["dup_modes"] = hint
    return ev


def run_all(cfg: dict) -> None:
    step_prepare(cfg)
    step_synteny(cfg)
    step_hoc(cfg)
    step_recon(cfg)
