"""`genelegume subgenomes`: split allopolyploids into subgenome leaves.

Each chromosome of the polyploid is assigned to the progenitor that most of its
genes hit best (OrthoFinder DIAMOND bitscores): with Arachis_duranensis as A and
Arachis_ipaensis as B, a chromosome whose genes mostly hit duranensis best is A.
The species tree is rewritten so each subgenome sits next to its progenitor,
keeping the polyploids' relationship to each other:

    (Adur,(Amon,Ahyp))N11, Aipa  ->  (Adur,(Amon_A,Ahyp_A)), (Aipa,(Amon_B,Ahyp_B))
"""
from __future__ import annotations

import copy
import os
import re
from typing import Dict, List, Optional, Tuple

import pandas as pd

from .tree import Node, Tree

MIN_VOTES = 3
MIN_SHARE = 0.6


# ------------------------------------------------------------------ assignment
def assign_chromosomes(chr_of: Dict[str, str], best: Dict[str, pd.Series],
                       min_votes: int = MIN_VOTES, min_share: float = MIN_SHARE) -> pd.DataFrame:
    """chr_of: polyploid gene -> chromosome; best[label]: gene -> best bitscore vs that progenitor.

    Returns one row per chromosome: n_genes, votes per label, assigned label (or None), share.
    """
    labels = list(best)
    df = pd.DataFrame({"gene": list(chr_of), "chr": list(chr_of.values())})
    for lab in labels:
        df[lab] = df["gene"].map(best[lab]).fillna(0.0)
    sc = df[labels].to_numpy()
    top = sc.max(axis=1)
    win = sc.argmax(axis=1)
    ties = (sc == top[:, None]).sum(axis=1) > 1
    df["vote"] = [labels[w] if t > 0 and not tie else None for w, t, tie in zip(win, top, ties)]
    rows = []
    for c, sub in df.groupby("chr", sort=False):
        v = sub["vote"].value_counts()
        n = int(v.sum())
        lab, k = (v.index[0], int(v.iloc[0])) if n else (None, 0)
        share = k / n if n else 0.0
        ok = n >= min_votes and share >= min_share
        rows.append({"chr": c, "n_genes": len(sub), "n_votes": n,
                     **{f"votes_{x}": int(v.get(x, 0)) for x in labels},
                     "share": round(share, 3), "assigned": lab if ok else None})
    out = pd.DataFrame(rows)
    return out.sort_values("chr", key=lambda s: s.map(_natural)).reset_index(drop=True)


def _natural(s: str):
    return [int(t) if t.isdigit() else t for t in re.split(r"(\d+)", str(s))]


# ------------------------------------------------------------------ tree
def to_newick(node: Node) -> str:
    def lab(n: Node) -> str:
        name = n.name or ""
        if re.search(r"[\s,():;\[\]']", name):
            name = "'" + name.replace("'", "") + "'"
        return name + (f":{n.length:g}" if n.length is not None else "")

    def rec(n: Node) -> str:
        if n.is_leaf:
            return lab(n)
        return "(" + ",".join(rec(c) for c in n.children) + ")" + lab(n)

    return rec(node) + ";"


def split_tree(tree: Tree, polyploids: List[str], progenitors: Dict[str, str],
               leaf_name) -> Tree:
    """Replace polyploid leaves by subgenome leaves next to their progenitors.

    ``leaf_name(poly, label)`` gives the new leaf name. Polyploids that form a
    clade on their own keep that clade, copied once per subgenome.
    """
    root = copy.deepcopy(tree.root)
    by = {}

    def index(n: Node):
        by[n.name] = n
        for c in n.children:
            c.parent = n
            index(c)
    index(root)
    root.parent = None
    polys = set(polyploids)

    # group polyploids into clades made only of polyploids
    groups: List[Node] = []
    done = set()
    for p in polyploids:
        if p in done:
            continue
        n = by[p]
        while n.parent is not None and set(_leaves(n.parent)) <= polys:
            n = n.parent
        groups.append(n)
        done |= set(_leaves(n))

    used = set(by)

    def uniq(name: str) -> str:
        base, i = name, 2
        while name in used:
            name, i = f"{base}_{i}", i + 1
        used.add(name)
        return name

    for g in groups:
        parent = g.parent
        if parent is None:
            raise ValueError("the polyploids make up the whole tree")
        # detach the polyploid clade; collapse the parent if it becomes unary
        parent.children = [c for c in parent.children if c is not g]
        if len(parent.children) == 1:
            only = parent.children[0]
            gp = parent.parent
            if only.length is not None or parent.length is not None:
                only.length = (only.length or 0.0) + (parent.length or 0.0)
            if gp is None:
                root, only.parent = only, None
            else:
                gp.children = [only if c is parent else c for c in gp.children]
                only.parent = gp
            by.pop(parent.name, None)
        for lab, prog in progenitors.items():
            d = by[prog]
            cp = copy.deepcopy(g)

            def rename(n: Node):
                if n.is_leaf:
                    n.name = leaf_name(n.name, lab)
                    used.add(n.name)
                else:
                    n.name = uniq(f"{n.name or 'poly'}_{lab}")
                for c in n.children:
                    c.parent = n
                    rename(c)
            rename(cp)
            half = (d.length / 2) if d.length is not None else None
            join = Node(name=uniq(f"{prog}_{lab}_join"), length=half)
            gp = d.parent
            if gp is None:
                raise ValueError(f"progenitor {prog} is the root")
            gp.children = [join if c is d else c for c in gp.children]
            join.parent = gp
            d.length = half
            join.children = [d, cp]
            d.parent = cp.parent = join
    return Tree(to_newick(root))


def _leaves(n: Node) -> List[str]:
    return [n.name] if n.is_leaf else [x for c in n.children for x in _leaves(c)]


# ------------------------------------------------------------------ main
def run_subgenomes(cfg_path: str, polyploids: List[str], progenitors: Dict[str, str],
                   out_yaml: str, log=print) -> dict:
    from . import config as cfgmod
    from .pipeline import Context
    from .setup_inputs import base_name

    cfg = cfgmod.load(cfg_path)
    if cfg.get("subgenomes"):
        raise ValueError("config already has subgenomes; start from a config without them")
    ctx = Context(cfg)
    leaves = set(ctx.tree.leaf_names)
    for x in [*polyploids, *progenitors.values()]:
        if x not in leaves:
            raise ValueError(f"{x} is not a leaf of the species tree")
    fam = ctx.of.families(cfg["family_level"], cfg["include_unassigned"])  # no prepare needed

    def leaf_name(poly: str, lab: str) -> str:
        return f"{base_name(poly)}_{lab}"

    sub_block: Dict[str, Dict[str, List[str]]] = {}
    tables = []
    for poly in polyploids:
        gt = ctx.annotation(poly, fam)
        if gt is None:
            raise ValueError(f"no annotation for {poly}")
        chr_of = dict(zip(gt.df["gene"], gt.df["chr"]))
        strip = re.compile(cfg["id_strip"]) if cfg.get("id_strip") else None
        best = {}
        for lab, prog in progenitors.items():
            h = ctx.of.hits(poly, prog, evalue=cfg["synteny"]["evalue"], top=1)
            q = h["q"]
            if strip is not None:
                q = q.where(q.isin(chr_of.keys()), q.str.replace(strip, "", regex=True))
            best[lab] = h.assign(q=q).groupby("q")["bits"].max()
        t = assign_chromosomes(chr_of, best)
        t.insert(0, "species", poly)
        tables.append(t)
        parts = {leaf_name(poly, lab): t.loc[t["assigned"] == lab, "chr"].tolist() for lab in progenitors}
        sub_block[poly] = parts
        n_un = int(t.loc[t["assigned"].isna(), "n_genes"].sum())
        log(f"{poly}: " + "; ".join(f"{k} {len(v)} chromosomes" for k, v in parts.items())
            + f"; {n_un} genes on {int(t['assigned'].isna().sum())} unassigned sequences")
        big = t[t["n_genes"] >= 100]
        for r in big.itertuples(index=False):
            log(f"    {r.chr:<20} {r.n_genes:>6} genes  -> {r.assigned}  ({r.share:.0%} of votes)")
        weak = big[(big["share"] < 0.8)]
        if len(weak):
            log(f"  warning: {len(weak)} large chromosomes with < 80% agreement: "
                + ", ".join(weak["chr"]) + " (check for misassembly or translocation)")

    new_tree = split_tree(ctx.tree, polyploids, progenitors, leaf_name)
    stem = re.sub(r"\.ya?ml$", "", out_yaml)
    tree_path = stem + "_tree.nwk"
    with open(tree_path, "w") as fh:
        fh.write(to_newick(new_tree.root) + "\n")
    assign_path = stem + "_subgenome_assignment.tsv"
    pd.concat(tables, ignore_index=True).to_csv(assign_path, sep="\t", index=False)

    # write the new config: the original text with tree: and subgenomes: replaced
    import yaml
    text = open(cfg_path).read().splitlines()
    sub_yaml = yaml.safe_dump({"subgenomes": sub_block}, sort_keys=False, allow_unicode=True,
                              default_flow_style=None, width=100000).rstrip().splitlines()
    out, replaced_tree, replaced_sub = [], False, False
    for line in text:
        if re.match(r"^tree\s*:", line):
            out.append(f"tree: {os.path.abspath(tree_path)}   # 由 genelegume subgenomes 生成（亚基因组叶）")
            replaced_tree = True
        elif re.match(r"^subgenomes\s*:", line):
            out.append(f"# 由 genelegume subgenomes 按同源匹配划分，详情见 {os.path.basename(assign_path)}")
            out.extend(sub_yaml)
            replaced_sub = True
        else:
            out.append(line)
    if not replaced_tree:
        out.append(f"tree: {os.path.abspath(tree_path)}")
    if not replaced_sub:
        out.extend(sub_yaml)
    with open(out_yaml, "w") as fh:
        fh.write("\n".join(out) + "\n")
    # warn about WGD entries naming a polyploid
    for w in cfg.get("wgd") or []:
        names = list(w.get("mrca", [])) + ([w["node"]] if "node" in w else [])
        if any(n in polyploids for n in names):
            log(f"  warning: WGD {w.get('name')} refers to a polyploid leaf; edit it to use subgenome leaves")
    log(f"wrote {out_yaml}, {tree_path}, {assign_path}")
    return {"subgenomes": sub_block, "tree": tree_path}
