"""Species tree annotated with per-branch event counts (gain/loss/expansion/contraction)."""
from __future__ import annotations

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

from .tree import Tree


def _layout(tree: Tree):
    y, x = {}, {}
    k = 0
    for n in tree.nodes:  # postorder: leaves first in order
        if n.is_leaf:
            y[n.name] = k
            k += 1
        else:
            y[n.name] = sum(y[c.name] for c in n.children) / len(n.children)
    for n in tree.preorder():
        x[n.name] = 0.0 if n.parent is None else x[n.parent.name] + 1.0
    depth = max(x.values()) or 1.0
    for n in tree.leaves:  # align leaves (cladogram)
        x[n.name] = depth
    return x, y


def plot_tree_events(tree: Tree, summary: pd.DataFrame, out: str, title: str = "",
                     wgd: dict | None = None) -> None:
    wgd = wgd or {}
    x, y = _layout(tree)
    n = len(tree.leaves)
    fig, ax = plt.subplots(figsize=(9, max(3, 0.32 * n + 1)))
    for node in tree.nodes:
        if node.parent is None:
            continue
        p = node.parent.name
        ax.plot([x[p], x[p]], [y[p], y[node.name]], color="#555", lw=0.8)
        ax.plot([x[p], x[node.name]], [y[node.name], y[node.name]], color="#555", lw=0.8)
        if node.name in summary.index:
            r = summary.loc[node.name]
            g = int(r.get("gain", 0)); l = int(r.get("loss", 0))
            e = int(r.get("expansion", 0)); c = int(r.get("contraction", 0))
            ax.text((x[p] + x[node.name]) / 2, y[node.name] + 0.12, f"+{g}/-{l}",
                    fontsize=6, ha="center", va="bottom", color="#1b6ca8")
            ax.text((x[p] + x[node.name]) / 2, y[node.name] - 0.12, f"↑{e}/↓{c}",
                    fontsize=6, ha="center", va="top", color="#a8431b")
        if node.name in wgd:
            xm = (x[p] + x[node.name]) / 2
            ax.plot([xm], [y[node.name]], marker="s", color="#7a1fa2", ms=5)
            ax.text(xm + 0.05, y[node.name] - 0.42, f"WGD×{wgd[node.name]}", fontsize=6, color="#7a1fa2")
    r = tree.root.name
    if r in summary.index and "gain" in summary.columns:
        ax.text(x[r] - 0.05, y[r], f"root: {int(summary.loc[r, 'gain'])} present",
                fontsize=6, ha="right", va="center", color="#1b6ca8")
    for leaf in tree.leaves:
        ax.text(x[leaf.name] + 0.08, y[leaf.name], leaf.name, va="center", fontsize=7,
                style="italic")
    ax.set_xlim(-1.6, max(x.values()) + 3)
    ax.set_ylim(-1, n)
    ax.axis("off")
    ax.set_title(title + "\nblue: +gain/-loss    red: ↑expansion/↓contraction", fontsize=8)
    fig.tight_layout()
    fig.savefig(out)
    plt.close(fig)
