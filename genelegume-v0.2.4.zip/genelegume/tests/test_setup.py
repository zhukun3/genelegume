"""genelegume setup: per-species folders with mixed formats -> config that runs."""
import gzip
import os
import shutil

import pandas as pd
import yaml

from genelegume import config as cfgmod
from genelegume import pipeline
from genelegume.setup_inputs import run_setup
from genelegume.simulate import Sim, SimParams


def _bed(d, sp):
    return [ln.split("\t") for ln in (d / "bed" / f"{sp}.bed").read_text().splitlines() if ln]


def _w(p, lines, gz=False):
    p.parent.mkdir(parents=True, exist_ok=True)
    op = gzip.open if gz else open
    with op(p, "wt") as fh:
        fh.write("\n".join(lines) + "\n")


def test_setup_mixed_folders(tmp_path):
    Sim(p=SimParams(seed=11, genes_per_chr=60)).run().write(str(tmp_path))
    root = tmp_path / "species"
    # Gmax: Phytozome-like GFF3 + TE decoy + genome in a subfolder
    L = []
    for c, s, e, g, _, st in _bed(tmp_path, "Gmax"):
        L += [f"{c}\tx\tgene\t{int(s)+1}\t{e}\t.\t{st}\t.\tID={g}.gene",
              f"{c}\tx\tmRNA\t{int(s)+1}\t{e}\t.\t{st}\t.\tID={g};Parent={g}.gene"]
    _w(root / "Gmax" / "anno" / "Gmax.v4.gene.gff3.gz", L, gz=True)
    _w(root / "Gmax" / "anno" / "Gmax.TEanno.gff3", ["chr1\tEDTA\tLTR\t1\t9\t.\t+\t.\tID=te"])
    (root / "Gmax" / "genome").mkdir(parents=True)
    shutil.copy(tmp_path / "genome" / "Gmax.fa", root / "Gmax" / "genome" / "assembly.fa")
    # Gsoj: GTF only
    L = []
    for c, s, e, g, _, st in _bed(tmp_path, "Gsoj"):
        L.append(f'{c}\tx\tCDS\t{int(s)+1}\t{e}\t.\t{st}\t0\tgene_id "{g}g"; transcript_id "{g}.1";')
    _w(root / "Gsoj" / "Gsoj.gtf", L)
    # Mtru: NCBI style in a folder whose case differs; plus a wrong older GFF
    L = []
    for c, s, e, g, _, st in _bed(tmp_path, "Mtru"):
        L += [f"{c}\tG\tmRNA\t{int(s)+1}\t{e}\t.\t{st}\t.\tID=rna-X{g};Parent=gene-{g}",
              f"{c}\tG\tCDS\t{int(s)+1}\t{e}\t.\t{st}\t0\tParent=rna-X{g};protein_id={g}.1"]
    _w(root / "mtru" / "GCF.gff", L)
    _w(root / "mtru" / "old.gff3", ["chr1\tx\tmRNA\t1\t900\t.\t+\t.\tID=old1"])
    # Pvul, Vvin: plain BED; Mpol: no folder
    for sp in ("Pvul", "Vvin"):
        (root / sp).mkdir(parents=True)
        shutil.copy(tmp_path / "bed" / f"{sp}.bed", root / sp / f"{sp}.genes.bed")

    out = tmp_path / "gl.yaml"
    rep = tmp_path / "rep.tsv"
    res = run_setup(str(tmp_path / "OrthoFinder" / "Results_sim"), str(root), str(out),
                    str(tmp_path / "proteome"), "out", 1, str(rep), log=lambda *_: None)
    by = {r["species"]: r for r in res["results"]}
    assert by["Gmax"]["annotation"].endswith("Gmax.v4.gene.gff3.gz")
    assert by["Gmax"]["genome"].endswith("assembly.fa")
    assert by["Mtru"]["annotation"].endswith("GCF.gff") and by["Mtru"]["folder_match"] == "case:mtru"
    assert by["Mpol"]["annotation"] is None
    assert all(by[s]["match_loose"] == 1.0 for s in ("Gmax", "Gsoj", "Mtru", "Pvul", "Vvin"))
    assert by["Gsoj"]["proteome_source"] == "orthofinder_input"

    cfg = yaml.safe_load(out.read_text())
    cfg.update(synteny={"scope": ["Gmax", "Vvin"]}, threads=1,
               wgd=[{"mrca": ["Gmax", "Mtru"], "multiplier": 2},
                    {"mrca": ["Gmax", "Gsoj"], "multiplier": 2}])
    with open(out, "w") as fh:
        yaml.safe_dump(cfg, fh)
    pipeline.run_all(cfgmod.load(str(out)))
    m = pd.read_csv(tmp_path / "out" / "id_match.tsv", sep="\t")
    assert (m["rate"] == 1.0).all()
    assert os.path.exists(tmp_path / "out" / "recon_hoc" / "branch_summary.tsv")


def test_folder_names_with_suffix(tmp_path):
    from genelegume.setup_inputs import find_folder
    for d in ("Glycine_max", "Arachis_hypogaea", "Cercis_chinensis", "peanut_T2T"):
        (tmp_path / d).mkdir()
    assert find_folder(str(tmp_path), "Glycine_max.Wm82")[1] == "base:Glycine_max"
    assert find_folder(str(tmp_path), "Arachis_hypogaea.jnh12")[0].endswith("Arachis_hypogaea")
    assert find_folder(str(tmp_path), "Circus_chinensis")[1] == "fuzzy:Cercis_chinensis"
    assert find_folder(str(tmp_path), "S1979_T2T.gene.pep")[0] is None
    p, how = find_folder(str(tmp_path), "S1979_T2T.gene.pep", {"S1979_T2T.gene.pep": "peanut_T2T"})
    assert how == "map" and p.endswith("peanut_T2T")


def test_wgd_placement_by_genus():
    from genelegume.setup_inputs import place_wgd
    from genelegume.tree import Tree
    t = Tree("(Arabidopsis_thaliana.tair10,(Circus_chinensis,((Arachis_duranensis,Aeschynomene_evenia),"
             "((Glycine_max.Wm82,Glycine_soja.YSD56),Medicago_truncatula.longest))));")
    wgd, notes = place_wgd(t, t.leaf_names)
    got = {w["name"]: w for w in wgd}
    assert set(got) == {"papilionoid", "Glycine", "At_alpha_beta"} and not notes
    assert t.mrca(got["papilionoid"]["mrca"]).name == t.mrca(
        ["Arachis_duranensis", "Medicago_truncatula.longest"]).name
    assert got["At_alpha_beta"]["node"] == "Arabidopsis_thaliana.tair10"
    # misrooted: Cercis falls inside the papilionoid clade -> not placed, explained
    bad = Tree("(Arabidopsis_thaliana,((Arachis_duranensis,Circus_chinensis),Medicago_truncatula));")
    wgd, notes = place_wgd(bad, bad.leaf_names)
    assert "papilionoid" not in {w["name"] for w in wgd} and "Circus_chinensis" in notes[0]


def test_isoform_note(tmp_path):
    from genelegume.setup_inputs import resolve_species
    prots = [f"Lj1g{i:05d}.{k}" for i in range(50) for k in (1, 2)]
    r = resolve_species(("Lotus_japonicus", str(tmp_path), None, prots, None))
    assert r["n_isoform_extra"] == 50
    assert any("其他转录本" in n for n in r["notes"])


def test_wgd_uses_folder_map_names():
    from genelegume.setup_inputs import place_wgd
    from genelegume.tree import Tree
    t = Tree("(Arabidopsis_thaliana.tair10,(Circus_chinensis,((Arachis_duranensis,S1979_T2T.gene.pep),"
             "Medicago_truncatula.longest)));")
    wgd, notes = place_wgd(t, t.leaf_names)
    assert "papilionoid" not in {w["name"] for w in wgd}          # S1979 unknown -> not placed
    wgd, notes = place_wgd(t, t.leaf_names, {"S1979_T2T.gene.pep": "Stylosanthes_guianensis"})
    pap = [w for w in wgd if w["name"] == "papilionoid"]
    assert pap and t.mrca(pap[0]["mrca"]).name == t.mrca(
        ["Arachis_duranensis", "Medicago_truncatula.longest"]).name and not notes


def test_isoform_note_dropped_when_every_protein_matches(tmp_path):
    from genelegume.setup_inputs import resolve_species
    folder = tmp_path / "Adur"
    folder.mkdir()
    prots = [f"Adu0{c}.{i}" for c in range(1, 4) for i in range(1, 30)]   # suffix = gene number
    rows = [f"chr{c}\tx\tmRNA\t{i*1000+1}\t{i*1000+900}\t.\t+\t.\tID=Adu0{c}.{i}"
            for c in range(1, 4) for i in range(1, 30)]
    (folder / "a.gff3").write_text("\n".join(rows) + "\n")
    r = resolve_species(("Adur", str(tmp_path), None, prots, None))
    assert r["match_loose"] == 1.0 and r["n_isoform_extra"] == 0
    assert not any("其他转录本" in n for n in r["notes"])
